-- Incoming 0x028 action layout: local server action packet and Ashita chains reference.
local bit=require('bit')
local M={}
function M.parse(e)
    local offset,limit=40,e.size*8
    local function read(n)
        if offset+n>limit then error('Truncated action packet') end
        local value=ashita.bits.unpack_be(e.data_raw,0,offset,n)
        offset=offset+n
        return value
    end
    local result={actor=read(32),targets={}}
    local targets=read(6); read(4)
    result.category=read(4); result.id=bit.band(read(32),65535); read(32)
    for _=1,targets do
        local target={id=read(32),actions={}}
        local actions=read(4)
        for _=1,actions do
            local a={reaction=read(5)}
            read(12); read(7); read(3)
            a.amount=read(17); a.message=read(10); read(31)
            if read(1)==1 then a.effect=bit.band(read(10),63); read(17); a.effectMessage=read(10) end
            if read(1)==1 then read(10); read(14); read(10) end
            target.actions[#target.actions+1]=a
        end
        result.targets[#result.targets+1]=target
    end
    return result
end
return M
