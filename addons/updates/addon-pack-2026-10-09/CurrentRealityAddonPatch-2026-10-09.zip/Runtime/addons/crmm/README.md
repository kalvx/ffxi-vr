# crmm — Current Reality Summoner helper

Version 1.2.1, for your Ashita v4 client and Current Reality server. Load with:

```text
/addon load crmm
```

Target a living monster, summon your avatar, and press **Scan**. The panel reads your current main/subjob, learned usable weapon skills and spells, current avatar's available abilities, MP and cooldowns. It shows a recommended chain, its burst element, and previews for your other learned summons. Those previews are level-based; summon an avatar and Scan to verify its actual available pacts. Some summons have no chain-capable pact in this server's definitions.

When engaged with at least 1000 TP, press **Run combo**. This starts exactly one sequence: weapon skill → avatar pact, or avatar pact → weapon skill, followed by a learned player spell of the appropriate burst element. It considers both orders. For repeated execution, enable **Auto combo** once. It waits for 1000 TP, enough MP for the entire chosen combination, ready pact/spell timers and a fresh target scan, then executes and repeats. You must engage the monster yourself and select the monster you are attacking. Keep your avatar summoned; the addon does not summon or replace it. Auto starts OFF after load and turns OFF on Stop, logout, job or zone changes, or three failed sequences. Disengaging pauses execution until you engage again. Stay in melee range with your avatar nearby, and stand still for the spell.

The opener must produce a successful server action result. The closer is sent 3.3 seconds after that confirmation. The burst is requested only after the matching skillchain additional-effect message; ordinary extra damage is not accepted as chain confirmation. A server magic-burst message confirms completion. Misses, absent acknowledgements, absorbed/unconfirmed chains, competing chain actions, target/weapon/job/pet/zone changes, unavailable skills, low TP/MP, recasts and incapacitating statuses cancel the remaining sequence. Stop cancels pending steps; it cannot undo a command already transmitted.

## Farm mode: repeat fights and stop when XP stops

After a fight, reload with `/addon reload crmm`. Enable **Farm: ON** or `/crmm farm on`. Farm also enables Auto combo. Both modes start OFF after loading. **Stop** or `/crmm stop` disables both.

Farm prioritizes the monster you are fighting, then your selected eligible monster, then the nearest living available monster within 20 yalms. It holds that target until confirmed defeat and restores the cursor if it changes. It rejects targets claimed outside your alliance. This is stationary camp combat: it does not walk, navigate obstacles, or move you into weapon-skill range. Use a camp where pulled monsters reach melee range; the panel explains range waits.

It sends your engage command as soon as the target is selected, before waiting for the scan or summon, so you can melee and build TP. It then scans the selected monster. If no avatar is summoned, it chooses an eligible learned elemental avatar using that target's resistance scores (Ifrit, Shiva, Garuda, Titan, Ramuh, Leviathan, Carbuncle or Fenrir). A tie uses that order; a neutral best score does not prove a weakness. It checks actual summon level, MP and recast. It preserves an existing avatar. Outside five yalms it casts one affordable learned opening elemental spell if available. In melee range it skips that opening cast to avoid delaying your swings. It sends Assault to the locked target and confirms the avatar's target before combos. Repeated failed summons or Assault attempts stop the loop.

At 1000 TP, with MP, timers and range ready, it runs the current avatar's compatible weapon-skill/pact combination and casts the learned burst only after the skillchain is confirmed. It repeats while the monster lives. Auto combo without Farm now also sends Assault when the avatar is not attacking your selected engaged monster. It never makes up a chain when your weapon/avatar has no compatible combination; the panel shows that wait.

After target HP reaches zero, Farm waits 12 seconds for the experience update. An increased XP total or a level-up permits the next target. A kill without XP stops Farm; limit points alone do not count. The controller also stops on logout, zone/job change, death, loss of the tracked target before a confirmed defeat, foreign claim, repeated combo failures, or five minutes without completed progress. Low MP waits for recovery; this mode does not automatically rest or use consumables. Stop cancels queued guarded actions, but cannot undo actions already transmitted or turn off the game's existing auto-attack.

The scan, planner, actions and experience checks are read-only observations plus normal client commands. No database tables, jobs, gear addons, fishing code or level-cap changes are involved.

## Your magic and summons

The burst selector includes learned, currently usable Tier I/II Fire, Blizzard, Aero, Stone, Thunder, Water and Banish, plus Holy where available. It checks current main/sub levels; learning a spell on another job does not make it usable as SMN. Tier II is preferred when you have enough MP for both the pact and spell, with Tier I fallback. Auto waits for MP and recast for its preferred learned spell rather than dropping the burst while that spell is unavailable. These recommendations are not a complete damage simulator.

If your current jobs have no matching burst spell, the panel explicitly shows **no player burst** and Run performs the chain only. It never invents spells or grants access. An avatar's elemental pacts such as Fire II share Blood Pact: Rage recast with its chain pact, so an ordinary second Rage pact is not appended. Astral Flow, Astral Conduit, Apogee activation and automatic replacement of an existing avatar are not commanded. An already-active Apogee's extra MP cost is accounted for.

All learned summons are listed, including spirits and special summons. Your current database supplies 27 chain-capable pacts across Carbuncle, Fenrir, Ifrit, Titan, Leviathan, Garuda, Shiva, Ramuh, Diabolos and Cait Sith. Siren currently has no skillchain properties in the server's pet-skill records; she is displayed without fabricated combinations. No pet/ability tables were edited.

The panel shows **SCAN OK** when telemetry arrives. Private `[CRMM1]` replies are parsed directly from incoming chat packets and hidden; their numbers are protocol data. Shantotto II can independently burst a successful chain, but this addon does not command trusts.

## Live target scan

`server/crmm.lua` is also installed as `VR_recovery_test/scripts/commands/crmm.lua`. The addon sends the server command `!crmm <target-id> <request-id>` through `/say`; the server command handler consumes it and sends two private system replies. It checks the actual cursor target, matching ID, monster type, distance and life state, and limits queries to once per two seconds. The addon samples every five seconds while idle with a valid SMN monster target, and requires a fresh response before Run. Stop pauses automatic scanning; Scan resumes it.

The helper only reads current elemental resistance ranks, specific damage-taken modifiers, elemental magic evasion and elemental/general absorb/null chances. It makes no SQL writes and changes no character stats, variables, levels, quest flags or equipment. Requests are correlated to target, character, zone, weapon and avatar; stale, partial or unrelated replies cannot launch a sequence.

Lower resistance ranks and less damage reduction improve an element's score. Absorbing elements and full nullification are excluded. The planner prefers a complete usable burst combination, then the relative element score and chain level. The displayed modifiers are sampled observations, not a guarantee of damage: scripted mechanics, monster stances, weather, equipment procs, special weapon aftermath and changes after the scan can affect the outcome. Do not call a neutral element a confirmed weakness merely because it wins the ranking.

Only install the client on this server (or another server where its matching helper is installed). If the helper is absent, Run waits for a valid response and does not execute combat actions. A missing command may appear in chat, depending on that server's command handler.

## Commands and controller macros

```text
/crmm scan
/crmm run
/crmm auto on
/crmm auto off
/crmm farm on
/crmm farm off
/crmm stop
/crmm show
/crmm hide
```

`/crmm` toggles the panel. FFXI macro examples:

```text
/console /crmm scan
/console /crmm run
/console /crmm auto on
/console /crmm stop
```

Put these in separate SCAN / COMBO / AUTO / STOP macros. Equivalent scripts are `crmm-scan.txt`, `crmm-run.txt`, `crmm-auto.txt`, `crmm-farm.txt`, and `crmm-stop.txt`, run with `/exec crmm-run.txt`. No startup files or key bindings were changed. This addon does not alter crhotswap, crfishing, chains or the level-75 policy.

## Install, data and undo

The client files are already in your Runtime addon/scripts directories. On a second Ashita v4 device, extract the portable zip's `addons` and `scripts` folders into the Ashita runtime. The server helper is installed once on the server, not on each client machine. Load crmm manually.

Unload immediately with `/addon unload crmm`. The installation checkpoint in `Backups/crmm-install-*` records the added files and hashes. `tools/rollback_crmm.py <checkpoint>` previews removal; `--apply` requires the game client and map process stopped and removes only unchanged, listed files. Keeping the map stopped for removal prevents a removed command from remaining in its Lua cache. It never rolls back levels or database records.

`tools/export_crmm.py` refreshes the bundled action data using SELECT queries and the matching local server source. It exports no credentials or character data. It copies the server's ordered skillchain transition rules, weapon/pact properties, spell job requirements and pact MP costs. Export again after intentional server combat-rule changes, then reload crmm.

## Validation

Run `python CurrentRealityClient/Runtime/addons/crmm/tests/run.py`. Tests cover planning in both orders, spell/job/MP eligibility, ability-resource and cooldown checks, automatic waiting/repetition/disarming, read-only server targeting, fresh telemetry, action-packet parsing, real callback scheduling, expected chain confirmation, burst confirmation, stop/timeout/target changes, and outgoing target protection. Farm tests also exercise summons, opening magic, Assault, matching player/pet targets, repeated combos, confirmed deaths, XP continuation, no-XP shutdown and queued-action cancellation. These are simulated Ashita/server tests; in-game timing still needs a trial after loading.

API and packet references: local Ashita SDK annotations, `addons/chains`, and this server's `battleutils.cpp`, `charutils.cpp`, `petentity.cpp` and `packet_system.cpp`. Standard command execution uses [Ashita's documented command interface](https://docs.ashitaxi.com/features/).
