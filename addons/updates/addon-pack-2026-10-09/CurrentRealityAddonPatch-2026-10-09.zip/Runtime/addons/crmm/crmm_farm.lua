-- Pure camp-combat controller. All client actions are supplied by the adapter.
local M={}
function M.new(env)
    local f={enabled=false,status='OFF',radius=20}
    function f:stop(reason)
        self.enabled=false; self.target=nil; self.status=reason or 'Stopped.'
    end
    function f:start(context)
        self.enabled=true; self.context=context; self.target=nil; self.next=0
        self.lastProgress=env.now(); self.status='Finding a target.'
    end
    function f:tick(s)
        if not self.enabled then return false end
        local t=env.now()
        local function halt(reason) self:stop(reason); env.stop(reason); return false end
        if not s or s.context~=self.context or s.hp<=0 then return halt('Farm OFF: logout, job/zone change or player defeated.') end
        if t-self.lastProgress>300 then return halt('Farm OFF: no completed progress for five minutes.') end
        if self.target then
            local mob=env.mob(self.target.index)
            if not self.deadAt and (not mob or mob.id~=self.target.id) then return halt('Farm OFF: tracked target disappeared before a confirmed defeat.') end
            if self.deadAt or mob.hp<=0 then
                self.deadAt=self.deadAt or t
                self.status='Target defeated; waiting for experience update.'
                if t-self.deadAt<12 then return false end
                if not (s.level>self.level or s.level==self.level and s.exp>self.exp) then return halt('Farm OFF: defeated target gave no experience.') end
                self.target=nil; self.deadAt=nil; self.lastProgress=t; self.next=t+1
                return false
            end
            if not mob.allowed then return halt('Farm OFF: target claimed outside your alliance or moved outside camp range.') end
        end
        if t<self.next then return false end
        if not self.target then
            local mob=env.choose(self.radius,s.battleTarget)
            if not mob then self.next=t+2; self.status='Waiting for a nearby available monster.'; return false end
            self.target=mob; self.exp=s.exp; self.level=s.level; self.phase='scan'; self.attempts=0; self.deadAt=nil
        end
        local target=self.target
        if s.selected~=target.index then
            env.select(target.index); self.next=t+1; self.status='Selecting '..target.name; return false
        end
        -- Start player melee before waiting for telemetry, summoning or opening casts.
        if s.status~=1 or s.battleTarget~=target.index then
            env.command('/attack <t>'); self.next=t+3; self.status='Engaging '..target.name; return false
        end
        if not s.weak then self.status='Waiting for target resistance scan.'; return false end
        if s.blocked then self.status='Waiting for disabling status to clear.'; return false end
        if s.pet==0 then
            local summon=env.summon(s)
            if not summon then self.status='Waiting for MP/recast or an eligible learned summon.'; return false end
            self.attempts=self.attempts+1
            if self.attempts>5 then return halt('Farm OFF: summon failed repeatedly.') end
            env.command('/ma "'..summon..'" <me>'); self.next=t+10; self.status='Summoning '..summon; return false
        end
        if self.phase=='scan' then
            local spell=(s.distance or math.huge)>5 and env.pull(s) or nil
            if spell then env.command('/ma "'..spell..'" <t>'); self.next=t+6 end
            self.phase='fight'; self.attempts=0; self.status=spell and 'Casting opening spell.' or 'Opening with avatar.'
            return false
        end
        if s.petTarget~=target.index then
            self.attempts=self.attempts+1
            if self.attempts>5 then return halt('Farm OFF: avatar did not acquire the selected target.') end
            env.command('/pet "Assault" <t>'); self.next=t+3; self.status='Assault on '..target.name; return false
        end
        self.attempts=0
        self.status='Fighting '..target.name..'; waiting for TP, pact and burst timers.'
        return true
    end
    return f
end
return M
