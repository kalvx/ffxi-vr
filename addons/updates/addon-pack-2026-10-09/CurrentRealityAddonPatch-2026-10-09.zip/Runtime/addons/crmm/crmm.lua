addon.name='crmm'
addon.author='Current Reality'
addon.version='1.2.1'
addon.desc='Summoner skillchain and magic burst helper with optional automatic combos.'
require('common')
local bit=require('bit')
local imgui=require('imgui')
local ffi=require('ffi')
local core=require('crmm_core')
local data=require('crmm_data')
local packets=require('crmm_packets')
local farmModule=require('crmm_farm')
local farm
ffi.cdef('unsigned long __stdcall GetTickCount(void);')
local function now() return tonumber(ffi.C.GetTickCount())/1000 end
local state={visible=true,auto=true,nonce=math.floor(now())%90000000,message='Target a monster and press Scan.',plans={},all={},nextScan=0,zoneUntil=0}
local avatars={'Carbuncle','Fenrir','Ifrit','Titan','Leviathan','Garuda','Shiva','Ramuh','Diabolos','Cait Sith','Siren',
    'Alexander','Odin','Atomos','Fire Spirit','Ice Spirit','Air Spirit','Earth Spirit','Thunder Spirit','Water Spirit','Light Spirit','Dark Spirit'}
local function say(s) state.message=s; print('[crmm] '..s) end
local function queue(s) AshitaCore:GetChatManager():QueueCommand(1,s) end
local function snapshot()
    if now()<state.zoneUntil then return end
    local mem=AshitaCore:GetMemoryManager()
    local p,party,entity=mem:GetPlayer(),mem:GetParty(),mem:GetEntity()
    local index=party:GetMemberTargetIndex(0)
    if p:GetLoginStatus()~=2 or index==0 or not p:HasAbilityData() or not p:HasSpellData() then return end
    if p:GetMainJob()~=15 and p:GetSubJob()~=15 then return end
    local ti=mem:GetTarget():GetTargetIndex(0)
    if ti==0 or bit.band(entity:GetSpawnFlags(ti),16)==0 or entity:GetHPPercent(ti)<=0 then return end
    local petIndex=entity:GetPetTargetIndex(index)
    local s={main=p:GetMainJob(),sub=p:GetSubJob(),level=p:GetMainJobLevel(),sublevel=p:GetSubJobLevel(),
        player=party:GetMemberServerId(0),zone=party:GetMemberZone(0),index=index,targetIndex=ti,target=entity:GetServerId(ti),
        targetName=entity:GetName(ti),petIndex=petIndex,pet=petIndex~=0 and entity:GetServerId(petIndex) or 0,
        avatar=petIndex~=0 and entity:GetName(petIndex) or '',mp=party:GetMemberMP(0),tp=party:GetMemberTP(0),
        hp=party:GetMemberHP(0),status=entity:GetStatusServer(index),battleTarget=entity:GetTargetedIndex(index),distance=math.sqrt(entity:GetDistance(ti))}
    local equipped=mem:GetInventory():GetEquippedItem(0)
    local packed=equipped and equipped.Index or 0
    local item=packed>0 and mem:GetInventory():GetContainerItem(math.floor(packed/256),packed%256)
    s.weapon=item and tostring(item.Id)..':'..(item.Extra or '') or 'none'
    s.key=table.concat({s.player,s.zone,s.main,s.sub,s.level,s.sublevel,s.target,s.pet,s.weapon},':')
    return s
end
local function buffs()
    local result={}
    for _,id in pairs(AshitaCore:GetMemoryManager():GetPlayer():GetBuffs()) do result[id]=true end
    return result
end
local function abilityReady(id)
    local recast=AshitaCore:GetMemoryManager():GetRecast()
    for i=0,31 do
        if recast:GetAbilityTimerId(i)==id and recast:GetAbilityTimer(i)>0 then return false end
    end
    return true
end
local function distance(a,b)
    local e=AshitaCore:GetMemoryManager():GetEntity()
    local x=e:GetLocalPositionX(a)-e:GetLocalPositionX(b)
    local y=e:GetLocalPositionY(a)-e:GetLocalPositionY(b)
    local z=e:GetLocalPositionZ(a)-e:GetLocalPositionZ(b)
    return math.sqrt(x*x+y*y+z*z)
end
local function copyAction(id,d,kind,actor)
    local a={}; for k,v in pairs(d) do a[k]=v end
    local res=AshitaCore:GetResourceManager()
    local r=kind=='spell' and res:GetSpellById(id) or res:GetAbilityById(id+(kind=='pet' and 512 or 0))
    if not r or not r.Name or not r.Name[1] or r.Name[1]=='' then return end
    a.id=id; a.kind=kind; a.actor=actor; a.name=r.Name[1]
    if a.name:find('["\r\n]') then return end
    return a
end
local function utilityCommand(command)
    local s=snapshot()
    if not s then return end
    local category,id,target=2,0,s.targetIndex
    local name=command:match('^/ma "(.-)"')
    if name then
        local r=AshitaCore:GetResourceManager():GetSpellByName(name,0)
        if not r then return end
        category=3; id=r.Index
        if command:find('<me>',1,true) then target=s.index end
    elseif command:find('/pet ',1,true)==1 then category=9; id=88 end -- server Assault ability
    state.utilityGuard={category=category,id=id,target=target,key=s.key,generation=state.generation or 0,expires=now()+12}
    queue(command)
end
local function catalog(s)
    local mem=AshitaCore:GetMemoryManager()
    local p,res=mem:GetPlayer(),AshitaCore:GetResourceManager()
    local w,pet,spells,other,owned,potentialPacts,potentialSpells={},{},{},{},{},{},{}
    local effects=buffs()
    for id,d in pairs(data.ws) do
        if p:HasWeaponSkill(id) then local a=copyAction(id,d,'ws',s.player); if a then w[#w+1]=a end end
    end
    for id,d in pairs(data.spells) do
        if p:HasSpell(id) and core.castable(d,s) then
            local a=copyAction(id,d,'spell',s.player)
            if a then
                potentialSpells[#potentialSpells+1]=a
                if mem:GetRecast():GetSpellTimer(id)==0 then spells[#spells+1]=a end
            end
        end
    end
    local smnLevel=s.main==15 and s.level or s.sublevel
    for _,name in ipairs(avatars) do
        local summon=res:GetSpellByName(name,0)
        if summon and p:HasSpell(summon.Index) then owned[name]=summon.Index end
    end
    for id,d in pairs(data.pets) do
        if d.level<=smnLevel and owned[d.avatar] then
            local a=copyAction(id,d,'pet',s.pet)
            if a then
                a.mp=math.ceil(a.mp*(effects[583] and 1.5 or 1))
                -- HasAbility uses the resource ID (server ability ID + 512), including pet abilities.
                -- Do not pass a raw server pet-menu bit to a client ID-based helper.
                if d.avatar==s.avatar and p:HasAbility(id+512) then
                    potentialPacts[#potentialPacts+1]=a
                    if abilityReady(d.recast) then pet[#pet+1]=a end
                end
                -- Un-summoned avatar menu bits cannot be verified: previews use ordinary level-unlocked pacts.
                if d.add==0 then other[d.avatar]=other[d.avatar] or {}; other[d.avatar][#other[d.avatar]+1]=a end
            end
        end
    end
    return w,pet,spells,other,owned,potentialPacts,potentialSpells
end
local function rebuild(s)
    state.plans={}; state.all={}; state.autoPlan=nil
    if not state.weak or state.weak.key~=s.key or now()-state.weak.time>12 then return end
    local w,p,sp,others,owned,potentialPacts,potentialSpells=catalog(s)
    state.available=string.format('%d usable weapon skills | %d ready avatar pacts | %d usable burst spells',#w,#p,#sp)
    state.owned=owned
    state.plans=core.plan(data,w,p,sp,state.weak.values,s.mp)
    -- Keep the intended full combo while MP/recasts recover; do not silently drop
    -- its burst merely because the spell is cooling down or MP is temporarily low.
    state.autoPlan=core.plan(data,w,potentialPacts,potentialSpells,state.weak.values,999999)[1]
    for _,avatar in ipairs(avatars) do
        if owned[avatar] then
            local suggestions=core.plan(data,w,others[avatar] or {},sp,state.weak.values,s.mp)
            state.all[#state.all+1]={name=avatar,plan=suggestions[1]}
        end
    end
    state.snapshot=s
end
local runner
local function valid(active)
    local s=snapshot()
    if not s or s.key~=active.identity.key then return false,'Target, weapon, job, pet or zone changed. Sequence stopped.' end
    if s.hp<=0 or s.status~=1 then return false,'Engage the selected monster before running a combo.' end
    if s.pet==0 then return false,'Summon an avatar first.' end
    local e=AshitaCore:GetMemoryManager():GetEntity()
    if active.identity.automated and (s.battleTarget~=s.targetIndex or e:GetTargetedIndex(s.petIndex)~=s.targetIndex) then
        return false,'Player or avatar combat target changed; remaining combo cancelled.'
    end
    if e:GetHPPercent(s.petIndex)<=0 then return false,'Avatar unavailable.' end
    local claim=e:GetClaimStatus(s.targetIndex)
    if claim~=0 then
        local party,ours=AshitaCore:GetMemoryManager():GetParty(),false
        for i=0,17 do if party:GetMemberIsActive(i)~=0 and party:GetMemberServerId(i)==claim then ours=true end end
        if not ours then return false,'Target is claimed outside your alliance.' end
    end
    local b=buffs()
    for _,id in ipairs({2,7,10,14,17,19,28}) do if b[id] then return false,'A status effect prevents actions.' end end
    return true,nil,s,b
end
local function ready(a,active)
    local ok,reason,s,b=valid(active)
    if not ok then return false,reason end
    local p=AshitaCore:GetMemoryManager():GetPlayer()
    if a.kind=='ws' then
        if b[16] or s.tp<1000 or not p:HasWeaponSkill(a.id) then return false,'Weapon skill unavailable, TP below 1000, or Amnesia.' end
        if s.distance>math.min(a.range,5) then return false,'Move within weapon-skill range.' end
    elseif a.kind=='pet' then
        if b[16] or s.avatar~=a.avatar or not p:HasAbility(a.id+512) or not abilityReady(a.recast) then return false,'Avatar pact is unavailable or on cooldown.' end
        local cost=math.ceil(data.pets[a.id].mp*(b[583] and 1.5 or 1))
        if s.mp<cost+(active.plan.spell and active.plan.spell.mp or 0) then return false,'Not enough MP reserved for the pact and burst.' end
        if distance(s.petIndex,s.targetIndex)>=a.range or distance(s.petIndex,s.index)>=21 or s.distance>=22 then return false,'Move yourself and your avatar closer to the target.' end
    else
        if b[6] or b[29] or not p:HasSpell(a.id) or not core.castable(a,s) or s.mp<a.mp
            or AshitaCore:GetMemoryManager():GetRecast():GetSpellTimer(a.id)>0 then return false,'Burst spell unavailable: check MP, Silence, job and recast.' end
        if s.distance>20 then return false,'Target is outside burst casting range.' end
    end
    if active.plan.spell and a.kind=='ws' and active.plan.second.kind=='pet' and s.mp<active.plan.second.mp+active.plan.spell.mp then
        return false,'Not enough MP reserved for pact and burst.'
    end
    return true
end
runner=core.runner({now=now,message=say,valid=valid,ready=ready,finished=function(success)
    state.autoNotBefore=now()+5
    local targetDefeated=state.snapshot and AshitaCore:GetMemoryManager():GetEntity():GetHPPercent(state.snapshot.targetIndex)<=0
    state.autoFailures=(success or targetDefeated) and 0 or (state.autoFailures or 0)+1
    if state.combatAuto and state.autoFailures>=3 then
        state.combatAuto=false
        if farm then farm:stop('Repeated combo failures.') end
        say('Auto combo paused after three failed sequences. Check the last error, then enable Auto again.')
    end
end,send=function(a)
    local prefix=({ws='/ws',pet='/pet',spell='/ma'})[a.kind]
    state.guard={id=a.id,kind=a.kind,key=runner.active.identity.key,targetIndex=runner.active.identity.targetIndex,expires=now()+12}
    queue(string.format('%s "%s" <t>',prefix,a.name))
    say('Requested '..a.name..'; waiting for the server.')
end})
local function stop(message)
    state.intent=nil; state.combatAuto=false; state.nextRunScan=nil
    state.generation=(state.generation or 0)+1
    if farm then farm:stop(message) end
    -- Keep any already queued action guard until its expiry, to reject a late packet after Stop.
    runner:stop(message)
end
local function start(s,automatic)
    rebuild(s)
    local function waiting(reason)
        if automatic then state.autoStatus=reason else say(reason) end
    end
    local plan=state.plans[1]
    if automatic then plan=state.autoPlan end
    if not plan then waiting('No usable weapon skill + current-avatar pact combination. Check the summon list, MP and Rage recast.'); return end
    s.automated=automatic==true
    local active={identity=s,plan=plan}
    for _,a in ipairs({plan.first,plan.second}) do
        local ok,reason=ready(a,active); if not ok then waiting(reason); return end
    end
    if plan.spell then
        local ok,reason=ready(plan.spell,active); if not ok then waiting(reason); return end
        local pet=plan.first.kind=='pet' and plan.first or plan.second
        if s.mp<pet.mp+plan.spell.mp then waiting('Not enough MP for the whole sequence.'); return end
    end
    runner:start(plan,s)
end
local function autoContext()
    local m=AshitaCore:GetMemoryManager()
    local p,party=m:GetPlayer(),m:GetParty()
    if p:GetLoginStatus()~=2 or (p:GetMainJob()~=15 and p:GetSubJob()~=15) then return end
    return table.concat({party:GetMemberServerId(0),party:GetMemberZone(0),p:GetMainJob(),p:GetSubJob()},':')
end
local function setAuto(enabled)
    if not enabled then stop('Auto combo OFF. Remaining sequence cancelled.'); return end
    local context=autoContext()
    if not context then say('Log in on SMN main/sub before enabling Auto combo.'); return end
    state.combatAuto=true; state.auto=true; state.autoContext=context; state.autoFailures=0
    state.autoStatus='Waiting for an engaged target, avatar, 1000 TP, MP and cooldowns.'
    say('Auto combo ON. It will repeat on targets you engage. Stop turns it off.')
end
-- Camp farming deliberately uses normal commands and target selection, never movement packets.
local function mobAt(index,radius)
    if not index or index<=0 or index>=2304 then return end
    local m=AshitaCore:GetMemoryManager(); local e,party=m:GetEntity(),m:GetParty()
    if bit.band(e:GetSpawnFlags(index),16)==0 then return end
    local id=e:GetServerId(index); if id==0 then return end
    local claim=e:GetClaimStatus(index); local allowed=claim==0
    for i=0,17 do
        if party:GetMemberIsActive(i)~=0 and party:GetMemberServerId(i)==claim then allowed=true end
    end
    local d=math.sqrt(e:GetDistance(index))
    return {index=index,id=id,name=e:GetName(index),hp=e:GetHPPercent(index),distance=d,allowed=allowed and d<=radius}
end
local elementalAvatars={'Ifrit','Shiva','Garuda','Titan','Ramuh','Leviathan','Carbuncle','Fenrir'}
local function chooseSummon(s)
    local m=AshitaCore:GetMemoryManager(); local p=m:GetPlayer(); local res=AshitaCore:GetResourceManager()
    local best,score
    for element,name in ipairs(elementalAvatars) do
        local r=res:GetSpellByName(name,0)
        local value=core.elementScore(s.weak[element])
        -- Read the client's job restrictions, not just whether the spell was learned.
        local required=r and r.LevelRequired and r.LevelRequired[16]
        local level=p:GetMainJob()==15 and p:GetMainJobLevel() or p:GetSubJobLevel()
        if r and required and required>0 and required<255 and required<=level and p:HasSpell(r.Index)
            and value and s.mp>=r.ManaCost and m:GetRecast():GetSpellTimer(r.Index)==0
            and (not score or value>score) then best=name; score=value end
    end
    return best
end
local function choosePull(s)
    local snap=snapshot(); if not snap then return end
    local m=AshitaCore:GetMemoryManager(); local best,value
    for id,d in pairs(data.spells) do
        local score=core.elementScore(s.weak[d.element])
        if score and core.castable(d,snap) and m:GetPlayer():HasSpell(id) and m:GetRecast():GetSpellTimer(id)==0 and d.mp<=s.mp then
            local a=copyAction(id,d,'spell',snap.player)
            if a and (not value or score>value or score==value and a.mp<best.mp) then best=a; value=score end
        end
    end
    return best and best.name
end
farm=farmModule.new({now=now,stop=stop,command=utilityCommand,mob=function(index) return mobAt(index,farm.radius) end,
    select=function(index) AshitaCore:GetMemoryManager():GetTarget():SetTarget(index,true) end,
    choose=function(radius,battleTarget)
        local current=mobAt(battleTarget,radius)
        if current and current.hp>0 and current.allowed then return current end
        current=mobAt(AshitaCore:GetMemoryManager():GetTarget():GetTargetIndex(0),radius)
        if current and current.hp>0 and current.allowed then return current end
        local best
        for index=1,2303 do
            local mob=mobAt(index,radius)
            if mob and mob.hp>0 and mob.allowed and (not best or mob.distance<best.distance) then best=mob end
        end
        return best
    end,summon=chooseSummon,pull=choosePull})
local function setFarm(enabled)
    if not enabled then stop('Farm OFF.'); return end
    local context=autoContext()
    if not context then say('Log in on SMN main/sub before enabling Farm.'); return end
    setAuto(true); farm:start(context)
    say('Farm ON: nearby targets within 20 yalms; stops after a kill without XP. Stop disables all automation.')
end
local function farmSnapshot()
    local context=autoContext(); if not context then return end
    local m=AshitaCore:GetMemoryManager(); local p,party,e=m:GetPlayer(),m:GetParty(),m:GetEntity()
    local index=party:GetMemberTargetIndex(0); local pet=e:GetPetTargetIndex(index)
    local snap=snapshot(); local b=buffs(); local blocked=false
    for _,id in ipairs({2,6,7,10,14,16,17,19,28,29}) do if b[id] then blocked=true end end
    return {context=context,hp=party:GetMemberHP(0),mp=party:GetMemberMP(0),exp=p:GetExpCurrent(),level=p:GetMainJobLevel(),
        distance=snap and snap.distance or math.huge,selected=m:GetTarget():GetTargetIndex(0),battleTarget=e:GetTargetedIndex(index),status=e:GetStatusServer(index),
        pet=pet,petTarget=pet~=0 and e:GetTargetedIndex(pet) or 0,blocked=blocked,
        weak=snap and state.weak and state.weak.key==snap.key and now()-state.weak.time<=12 and state.weak.values or nil}
end
local function scan(run)
    if runner.active then if run then say('A sequence is already running.'); end; return end
    local s=snapshot()
    if not s then say('Use SMN main/sub, target a living monster, and wait for job data.'); return end
    if run then state.intent=s.key end
    if state.request and state.request.key==s.key and now()-state.request.time<4 then return end
    if now()<state.nextScan then
        if run then say('Waiting briefly for a fresh target scan.'); state.nextRunScan=true end
        return
    end
    state.nonce=state.nonce%99999998+1
    state.request={nonce=state.nonce,key=s.key,target=s.target,zone=s.zone,time=now(),parts={}}
    state.nextScan=now()+5
    queue(string.format('/say !crmm %d %d',s.target,state.nonce))
    if run then say('Checking current target resistance before starting.') end
end
local function telemetry(text)
    text=text:gsub('\30.',''):gsub('\31.',''):gsub('%z.*$','')
    local nonce,target,zone,part,body=text:match('%[CRMM1%] (%d+) (%d+) (%d+) ([12]) ([%d,;%-]+)%s*$')
    if not nonce then return false end
    local req,s=state.request,snapshot()
    if not req or not s or tonumber(nonce)~=req.nonce or tonumber(target)~=req.target or tonumber(zone)~=req.zone
        or req.key~=s.key or now()-req.time>4 then return true end
    local rows={}
    for row in body:gmatch('[^;]+') do
        local values={}; for value in row:gmatch('[^,]+') do values[#values+1]=tonumber(value) end
        if #values~=5 then return true end
        for _,v in ipairs(values) do if not v or math.abs(v)>1000000 then return true end end
        rows[#rows+1]=values
    end
    if #rows~=4 then return true end
    req.parts[tonumber(part)]=rows
    if req.parts[1] and req.parts[2] then
        local values={}; for _,chunk in ipairs(req.parts) do for _,v in ipairs(chunk) do values[#values+1]=v end end
        state.weak={key=s.key,time=now(),values=values}; state.request=nil
        rebuild(s)
        if state.intent==s.key then state.intent=nil; start(s)
        else state.message='Scan successful. Run combo = once; Auto = repeat; Farm = target, summon and fight.' end
    end
    return true
end
ashita.events.register('text_in','crmm_telemetry',function(e)
    -- Fallback only. Primary telemetry is read from the private server packet below,
    -- before game chat-channel remapping, timestamps, name prefixes and line splitting.
    if bit.band(e.mode or e.mode_modified or 0,255)~=6 then return end
    if telemetry(e.message or e.message_modified or '') then e.blocked=true end
end)
ashita.events.register('packet_in','crmm_actions',function(e)
    if e.id==0x017 and type(e.data)=='string' and #e.data>=24 and e.data:byte(5)==6 then
        -- CChatMessagePacket: server channel at 0x04, message at 0x17.
        if telemetry(e.data:sub(24)) then e.blocked=true end
        return
    end
    if e.id==0x00A or e.id==0x00B then
        stop('Zone changed.'); state.zoneUntil=now()+4; state.weak=nil; state.request=nil; state.plans={}; state.all={}; return
    end
    if e.id~=0x028 or not runner.active then return end
    local ok,p=pcall(packets.parse,e)
    if not ok then stop('Malformed action packet; sequence stopped.'); return end
    local kind=({[3]='ws',[4]='spell',[13]='pet'})[p.category]
    if not kind then return end
    for _,target in ipairs(p.targets) do
        local a=target.actions[1]
        if a then
            local success=({[2]=true,[110]=true,[185]=true,[187]=true,[317]=true,[252]=true,[264]=true})[a.message] or false
            runner:action({actor=p.actor,target=target.id,id=p.id,kind=kind,success=success,
                effect=a.effect and a.effectMessage==287+a.effect and a.effect or nil,burst=a.message==252,
                chainAction=kind=='ws' or (kind=='pet' and data.pets[p.id]~=nil) or (a.effect and a.effectMessage==287+a.effect)})
        end
    end
end)
ashita.events.register('packet_out','crmm_target_guard',function(e)
    local utility=state.utilityGuard
    if utility and e.id==0x01A and type(e.data)=='string' and #e.data>=14 then
        local category=e.data:byte(11); local id=e.data:byte(13)+e.data:byte(14)*256
        if category==utility.category and (category==2 or id==utility.id) then
            local index=e.data:byte(9)+e.data:byte(10)*256; local s=snapshot()
            if utility.generation~=(state.generation or 0) or now()>utility.expires or not s or s.key~=utility.key or index~=utility.target then
                e.blocked=true; stop('Queued support action cancelled: target or automation changed.')
            end
            state.utilityGuard=nil
            if e.blocked then return end
        end
    end
    if farm.enabled and farm.target and e.id==0x01A and type(e.data)=='string' and #e.data>=14 then
        local index=e.data:byte(9)+e.data:byte(10)*256
        local category=e.data:byte(11)
        local own=AshitaCore:GetMemoryManager():GetParty():GetMemberTargetIndex(0)
        if (category==2 or category==3 or category==7 or category==9) and index~=own then
            local mob=mobAt(farm.target.index,farm.radius)
            if index~=farm.target.index or not mob or mob.id~=farm.target.id or mob.hp<=0 or not mob.allowed then
                e.blocked=true; stop('Farm OFF: outgoing action target changed.'); return
            end
        end
    end
    local guard=state.guard
    if not guard then return end
    if e.id~=0x01A or type(e.data)~='string' or #e.data<14 then return end
    local category=e.data:byte(11)
    local id=e.data:byte(13)+e.data:byte(14)*256
    if category~=({ws=7,pet=9,spell=3})[guard.kind] or id~=guard.id then return end
    local index=e.data:byte(9)+e.data:byte(10)*256
    local s=snapshot()
    if now()>guard.expires or not runner.active or not s or s.key~=guard.key or index~=guard.targetIndex then
        e.blocked=true; stop('Queued action cancelled: target or sequence changed.')
    end
    state.guard=nil
end)
ashita.events.register('command','crmm_command',function(e)
    local args=e.command:lower():match('^/crmm%s+(.-)%s*$')
    if e.command:lower()=='/crmm' then e.blocked=true; state.visible=not state.visible; return end
    if not args then return end
    e.blocked=true
    if args=='scan' then state.auto=true; scan(false)
    elseif args=='run' then scan(true)
    elseif args=='farm' then setFarm(not farm.enabled)
    elseif args=='farm on' then setFarm(true)
    elseif args=='farm off' then setFarm(false)
    elseif args=='auto' then setAuto(not state.combatAuto)
    elseif args=='auto on' then setAuto(true)
    elseif args=='auto off' then setAuto(false)
    elseif args=='stop' then stop('Stopped.'); state.auto=false
    elseif args=='show' then state.visible=true
    elseif args=='hide' then state.visible=false
    else say('Commands: scan | run | auto [on|off] | farm [on|off] | stop | show | hide') end
end)
local function describe(plan)
    return plan.first.name..' > '..plan.second.name..' > '..core.names[plan.chain]..' > '..(plan.spell and plan.spell.name or '(no player burst)')
end
local function tick()
    if now()<(state.poll or 0) then return end
    state.poll=now()+0.15
    runner:tick()
    if state.combatAuto and state.autoContext~=autoContext() then stop('Auto combo OFF: character, job or zone changed.') end
    local s=snapshot()
    if not s or (state.snapshot and state.snapshot.key~=s.key) then
        if state.intent then stop('Target or character changed before start.') end
        state.plans={}; state.all={}; state.weak=nil; state.request=nil; state.snapshot=s
    end
    if state.request and now()-state.request.time>4 then
        state.request=nil; state.intent=nil
        state.message='No live resistance reply. Check the server crmm command; Run is disabled until a scan succeeds.'
    end
    if s and not runner.active then
        if state.weak and state.weak.key==s.key and now()>=(state.nextPlan or 0) then rebuild(s); state.nextPlan=now()+1 end
        if (state.auto or state.nextRunScan) and now()>=state.nextScan then state.nextRunScan=nil; scan(false) end
    end
    local farmReady=true
    if farm.enabled and not runner.active then farmReady=farm:tick(farmSnapshot()) end
    if state.combatAuto then
        if farm.enabled and not farmReady then state.autoStatus=farm.status
        elseif runner.active then state.autoStatus='Running combo; waiting for confirmed actions.'
        elseif not s or s.status~=1 then state.autoStatus='Waiting: engage a living monster.'
        elseif s.battleTarget~=s.targetIndex then state.autoStatus='Waiting: select the monster you are attacking.'
        elseif s.pet~=0 and AshitaCore:GetMemoryManager():GetEntity():GetTargetedIndex(s.petIndex)~=s.targetIndex then
            state.autoStatus='Directing avatar Assault to your selected combat target.'
            if now()>=(state.nextAssault or 0) then utilityCommand('/pet \"Assault\" <t>'); state.nextAssault=now()+5 end
        elseif now()<(state.autoNotBefore or 0) then state.autoStatus='Waiting for action recovery.'
        elseif not state.weak or state.weak.key~=s.key or now()-state.weak.time>4 then state.autoStatus='Waiting for a fresh target scan.'
        elseif now()>=(state.nextAutoCheck or 0) then
            state.nextAutoCheck=now()+1
            start(s,true)
        end
    end
end
ashita.events.register('d3d_present','crmm_panel',function()
    local ok,err=pcall(tick)
    if not ok then stop('Error: '..tostring(err)); state.auto=false end
    if not state.visible then return end
    imgui.SetNextWindowSize({650,620},ImGuiCond_FirstUseEver)
    if imgui.Begin('crmm | Summoner chain and burst',nil) then
        if imgui.Button('Scan') then state.auto=true; scan(false) end
        imgui.SameLine()
        if imgui.Button('Run combo') then scan(true) end
        imgui.SameLine()
        if imgui.Button('Stop') then stop('Stopped.'); state.auto=false end
        imgui.SameLine()
        if imgui.Button(state.combatAuto and 'Auto combo: ON' or 'Auto combo: OFF') then setAuto(not state.combatAuto) end
        imgui.SameLine()
        if imgui.Button(farm.enabled and 'Farm: ON' or 'Farm: OFF') then setFarm(not farm.enabled) end
        if farm.enabled then imgui.TextWrapped('FARM: '..farm.status) end
        if state.combatAuto then imgui.TextWrapped('AUTO: '..(state.autoStatus or 'Waiting.')) end
        imgui.TextWrapped(state.message)
        local s=snapshot()
        if s then
            imgui.Text(string.format('Target: %s | Avatar: %s | TP %d/1000 | MP %d',s.targetName,s.avatar~='' and s.avatar or 'none - summon one yourself',s.tp,s.mp))
            if state.weak and state.weak.key==s.key then
                imgui.Text(string.format('SCAN OK | %.1fs ago',now()-state.weak.time))
                local labels={}
                for i,v in ipairs(state.weak.values) do
                    local label=not core.elementScore(v) and 'Avoid' or (v[1]<0 or v[2]<0) and 'Weak' or (v[1]>0 or v[2]>0) and 'Resistant' or 'Neutral'
                    labels[#labels+1]=core.elements[i]..': '..label
                end
                imgui.TextWrapped(table.concat(labels,' | '))
                if imgui.CollapsingHeader('Resistance details') then
                    for i,v in ipairs(state.weak.values) do
                        imgui.Text(string.format('%-9s rank %+d | damage x%.2f | MEVA %+d',core.elements[i],v[1],math.max(0,math.min(3,1-v[2]/10000)),v[3]))
                    end
                end
            end
            imgui.Separator()
            imgui.Text('Current avatar: best ready combination')
            if state.available then imgui.TextWrapped(state.available) end
            local shown=state.combatAuto and state.autoPlan or state.plans[1]
            if shown then
                imgui.TextWrapped(describe(shown))
                imgui.Text('Burst element: '..core.elements[shown.element])
                if not shown.spell then imgui.TextWrapped('Chain only for your current jobs. Shantotto II can use the resulting burst window; crmm does not command trusts.') end
            else imgui.TextWrapped('No ready plan. Scan, summon an avatar, and check learned skills, MP and Rage cooldown.') end
            imgui.Separator()
            imgui.Text('Learned summons (level-based previews; summon and Scan to verify)')
            for _,entry in ipairs(state.all) do
                imgui.TextWrapped(entry.name..': '..(entry.plan and describe(entry.plan) or 'No chain-capable pact / compatible skill available.'))
            end
        else imgui.TextWrapped('SMN main/sub and a living monster target are required.') end
        imgui.Separator()
        imgui.TextWrapped('Run combo = once. Auto combo = wait for TP/MP/timers, then repeat while engaged. Farm adds nearby targeting, summoning, opening magic and Assault; stops after no XP. Stand still for bursts. Stop disables Auto. Player bursts use learned Tier I/II spells; Rage cooldown prevents a second ordinary pact burst.')
        imgui.TextWrapped('Resistance modifiers guide the choice; scripted absorptions, stances and special battle rules may override them. Scan is read-only. Stop cancels remaining actions, not actions already sent.')
    end
    imgui.End()
end)
ashita.events.register('unload','crmm_unload',function() state.intent=nil; runner.active=nil end)
