local M={}
M.elements={'Fire','Ice','Wind','Earth','Lightning','Water','Light','Dark'}
M.names={'Transfixion','Compression','Liquefaction','Scission','Reverberation','Detonation','Induration','Impaction',
    'Gravitation','Distortion','Fusion','Fragmentation','Light','Darkness','Light II','Darkness II'}
M.burst={{7},{8},{1},{4},{6},{3},{2},{5},{4,8},{2,6},{1,7},{3,5},{1,3,5,7},{2,4,6,8},{7},{8}}
M.effects={11,7,8,12,10,13,9,14,3,5,6,4,1,2,1,2}
function M.chain(data,a,b)
    -- The server prioritizes opening properties, then closing properties.
    for _,x in ipairs(a.props) do
        for _,y in ipairs(b.props) do
            if data.chains[x] and data.chains[x][y] then return data.chains[x][y] end
        end
    end
end
function M.castable(spell,s)
    local m,sub=spell.jobs[s.main] or 255,spell.jobs[s.sub] or 255
    return (m>0 and m<255 and m<=s.level) or (sub>0 and sub<255 and sub<=s.sublevel)
end
function M.elementScore(v)
    if not v or v[4]>0 or v[5]>=100 or v[2]>=10000 then return nil end
    -- Relative recommendation, not a prediction of damage or a guaranteed weakness.
    return -v[1]*100-v[2]/100-v[3]/10-v[5]*2
end
function M.plan(data,weapons,pacts,spells,weak,mp)
    local plans={}
    for _,w in ipairs(weapons) do for _,p in ipairs(pacts) do
        for order=1,2 do
            local a,b=order==1 and w or p,order==1 and p or w
            local sc=M.chain(data,a,b)
            if sc then
                local best,element,score=nil,nil,-math.huge
                for _,e in ipairs(M.burst[sc]) do
                    local value=M.elementScore(weak[e])
                    if value then
                        local spell
                        for _,candidate in ipairs(spells) do
                            if candidate.element==e and candidate.mp+p.mp<=mp
                                and (not spell or candidate.tier>spell.tier or (candidate.tier==spell.tier and candidate.mp<spell.mp)) then spell=candidate end
                        end
                        local rank=value+(spell and 10000 or 0)
                        if rank>score then best,element,score=spell,e,rank end
                    end
                end
                if element and p.mp<=mp then
                    plans[#plans+1]={first=a,second=b,spell=best,element=element,chain=sc,avatar=p.avatar,
                        score=score+(sc>=13 and 30 or sc>=9 and 20 or 10)-p.mp/1000}
                end
            end
        end
    end end
    table.sort(plans,function(a,b)
        if a.score~=b.score then return a.score>b.score end
        if a.first.id~=b.first.id then return a.first.id<b.first.id end
        return a.second.id<b.second.id
    end)
    return plans
end
-- One finite sequence per click, advanced only by matching server action results.
function M.runner(env)
    local r={env=env}
    function r:stop(reason,success)
        local wasActive=self.active~=nil
        self.active=nil; self.env.message(reason or 'Stopped.')
        if wasActive and self.env.finished then self.env.finished(success==true) end
    end
    function r:send(action,phase)
        local ok,reason=self.env.ready(action,self.active)
        if not ok then self:stop(reason); return end
        self.phase=phase; self.deadline=self.env.now()+12
        self.expected=action
        self.env.send(action)
    end
    function r:start(plan,identity)
        if self.active then return false end
        self.active={plan=plan,identity=identity}
        self:send(plan.first,'open')
        return self.active~=nil
    end
    function r:tick()
        if not self.active then return end
        local ok,reason=self.env.valid(self.active)
        if not ok then self:stop(reason); return end
        local now=self.env.now()
        if now>self.deadline then self:stop('Timed out waiting for confirmed action; no further commands sent.'); return end
        if self.phase=='wait_close' and now>=self.due then self:send(self.active.plan.second,'close')
        elseif self.phase=='wait_burst' and now>=self.due then self:send(self.active.plan.spell,'burst') end
    end
    function r:action(event)
        if not self.active then return end
        if self.env.now()>self.deadline then self:stop('Action arrived after the sequence deadline.'); return end
        local ok,reason=self.env.valid(self.active)
        if not ok then self:stop(reason); return end
        local identity=self.active.identity
        if event.target~=identity.target then return end
        local expected=self.expected
        if event.actor~=expected.actor or event.id~=expected.id or event.kind~=expected.kind then
            if event.chainAction then self:stop('Another skillchain action changed this target; rescan and run again.') end
            return
        end
        if self.phase~='open' and self.phase~='close' and self.phase~='burst' then return end
        if not event.success then self:stop('Action failed or missed; sequence stopped.'); return end
        local now=self.env.now()
        if self.phase=='open' then
            self.phase='wait_close'; self.due=now+3.3; self.deadline=now+8
            self.env.message('Opener confirmed; timing the closer.')
        elseif self.phase=='close' then
            if event.effect~=M.effects[self.active.plan.chain] then self:stop('Expected skillchain was not confirmed; burst cancelled.'); return end
            if not self.active.plan.spell then self:stop('Skillchain confirmed. No usable player burst spell for this chain.',true); return end
            self.phase='wait_burst'; self.due=now+1; self.deadline=now+7
            self.env.message('Skillchain confirmed; preparing magic burst.')
        else
            self:stop(event.burst and 'Magic burst confirmed. Sequence complete.' or 'Spell completed, but the server did not confirm a magic burst.',event.burst)
        end
    end
    return r
end
return M
