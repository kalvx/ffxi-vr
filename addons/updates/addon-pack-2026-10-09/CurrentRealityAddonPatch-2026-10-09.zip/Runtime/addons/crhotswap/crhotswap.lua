addon.name='crhotswap'
addon.author='Current Reality'
addon.version='1.2.0'
addon.desc='Personal job-aware gear and recovery buttons.'
require('common')
local bit=require('bit')
local imgui=require('imgui')
local core=require('crhs_core')
local config=require('crhs_config')
local data=require('crhs_data')
local settings=require('settings')
local saved=settings.load(T{choices=T{},magicTypes=T{}})
local ffi=require('ffi')
ffi.cdef('unsigned long __stdcall GetTickCount(void);')
local function now() return tonumber(ffi.C.GetTickCount())/1000 end
local state={visible=true,view='idle',message='Press Scan to inspect your gear.',candidates={},
    plans={},queue={},next=0,zoneUntil=0,job='',unknown=0,restricted=0}
settings.register('settings','crhotswap_settings',function(s)
    saved=s; state.plans={}; state.queue={}; state.pending=nil; state.editSlot=nil
end)
local function fingerprint(c)
    local extra=(c.extra or ''):gsub('.',function(b) return string.format('%02x',b:byte()) end)
    return tostring(c.id)..':'..c.bag..':'..extra
end
local function choiceKey(s,mode,slot) return s.character..':'..core.profile(s)..':'..mode..':'..slot end
local function magicPreferenceKey(s) return s.character..':'..core.profile(s) end
local function magicMode(s)
    local kind=saved.magicTypes[magicPreferenceKey(s)] or 'auto'
    return 'magic_'..(kind=='auto' and core.autoMagic(s) or kind)
end
local function resolvePins(s,mode,found)
    local pins,missing={},{}
    for slot=4,15 do
        local wanted=saved.choices[choiceKey(s,mode,slot)]
        if wanted then
            for _,c in ipairs(found) do
                if fingerprint(c)==wanted and bit.band(c.slots,2^slot)~=0 then pins[slot]=c; break end
            end
            if not pins[slot] then missing[#missing+1]=core.slots[slot] end
        end
    end
    return pins,missing
end
local function say(message) state.message=message; print('[crhotswap] '..message) end
local function snapshot()
    local mem=AshitaCore:GetMemoryManager()
    local p,party=mem:GetPlayer(),mem:GetParty()
    local index=party:GetMemberTargetIndex(0)
    if p:GetLoginStatus()~=2 or party:GetMemberIsActive(0)==0 or index==0 or now()<state.zoneUntil or state.inventoryReady==false then return nil end
    local s={main=p:GetMainJob(),sub=p:GetSubJob(),level=p:GetMainJobLevel(),sublevel=p:GetSubJobLevel(),
        su=p:GetSuLevel(),mp=p:GetMPMax(),character=party:GetMemberServerId(0),zone=party:GetMemberZone(0),
        hp=party:GetMemberHP(0),status=mem:GetEntity():GetStatusServer(index),race=mem:GetEntity():GetRace(index)}
    if s.main<1 or s.main>22 or s.level<1 then return nil end
    s.key=table.concat({s.character,s.zone,s.main,s.sub,s.level,s.sublevel,s.su},':')
    return s
end
local function equipped()
    local inv=AshitaCore:GetMemoryManager():GetInventory()
    local result={}
    for slot=0,15 do
        local entry=inv:GetEquippedItem(slot)
        if entry and entry.Index>0 then
            local bag,index=math.floor(entry.Index/256),entry.Index%256
            result[slot]={bag=bag,index=index}
        end
    end
    return result
end
local function currentIs(slot,c)
    local e=AshitaCore:GetMemoryManager():GetInventory():GetEquippedItem(slot)
    return e and e.Index==c.bag*256+c.index
end
local function scan(quiet)
    local s=snapshot()
    if not s then if not quiet then say('Log in and wait for inventory to load.') end; return false end
    local inv=AshitaCore:GetMemoryManager():GetInventory()
    local eq=equipped()
    local eqMap={}
    state.currentRestricted=false
    for slot,entry in pairs(eq) do
        eqMap[core.key(entry)]=slot
        local item=inv:GetContainerItem(entry.bag,entry.index)
        local d=item and data.items[item.Id]
        if slot>=4 and d and d.blocked~=0 then state.currentRestricted=true end
    end
    local found,unknown,restricted={},0,0
    for bag=0,16 do
        if core.bags[bag] then
            local capacity=math.min(80,inv:GetContainerCountMax(bag))
            for index=1,capacity do
                local item=inv:GetContainerItem(bag,index)
                if item and item.Id>0 and item.Count>0 and item.Flags~=19 then
                    local res=AshitaCore:GetResourceManager():GetItemById(item.Id)
                    local d=data.items[item.Id]
                    if res and bit.band(res.Flags,0x800)~=0 and bit.band(res.Slots,0xFFF0)~=0 then
                        if not d then unknown=unknown+1
                        elseif d.blocked~=0 then restricted=restricted+1
                        elseif core.eligible(d,s) then
                            local mods={}
                            for k,v in pairs(d.mods) do mods[k]=v end
                            for k,v in pairs(config.overrides[item.Id] or {}) do mods[k]=v end
                            found[#found+1]={id=item.Id,bag=bag,index=index,extra=item.Extra,name=res.Name[1],
                                slots=d.slots,mods=mods,equipped=eqMap[bag..':'..index]}
                        end
                    end
                end
            end
        end
    end
    state.candidates=found; state.unknown=unknown; state.restricted=restricted
    state.snapshot=s; state.job=core.profile(s); state.plans={}
    state.missing={}
    for _,mode in ipairs(core.modes) do
        local pins,missing=resolvePins(s,mode,found)
        state.plans[mode]=core.plan(found,mode,s,config,pins)
        state.missing[mode]=missing
    end
    if not quiet then say(string.format('%s %d/%d: %d eligible pieces scanned.',state.job,s.level,s.sublevel,#found)) end
    return true
end
local function stop(message)
    state.queue={}; state.pending=nil
    if message then say(message) end
end
local function rest(s)
    if s.status==33 then say('Recovery gear confirmed; already resting.'); return end
    AshitaCore:GetChatManager():QueueCommand(1,'/heal on')
    say('Recovery gear confirmed; resting requested. The game may refuse if you are moving or otherwise unable to rest.')
end
local function apply(mode)
    stop()
    if not scan(true) then say('Log in and wait for inventory to load.'); return end
    local s=state.snapshot
    if mode=='magic' then mode=magicMode(s) end
    if not core.validMode(mode) then say('Unknown gear mode.'); return end
    state.view=mode
    if #state.missing[mode]>0 then say('Saved choice unavailable: '..table.concat(state.missing[mode],', ')..'. Click its row and choose Auto or a replacement.'); return end
    if s.hp<=0 or (s.status~=0 and s.status~=1 and s.status~=33) then say('Cannot switch gear in this character state.'); return end
    if mode=='rest' and s.status==1 then say('Disengage before pressing Rest.'); return end
    if state.currentRestricted then say('Remove multi-slot costume/armor before switching; its occupied slots are protected.'); return end
    state.view=mode
    local target=state.plans[mode]
    -- Moving an already equipped earring/ring requires releasing its old slot first.
    for slot=4,15 do
        local c=target[slot]
        if c and c.equipped and c.equipped~=slot then
            state.queue[#state.queue+1]={slot=c.equipped,item=c,remove=true}
        end
    end
    for slot=4,15 do
        local c=target[slot]
        if c and not currentIs(slot,c) then state.queue[#state.queue+1]={slot=slot,item=c} end
    end
    if #state.candidates==0 then say('No eligible gear found. Wait for bags to load, then Scan.'); return end
    if #state.queue==0 then
        if mode=='rest' then rest(s) else say(mode..' gear already equipped.') end
        return
    end
    state.pending={key=s.key,target=target,mode=mode,verifyAt=nil}
    state.next=now()
    say(string.format('Applying %s: %d changes for %s.',mode,#state.queue,state.job))
end
local function tick()
    local t=now()
    if t<(state.poll or 0) then return end
    state.poll=t+0.1
    local s=snapshot()
    if not s then
        if state.pending then stop('Swap cancelled: character or zone unavailable.') end
        state.job=''; state.plans={}; return
    end
    if state.snapshot and state.snapshot.key~=s.key then
        stop('Job, level, character or zone changed. Press Scan or a gear button.')
        state.plans={}; state.candidates={}; state.snapshot=nil
    end
    state.job=core.profile(s)
    local pending=state.pending
    if not pending then return end
    if pending.key~=s.key or s.hp<=0 or (s.status~=0 and s.status~=1 and s.status~=33) or (pending.mode=='rest' and s.status==1) then
        stop('Swap cancelled: character state changed.'); return
    end
    if #state.queue>0 and t>=state.next then
        local entry=table.remove(state.queue,1)
        local c=entry.item
        local live=AshitaCore:GetMemoryManager():GetInventory():GetContainerItem(c.bag,c.index)
        if not live or live.Id~=c.id or live.Count<1 or live.Flags==19 or live.Extra~=c.extra then
            stop('Inventory changed during swap. Press the gear button again.'); return
        end
        if entry.remove then
            if not currentIs(entry.slot,c) then stop('Equipment changed during swap. Press the gear button again.'); return end
            AshitaCore:GetPacketManager():AddOutgoingPacket(0x50,{0,0,0,0,0,entry.slot,c.bag,0})
        elseif not currentIs(entry.slot,c) then
            AshitaCore:GetPacketManager():AddOutgoingPacket(0x50,{0,0,0,0,c.index,entry.slot,c.bag,0})
        end
        state.next=t+0.2
        if #state.queue==0 then pending.verifyAt=t+2 end
    elseif pending.verifyAt and t>=pending.verifyAt then
        local failures={}
        for slot,c in pairs(pending.target) do
            if not currentIs(slot,c) then failures[#failures+1]=core.slots[slot] end
        end
        state.pending=nil
        if #failures>0 then say('Not confirmed: '..table.concat(failures,', ')..'. Check gear locks/bag access or another gear addon.')
        elseif pending.mode=='rest' then rest(s)
        else say(pending.mode..' gear equipped and confirmed for '..state.job..'.') end
    end
end
local function preview(mode)
    stop()
    if scan(true) then
        if mode=='magic' then mode=magicMode(state.snapshot) end
        state.view=mode
        say('Preview '..mode..' for '..state.job..' (nothing equipped).')
        for slot=4,15 do
            local c=state.plans[mode][slot]
            if c then print(string.format('[crhotswap] %s: %s (%s)',core.slots[slot],c.name,core.bags[c.bag])) end
        end
    else say('Log in and wait for inventory to load.') end
end
ashita.events.register('command','crhotswap_command',function(e)
    local args=e.command:lower():match('^/crhotswap%s*(.*)$')
    if args==nil or (e.command:sub(11,11)~='' and not e.command:sub(11,11):match('%s')) then return end
    e.blocked=true; args=args:match('^%s*(.-)%s*$')
    if args=='' then state.visible=not state.visible
    elseif args=='def' then apply('defense')
    elseif args=='magic' or core.validMode(args) then apply(args)
    elseif args:match('^magic %a+$') and core.validMode('magic_'..args:sub(7)) then apply('magic_'..args:sub(7))
    elseif args=='scan' then stop(); scan(false)
    elseif args=='stop' then stop('Stopped.')
    elseif args=='show' then state.visible=true
    elseif args=='hide' then state.visible=false
    elseif args:match('^preview ') then
        local mode=args:sub(9):gsub('^magic ','magic_')
        if mode=='magic' or core.validMode(mode) then preview(mode) else say('Unknown preview mode.') end
    else say('Commands: idle | rest | attack | magic [school] | defense | evasion | scan | preview <mode> | show | hide | stop') end
end)
ashita.events.register('packet_in','crhotswap_zone',function(e)
    if e.id==0x01D and type(e.data)=='string' and e.data:byte(5)==1 then state.inventoryReady=true end
    if e.id==0x00A or e.id==0x00B then
        stop(); state.inventoryReady=false; state.zoneUntil=now()+3; state.plans={}; state.candidates={}; state.snapshot=nil
        state.message='Zone changed. Wait for bags, then press Scan or a gear button.'
    end
end)
ashita.events.register('d3d_present','crhotswap_panel',function()
    local ok,err=pcall(tick)
    if not ok then stop('Error: '..tostring(err)) end
    if not state.visible then return end
    imgui.SetNextWindowSize({540,640},ImGuiCond_FirstUseEver)
    if imgui.Begin('crhotswap | Current Reality',nil) then
        imgui.Text('Job: '..(state.job~='' and state.job or 'Waiting for character'))
        imgui.Text('Manual switching | Weapons preserved')
        if imgui.Button('Idle',{130,32}) then apply('idle') end
        imgui.SameLine()
        if imgui.Button('Attack',{130,32}) then apply('attack') end
        imgui.SameLine()
        if imgui.Button('Stop',{70,32}) then stop('Stopped.') end
        imgui.SameLine()
        if imgui.Button('Rest',{70,32}) then apply('rest') end
        if imgui.Button('Magic',{130,32}) then apply('magic') end
        imgui.SameLine()
        if imgui.Button('Defense',{130,32}) then apply('defense') end
        imgui.SameLine()
        if imgui.Button('Evasion',{130,32}) then apply('evasion') end
        if imgui.Button('Scan') then stop(); scan(false) end
        imgui.SameLine()
        if imgui.Button('Preview Idle') then preview('idle') end
        imgui.SameLine()
        if imgui.Button('Preview Attack') then preview('attack') end
        if imgui.Button('Preview Magic') then preview('magic') end
        imgui.SameLine()
        if imgui.Button('Preview Defense') then preview('defense') end
        imgui.SameLine()
        if imgui.Button('Preview Evasion') then preview('evasion') end
        if imgui.Button('Preview Rest') then preview('rest') end
        if state.snapshot and state.plans.idle then
            local prefKey=magicPreferenceKey(state.snapshot)
            local kind=saved.magicTypes[prefKey] or 'auto'
            local label=kind=='auto' and ('Auto: '..core.autoMagic(state.snapshot)) or kind
            if imgui.BeginCombo('Magic focus',label) then
                local kinds={'auto'}
                for _,v in ipairs(core.magicTypes) do kinds[#kinds+1]=v end
                for _,v in ipairs(kinds) do
                    if imgui.Selectable(v,v==kind) then
                        stop(); saved.magicTypes[prefKey]=v; settings.save()
                        state.view=magicMode(state.snapshot)
                        say('Magic focus set to '..v..'. Preview or press Magic to equip.')
                    end
                end
                imgui.EndCombo()
            end
        end
        imgui.Separator()
        imgui.TextWrapped(state.message)
        imgui.Text('Plan: '..state.view..' | '..#state.candidates..' eligible pieces')
        local plan=state.plans[state.view]
        if plan then
            for slot=4,15 do
                local c=plan[slot]
                local pinned=saved.choices[choiceKey(state.snapshot,state.view,slot)]~=nil
                if imgui.Selectable(string.format('%-5s  %s%s##slot%d',core.slots[slot],c and c.name or '(keep current)',pinned and ' [saved]' or '',slot),state.editSlot==slot) then
                    state.editSlot=slot
                end
                if c and imgui.IsItemHovered() then
                    imgui.SetTooltip(string.format('%s, slot %d | score %.1f\nHP %+d | Regen %+d | Refresh %+d | hHP %+d\nAttack %+d | Accuracy %+d | Speed %+d%%',
                        core.bags[c.bag],c.index,core.score(c,state.view,state.snapshot,config),
                        c.mods[2] or 0,c.mods[370] or 0,c.mods[369] or 0,c.mods[72] or 0,
                        c.mods[23] or 0,c.mods[25] or 0,c.mods[76] or 0))
                    if state.view=='rest' then
                        imgui.SetTooltip(string.format('%s | Score %.1f\nHealing HP %+d | Healing MP %+d\nRegen %+d | Refresh %+d',core.bags[c.bag],core.score(c,state.view,state.snapshot,config),c.mods[72] or 0,c.mods[71] or 0,c.mods[370] or 0,c.mods[369] or 0))
                    elseif state.view~='idle' and state.view~='attack' then
                        imgui.SetTooltip(string.format('%s | Score %.1f\nDEF %+d | EVA %+d | Evasion skill %+d\nMP %+d | Fast Cast %+d | Magic acc %+d | Magic attack %+d\nSummoning skill %+d | Perpetuation reduction %+d\nDamage taken %+.2f%% | Physical taken %+.2f%%',core.bags[c.bag],core.score(c,state.view,state.snapshot,config),
                            c.mods[1] or 0,c.mods[68] or 0,c.mods[108] or 0,c.mods[5] or 0,c.mods[170] or 0,c.mods[30] or 0,c.mods[28] or 0,
                            c.mods[117] or 0,c.mods[346] or 0,(c.mods[160] or 0)/100,(c.mods[161] or 0)/100))
                    end
                end
            end
        end
        if plan and state.editSlot then
            local slot=state.editSlot
            imgui.Separator()
            imgui.Text('Choose '..core.slots[slot]..' for '..state.job..' / '..state.view)
            local key=choiceKey(state.snapshot,state.view,slot)
            if imgui.Button('Use automatic choice') then
                stop(); saved.choices[key]=nil; settings.save(); scan(true)
                say('Automatic choice restored. Press '..state.view..' to equip.')
            end
            imgui.SameLine()
            if imgui.Button('Close choices') then state.editSlot=nil end
            local choices={}
            for _,c in ipairs(state.candidates) do if bit.band(c.slots,2^slot)~=0 then choices[#choices+1]=c end end
            table.sort(choices,function(a,b) return core.score(a,state.view,state.snapshot,config)>core.score(b,state.view,state.snapshot,config) end)
            for _,c in ipairs(choices) do
                if imgui.Selectable(string.format('%s | %s | %.1f##choice%s',c.name,core.bags[c.bag],core.score(c,state.view,state.snapshot,config),core.key(c)),false) then
                    stop()
                    -- A physical copy cannot be pinned to both ears/rings.
                    for other=4,15 do
                        local otherKey=choiceKey(state.snapshot,state.view,other)
                        if saved.choices[otherKey]==fingerprint(c) then saved.choices[otherKey]=nil end
                    end
                    saved.choices[key]=fingerprint(c); settings.save(); scan(true)
                    say('Saved '..c.name..' for '..state.job..' '..state.view..'. Press '..state.view..' to equip.')
                end
            end
        end
        imgui.Separator()
        imgui.TextWrapped('Inventory + Wardrobes 1-8. Recovery: Regen, Refresh (MP jobs), healing HP. Attack equips gear; it does not engage a target.')
        imgui.TextWrapped('Base server stats only; conditional effects and augments need overrides. Weapons/ammo and multi-slot armor are excluded.')
        if state.unknown>0 or state.restricted>0 then imgui.Text(string.format('Skipped: %d unknown, %d multi-slot.',state.unknown,state.restricted)) end
    end
    imgui.End()
end)
ashita.events.register('unload','crhotswap_unload',function() stop() end)
