local bit = require('bit')
local M = {}
M.magicTypes={'casting','healing','elemental','enfeebling','enhancing','divine','dark','summoning','ninjutsu','singing','blue','geomancy'}
M.modes={'idle','rest','attack','defense','evasion'}
for _,kind in ipairs(M.magicTypes) do M.modes[#M.modes+1]='magic_'..kind end
local jobMagic={[3]='healing',[4]='elemental',[5]='enfeebling',[7]='healing',[8]='dark',
    [10]='singing',[13]='ninjutsu',[15]='summoning',[16]='blue',[20]='enhancing',[21]='geomancy',[22]='enhancing'}
function M.autoMagic(s) return jobMagic[s.main] or jobMagic[s.sub] or 'casting' end
function M.validMode(mode)
    for _,v in ipairs(M.modes) do if v==mode then return true end end
    return false
end
M.slots = {[4]='head',[5]='body',[6]='hands',[7]='legs',[8]='feet',[9]='neck',
    [10]='waist',[11]='ear1',[12]='ear2',[13]='ring1',[14]='ring2',[15]='back'}
M.bags = {[0]='Inventory',[8]='Wardrobe 1',[10]='Wardrobe 2',[11]='Wardrobe 3',
    [12]='Wardrobe 4',[13]='Wardrobe 5',[14]='Wardrobe 6',[15]='Wardrobe 7',[16]='Wardrobe 8'}
M.jobs = {'WAR','MNK','WHM','BLM','RDM','THF','PLD','DRK','BST','BRD','RNG','SAM',
    'NIN','DRG','SMN','BLU','COR','PUP','DNC','SCH','GEO','RUN'}
function M.profile(s) return (M.jobs[s.main] or '?')..'/'..(M.jobs[s.sub] or 'NONE') end
function M.key(c) return c.bag..':'..c.index end
function M.eligible(d,s)
    return d and d.level<=s.level and d.su<=s.su and d.blocked==0
        and bit.band(d.jobs,2^(s.main-1))~=0
        and ((d.mods[276] or 0)==0 or bit.band(d.mods[276],2^(s.race-1))~=0)
end
function M.score(c,mode,s,config)
    local profile = config.profiles[M.profile(s)] or {}
    local magic=mode:match('^magic_(.+)$')
    local w = profile[mode] or (magic and profile.magic) or config[mode] or (magic and config.magic)
    local v = c.mods
    local function mod(id) return v[id] or 0 end
    if mode=='idle' then
        return mod(2)*w.hp + mod(3)*w.hpp + mod(370)*w.regen
            + (s.mp>0 and mod(369)*w.refresh or 0) + mod(72)*w.healing
    end
    if mode=='rest' then
        return mod(72)*w.healing_hp+mod(370)*w.regen+mod(2)*w.hp
            +(s.mp>0 and (mod(71)*w.healing_mp+mod(369)*w.refresh+mod(5)*w.mp) or 0)
    end
    if mode=='defense' then
        -- Server damage-taken modifiers are signed basis points: -500 = -5% damage.
        return mod(1)*w.defense+mod(63)*w.defense_percent+mod(10)*w.vit+mod(2)*w.hp
            -mod(160)/100*w.damage_reduction-mod(161)/100*w.physical_reduction
            -mod(163)/100*w.magic_reduction+mod(29)*w.magic_defense
    end
    if mode=='evasion' then
        return mod(68)*w.evasion+mod(108)*w.evasion_skill+mod(11)*w.agi+mod(2)*w.hp-mod(160)/100*w.damage_reduction
    end
    if magic then
        local score=mod(170)*w.fastcast+(s.mp>0 and (mod(5)*w.mp+mod(369)*w.refresh) or 0)
        local skills={healing=112,elemental=115,enfeebling=114,enhancing=113,divine=111,dark=116,
            summoning=117,ninjutsu=118,singing=119,blue=122,geomancy=123}
        if skills[magic] then score=score+mod(skills[magic])*w.skill end
        if magic=='summoning' then
            return score+mod(346)*w.perpetuation+(mod(357)+mod(541))*w.pact_delay
                +mod(126)*w.pact_damage+mod(1040)*w.avatar_level+mod(1078)*w.summoning_cast
        elseif magic=='healing' then
            return score+(mod(374)+mod(260))*w.potency+mod(13)*w.stat
        elseif magic=='enhancing' then
            return score
        elseif magic=='geomancy' then
            return score+mod(124)*w.skill
        elseif magic=='singing' then
            return score+mod(30)*w.accuracy+mod(14)*w.stat
        elseif magic=='enfeebling' then
            return score+mod(30)*w.accuracy+(mod(12)+mod(13))*w.stat
        elseif magic~='casting' then
            return score+mod(30)*w.accuracy+mod(28)*w.attack+mod(magic=='divine' and 13 or 12)*w.stat
        end
        return score
    end
    return mod(23)*w.attack + mod(25)*w.accuracy + mod(8)*w.str + mod(9)*w.dex
end
local function fits(c,slot) return bit.band(c.slots,2^slot)~=0 end
-- Exact two-slot assignment: one physical ring/earring cannot fill both slots.
local function choose(candidates,mode,s,config,forced,forcedSlot,pins)
    local set,total={},0
    local function value(c,slot)
        return M.score(c,mode,s,config) + (c.equipped==slot and 0.00001 or 0)
    end
    local function allowed(c,slot)
        for pinnedSlot,pinned in pairs(pins or {}) do
            if (slot==pinnedSlot and c~=pinned) or (slot~=pinnedSlot and M.key(c)==M.key(pinned)) then return false end
        end
        return fits(c,slot) and (not forced or M.key(c)~=M.key(forced) or slot==forcedSlot)
            and (slot~=forcedSlot or c==forced)
    end
    for slot=4,15 do
        if slot<11 or slot>14 then
            local best,score=nil,-math.huge
            for _,c in ipairs(candidates) do
                if allowed(c,slot) and value(c,slot)>score then best,score=c,value(c,slot) end
            end
            if best then set[slot]=best; total=total+score end
        end
    end
    for _,pair in ipairs({{11,12},{13,14}}) do
        local a,b=pair[1],pair[2]
        local left,right={false},{false}
        for _,c in ipairs(candidates) do
            if allowed(c,a) then left[#left+1]=c end
            if allowed(c,b) then right[#right+1]=c end
        end
        local best,ba,bb=-math.huge,nil,nil
        for _,x in ipairs(left) do for _,y in ipairs(right) do
            if (not x or not y or M.key(x)~=M.key(y))
                and (forcedSlot~=a or x==forced) and (forcedSlot~=b or y==forced) then
                local score=(x and value(x,a) or -1000000)+(y and value(y,b) or -1000000)
                if score>best then best,ba,bb=score,x,y end
            end
        end end
        set[a]=ba or nil; set[b]=bb or nil; total=total+best
    end
    return set,total
end
function M.plan(candidates,mode,s,config,pins)
    if mode~='idle' then return choose(candidates,mode,s,config,nil,nil,pins) end
    local function available(c,slot)
        if not fits(c,slot) then return false end
        for ps,pc in pairs(pins or {}) do
            if (slot==ps and c~=pc) or (slot~=ps and M.key(c)==M.key(pc)) then return false end
        end
        return true
    end
    local speed=0
    for _,c in ipairs(candidates) do for slot=4,15 do
        if available(c,slot) then speed=math.max(speed,c.mods[76] or 0) end
    end end
    if speed<=0 then return choose(candidates,mode,s,config,nil,nil,pins) end
    -- Movement speed does not stack: force one fastest piece, then optimize the rest.
    local best,bestScore=nil,-math.huge
    for _,c in ipairs(candidates) do
        if (c.mods[76] or 0)==speed then
            for slot=4,15 do if available(c,slot) then
                local set,score=choose(candidates,mode,s,config,c,slot,pins)
                if score>bestScore then best,bestScore=set,score end
            end end
        end
    end
    return best,bestScore
end
return M
