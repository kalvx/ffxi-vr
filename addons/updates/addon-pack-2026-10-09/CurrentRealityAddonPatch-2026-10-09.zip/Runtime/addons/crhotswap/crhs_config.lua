-- Personal settings. Reload crhotswap after editing.
return {
    -- Scores are tradeoffs, not promises of maximum HP and maximum recovery simultaneously.
    idle = { hp=1, hpp=10, regen=50, refresh=30, healing=8 },
    rest = { healing_hp=50, healing_mp=50, regen=30, refresh=30, hp=0.05, mp=0.05 },
    attack = { attack=1, accuracy=2, str=0.5, dex=0.75 },
    defense = { defense=1, defense_percent=5, vit=1, hp=0.2, damage_reduction=15, physical_reduction=10, magic_reduction=5, magic_defense=1 },
    evasion = { evasion=3, evasion_skill=3, agi=1.5, hp=0.05, damage_reduction=3 },
    -- Generic casting weights; each selected school adds the corresponding skill/effect weights.
    magic = { fastcast=4, mp=0.1, refresh=8, skill=3, accuracy=2, attack=3,
        potency=8, stat=1, perpetuation=35, pact_delay=5, pact_damage=5, avatar_level=25, summoning_cast=8 },
    -- These are separate profiles even when using the same default priorities.
    -- Example: ['THF/NIN'] = { attack={attack=1,accuracy=3,str=0.5,dex=0.75} }
    profiles = {},
    -- Add/replace unconditional modifier values by item ID, e.g. [12345]={[370]=2}.
    -- Use only known always-active values. Augments/latents are not inferred.
    overrides = {},
}
