# crhotswap

## Version 1.2: Rest

Reload with `/addon reload crhotswap`. **Rest** rescans your job and equipment, equips a separate recovery set, verifies the selected pieces, then sends `/heal on`. Stand still and disengage first; the game can refuse the rest command. Already resting stays resting. Idle remains a gear-only button. No automatic mode switching is added.

Rest prioritizes healing HP and, with an MP pool, healing MP, plus Regen/Refresh and small HP/MP weights. Movement speed is not forced. Base stats and saved item choices follow the same rules as other sets. Click a Rest gear row to save an alternative.

Use `/crhotswap rest`, `/console /crhotswap rest` in a game macro, or `/exec crhotswap-rest.txt`. **Preview Rest** and `/crhotswap preview rest` inspect without equipping or resting. Stop cancels pending swaps/rest requests before they are sent; it does not stand you up or undo gear changes. Failed equipment confirmation, unavailable saved choices, combat, zoning and character changes prevent a pending rest request.

The 1.2 portable package contains five addon files and all eight scripts. The previous addon files are backed up in `Backups/crhotswap-before-rest-20261004`; version 1.1's portable zip is also retained. Validation: 61 optimizer and mocked Ashita integration checks pass. Actual in-game rest behaviour still requires a live check after reload.

## Version 1.1: Magic, Defense and Evasion

Reload with `/addon reload crhotswap` to get the new buttons. **Scan** builds all sets without equipping. **Magic**, **Defense** and **Evasion** are manual gear switches with the same per-character/job/slot saved alternatives as Idle and Attack.

- **Magic focus:** Auto uses your main magic job, then your subjob: SMN/WHM selects summoning; THF/NIN selects ninjutsu; THF/WHM selects healing. The dropdown lets you choose casting, healing, elemental, enfeebling, enhancing, divine, dark, summoning, ninjutsu, singing, blue or geomancy. Selection is saved for the character and job combination. Choosing a focus only previews it; press Magic to equip. Each school keeps its own saved item choices.
- **Summoning:** summoning skill, perpetuation-cost reduction, Refresh/MP, Fast Cast, summoning casting-time reduction, Blood Pact delay/damage and avatar-level bonuses. Caster magic attack is not treated as avatar magic attack. Pet-only stat tables and conditional effects are not scored.
- **Other magic:** the selected school's skill plus relevant stats: Cure Potency/MND for healing; magic accuracy/attack and INT for elemental/dark/magical blue/ninjutsu; accuracy/INT/MND for enfeebling; enhancing skill for enhancing; singing skill/accuracy/CHR for singing; geomancy/handbell skill for geomancy. General casting focuses on Fast Cast and MP support. Ninjutsu is a general casting/offensive set, not a dedicated Utsusemi interruption set; Blue is for magical spells, not physical blue magic.
- **Defense:** DEF, defense percentage, VIT, HP, magic defense and damage-taken reductions. Signed server damage modifiers are converted correctly: -500 means -5% damage taken.
- **Evasion:** evasion, evasion skill and AGI, with smaller HP/damage-reduction weights. This is physical evasion, not a magic-evasion set.

These are weighted armor/accessory recommendations, not automatic precast/midcast swaps or spell casting. Weapons, shields, instruments and ammo remain unchanged. Caps, spell-specific conditions, set bonuses and augments are not simulated; use saved choices for those. No magic job means Auto uses neutral casting priorities; it does not grant spells or skill access. All weights are editable in `crhs_config.lua`.

New chat/script commands (prefix with `/console ` in an FFXI macro):

```text
/crhotswap magic
/crhotswap magic summoning
/crhotswap magic healing
/crhotswap defense
/crhotswap def
/crhotswap evasion
/crhotswap preview magic summoning
/crhotswap preview defense
/crhotswap preview evasion
```

Additional scripts: `crhotswap-magic.txt`, `crhotswap-summoning.txt`, `crhotswap-defense.txt`, `crhotswap-evasion.txt`. The version 1.1 portable package includes all seven scripts.

Personal Current Reality addon for Ashita v4. Load in the game chat:

```text
/addon load crhotswap
```

Click **Scan** first. It reads your character, current main/sub jobs and levels, and Inventory plus Mog Wardrobes 1–8. It builds Idle and Attack recommendations without equipping anything. Each gear button also rescans before acting. Safe, Storage, Locker, Satchel, Sack and Case are not directly equippable under the current server settings and are not included.

Click **Idle** or **Attack** to equip the selected plan. No automatic switching when combat starts/ends, and no equipping on load or Scan. Attack changes equipment only; use your normal attack command to engage a target. Main/sub weapons, ranged weapon and ammo stay unchanged.

Click a gear row to see alternatives, sorted by score. Choose an item to save it for this character, main/sub combination, mode and slot. Then press Idle/Attack to apply it. **Use automatic choice** removes the saved preference. An unavailable saved item blocks that set rather than silently replacing your preference. Saved selections identify the item, bag and extra-data fingerprint, so reordering a bag does not lose them. Moving it to another bag requires selecting it again. Two identical copies can be auto-selected for paired slots; a saved preference identifies one matching copy.

## Macros and scripts

Commands (game chat or Ashita command input):

```text
/crhotswap scan
/crhotswap idle
/crhotswap attack
/crhotswap preview idle
/crhotswap preview attack
/crhotswap stop
/crhotswap show
/crhotswap hide
```

`/crhotswap` toggles the panel. Preview also prints the set to chat. All controls are manual.

Use these FFXI macro lines through Ashita's console forwarding:

```text
/console /crhotswap scan
/console /crhotswap idle
/console /crhotswap attack
```

Put each line in its own macro, labelled SCAN / IDLE / ATTACK. Controller users can select these through the normal FFXI macro palette. For Ashita scripts, the installed scripts are `crhotswap-scan.txt`, `crhotswap-idle.txt` and `crhotswap-attack.txt`; run e.g. `/exec crhotswap-idle.txt`. Load the addon first. Startup files and existing key bindings are untouched.

## Gear selection

The bundled data is a read-only snapshot of **14,874 equipment definitions** from this Current Reality server's database. Job eligibility uses the **main job**, current level, Superior requirement and server race restriction. The subjob selects your personal profile and contributes to the character's current MP capability; it does not grant permission to wear another job's armor.

- **Idle:** forces one available piece with the highest unconditional gear movement-speed bonus, unless a saved slot choice prevents it. Optimizes remaining pieces for HP and recovery. Default score: HP + 10 × HP% + 50 × Regen + 30 × Refresh (only with an MP pool) + 8 × healing HP. Healing HP works while resting, not standing. Gear movement speed does not stack, so it is considered once.
- **Attack:** Attack + 2 × Accuracy + 0.5 × STR + 0.75 × DEX. These are transparent selection priorities, not a full damage simulator.
- Earring/ring pairs use distinct physical copies. Existing placement breaks ties. Moving a worn item to the other paired slot first releases it.

Edit `crhs_config.lua` to adjust the weights, add a profile such as `THF/NIN` or `THF/DNC`, or supply known item modifier overrides. Reload the addon after editing. HP and recovery compete; the default balances them rather than claiming both independent maxima. HP% uses a fixed score of 10 per percent, not an exact computed final-HP value.

**Limits:** auto-scoring uses unconditional base item modifiers. Augments, set bonuses, latent effects, item scripts, day/night conditions and enchantments are not evaluated. Choose such items manually when their real benefit is better. Multi-slot armor/costumes are excluded, and wearing one blocks switching until you remove it. Unknown items are skipped and counted. Items in the bazaar are skipped. The server remains authoritative about equip locks and bag availability; the addon reports any unconfirmed slots instead of claiming success.

Swaps are paced, cancelled on job/character/zone/state changes, and checked against the original bag item before every equip request. Inventory completion is awaited after zoning. Stop cancels unsent requests; it does not undo pieces already equipped. Avoid running another automatic gear addon that changes the same slots at the same time.

## Personal settings and another device

Ashita saves choices beneath `config/addons/crhotswap/<character>_<id>/`. For another Ashita v4 installation (including a ROG Ally), copy the `addons/crhotswap` folder, the three scripts and your `config/addons/crhotswap` folder. Load with the same command. No server access or Python is needed to run the addon. The portable zip includes the addon and scripts; copy your personal settings after you make selections.

Refresh the server-stat snapshot on this development PC with:

```text
python F:\FFXIServerComplete\tools\export_crhotswap.py
```

This helper only SELECTs equipment/modifier definitions; it does not export credentials or character data. Reload the addon after refreshing.

## Verification

`tests/run.py` runs optimizer and simulated Ashita integration tests using this workspace's existing LuaJIT DLL. It checks job/level/race restrictions, stat priorities, ring uniqueness, manual preferences, read-only Scan/Preview, packet layout, inventory changes, zoning, cancellation, and equipment acknowledgement. The actual in-game panel and live equip behaviour still need an Ashita session check.

API references: [Ashita equipmon](https://github.com/AshitaXI/Ashita-v4beta/blob/main/addons/equipmon/equipmon.lua), [LuAshitacast equipment packet implementation](https://github.com/ThornyFFXI/LuAshitacast/blob/main/equip.lua). Packet fields were also checked against this server's `SmallPacket0x050` implementation.
