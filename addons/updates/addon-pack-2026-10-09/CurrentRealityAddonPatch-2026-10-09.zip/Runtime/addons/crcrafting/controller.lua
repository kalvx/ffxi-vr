local M={};

function M.new()
    return {running=false,reason='Make one synthesis normally to capture a recipe',crafts=0,recipe=nil,capturedAt=0};
end

function M.capture(c,recipe,now)
    if c.running then return; end
    c.recipe=recipe; c.capturedAt=now or 0;
    c.reason='Recipe captured. Finish the manual synthesis, then start repeating.';
end

function M.stop(c,reason)
    c.running=false; c.reason=reason or 'Stopped';
end

function M.start(c,s,now)
    if not c.recipe then return false,'Make one synthesis normally first'; end
    if not s.online or s.status~=0 then return false,'Stand idle before starting'; end
    if not s.focus then return false,'Keep the game focused'; end
    if s.chat then return false,'Close chat input first'; end
    if s.free<=0 then return false,'Inventory is full'; end
    c.running=true; c.character=s.character; c.zone=s.zone;
    c.crafts=0;
    -- Current Reality rejects a new synth until 15 seconds after the prior
    -- synth began.  The captured packet marks the beginning of the manual one.
    c.nextAt=math.max(now+0.5,(c.capturedAt or 0)+15.5);
    c.phase='ready'; c.reason='Waiting for the synthesis cooldown';
    return true;
end

function M.sent(c,now)
    c.phase='awaiting_start'; c.lastSentAt=now; c.startDeadline=now+4;
    c.reason='Synthesis request sent; waiting for it to begin';
end

function M.tick(c,s,now)
    if not c.running then return nil; end
    local reason;
    if not s.online or s.character~=c.character or s.zone~=c.zone then reason='Character or zone changed';
    elseif s.hp<=0 then reason='Character is not alive';
    elseif not s.focus then reason='Game lost focus';
    elseif s.chat then reason='Chat input opened';
    elseif s.free<=0 then reason='Inventory is full';
    elseif s.status~=0 and s.status~=44 then reason='Character moved or became busy (status '..tostring(s.status)..')'; end
    if reason then M.stop(c,reason); return nil; end

    if c.phase=='awaiting_start' then
        if s.status==44 then
            c.phase='crafting'; c.crafts=c.crafts+1;
            c.reason='Synthesis '..c.crafts..' in progress';
        elseif now>=c.startDeadline then
            -- Do not pretend a rejected packet was a craft. Retry safely.
            c.phase='ready'; c.nextAt=now+2;
            c.reason='Server did not start the synthesis; retrying';
        end
        return nil;
    end

    if c.phase=='crafting' then
        if s.status==44 then return nil; end
        c.phase='ready';
        c.nextAt=math.max(now+0.5,(c.lastSentAt or now)+15.5);
        c.reason='Synthesis finished; waiting for cooldown';
        return nil;
    end

    if s.status~=0 then return nil; end
    if now<c.nextAt then
        c.reason='Next synthesis in '..tostring(math.max(1,math.ceil(c.nextAt-now)))..' seconds';
        return nil;
    end
    c.reason='Starting next synthesis'; return 'synth';
end

return M;
