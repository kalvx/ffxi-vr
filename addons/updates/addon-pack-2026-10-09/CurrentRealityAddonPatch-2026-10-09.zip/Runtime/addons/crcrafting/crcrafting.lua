addon.name='crcrafting'; addon.author='Current Reality'; addon.version='0.2.0';
addon.desc='Repeats the last synthesis recipe selected in game';
require('common'); require('win32types');
local ffi=require('ffi'); local bit=require('bit'); local imgui=require('imgui');
local controller=require('controller');

ffi.cdef[[
HWND GetForegroundWindow(void);
short __stdcall GetAsyncKeyState(int);
unsigned long __stdcall GetTickCount(void);
]];

local c=controller.new();
local visible=true;
local lastState={free=0,status=-1};
local f8WasDown=false;

local function now() return tonumber(ffi.C.GetTickCount())/1000; end

local function itemName(id)
    local item=id and id>0 and AshitaCore:GetResourceManager():GetItemById(id);
    return item and item.Name[1] or ('Item '..tostring(id or 0));
end

local function snapshot()
    local mem=AshitaCore:GetMemoryManager();
    local party,player,inv=mem:GetParty(),mem:GetPlayer(),mem:GetInventory();
    local index=party:GetMemberTargetIndex(0);
    local s={online=false,free=0,hp=0,status=-1,chat=false,focus=false};
    s.online=player:GetLoginStatus()==2 and party:GetMemberIsActive(0)>0 and index>0;
    if not s.online then return s; end
    s.character=party:GetMemberServerId(0); s.zone=party:GetMemberZone(0);
    s.hp=party:GetMemberHP(0); s.status=mem:GetEntity():GetStatusServer(index);
    s.focus=tonumber(ffi.cast('uintptr_t',ffi.C.GetForegroundWindow()))==tonumber(AshitaCore:GetProperties():GetFinalFantasyHwnd());
    local input=AshitaCore:GetChatManager():IsInputOpen();
    s.chat=input==true or (type(input)=='number' and input~=0);
    s.used=inv:GetContainerCount(0); s.capacity=inv:GetContainerCountMax(0); s.free=s.capacity-s.used;
    return s;
end

local function stop(reason) controller.stop(c,reason); end

local function start()
    local s=snapshot(); lastState=s;
    local ok,err=controller.start(c,s,now());
    if not ok then c.reason=err; end
end

local function sendSynth()
    local ok,sendErr=pcall(function()
        AshitaCore:GetChatManager():QueueCommand(1,'/lastsynth');
    end);
    if not ok then stop('Could not run /lastsynth: '..tostring(sendErr)); return false; end
    return true;
end

local function tick()
    local t=now(); local s=snapshot(); lastState=s;
    local f8=bit.band(tonumber(ffi.C.GetAsyncKeyState(0x77)),0x8000)~=0;
    if f8 and not f8WasDown then stop('Stopped with F8'); end
    f8WasDown=f8;
    local action=controller.tick(c,s,t);
    if action=='synth' and sendSynth() then controller.sent(c,t); end
end

local function u16(data,offset)
    local a,b=data:byte(offset+1,offset+2); return a+(b*256);
end

local function capture(data)
    -- Ashita packet data includes the four-byte FFXI packet header.  The
    -- 0x096 payload is: HashNo, padding, Crystal, CrystalIdx, Items,
    -- ItemNo[8], TableNo[8], padding.
    if type(data)~='string' or #data<36 then return nil,'Synthesis packet was shorter than expected'; end
    local count=data:byte(10);
    if not count or count<1 or count>8 then return nil,'Invalid ingredient count'; end
    local recipe={packet=data,crystal=u16(data,6),ingredients={}};
    if recipe.crystal==0 then return nil,'Invalid crystal'; end
    for i=1,count do
        local id=u16(data,10+((i-1)*2));
        if id==0 then return nil,'Invalid ingredient'; end
        table.insert(recipe.ingredients,id);
    end
    return recipe;
end

ashita.events.register('packet_out','crcrafting_packet',function(e)
    if e.id~=0x096 or e.blocked then return; end
    local recipe,err=capture(e.data);
    if not recipe then c.reason=err; return; end
    controller.capture(c,recipe,now());
end);

ashita.events.register('packet_in','crcrafting_zone',function(e)
    if e.id==0x00A or e.id==0x00B then stop('Zone changed'); end
end);

ashita.events.register('text_in','crcrafting_text',function(e)
    if not c.running then return; end
    local message=(e.message or ''):lower();
    for _,phrase in ipairs({
        'do not have the necessary ingredients',
        'cannot synthesize',
        'cannot use that command',
        'unable to use that command'
    }) do
        if message:find(phrase,1,true) then stop(e.message); break; end
    end
end);

ashita.events.register('command','crcrafting_command',function(e)
    local command=e.command:lower():match('^%s*(.-)%s*$');
    if command=='/crcrafting' then e.blocked=true; visible=not visible;
    elseif command=='/crcrafting stop' then e.blocked=true; stop('Stopped');
    elseif command=='/crcrafting start' then e.blocked=true; visible=true; start();
    elseif command=='/crcrafting clear' then e.blocked=true; stop('Recipe cleared'); c.recipe=nil; end
end);

ashita.events.register('d3d_present','crcrafting_panel',function()
    local ok,err=pcall(tick); if not ok then stop('Error: '..tostring(err)); end
    if not visible then return; end
    imgui.SetNextWindowSize({390,260},ImGuiCond_FirstUseEver);
    if imgui.Begin('Current Reality Crafting',nil,ImGuiWindowFlags_AlwaysAutoResize) then
        if c.recipe then
            imgui.Text('Recipe captured');
            imgui.Text('Crystal: '..itemName(c.recipe.crystal));
            local names={}; for _,id in ipairs(c.recipe.ingredients) do table.insert(names,itemName(id)); end
            imgui.TextWrapped('Materials: '..table.concat(names,', '));
        else
            imgui.TextWrapped('Make one synthesis normally to capture its recipe.');
        end
        imgui.Separator();
        imgui.TextWrapped(c.reason or 'Stopped');
        imgui.Text(string.format('Free inventory: %d   Repeats: %d',lastState.free or 0,c.crafts));
        if c.running then
            if imgui.Button('Stop',{150,30}) then stop('Stopped'); end
        else
            if imgui.Button('Start repeating',{150,30}) then start(); end
            imgui.SameLine();
            if imgui.Button('Clear recipe',{120,30}) then stop('Recipe cleared'); c.recipe=nil; end
        end
        imgui.Text('F8 stops. Keep the game focused.');
        imgui.Text('Opening chat, moving, zoning, or filling inventory stops it.');
    end
    imgui.End();
end);

ashita.events.register('unload','crcrafting_unload',function() stop('Unloaded'); end);
