-- Dark Potion I is a fallback after the unchanged party-care policy.
local bit=require('bit')
local O={}
function O.capture(mem,s)
    if s.status~=1 then return nil,'player not engaged' end
    if s.level<40 then return nil,'level below 40' end
    local entities,party=mem:GetEntity(),mem:GetParty()
    local index=mem:GetTarget():GetTargetIndex(0)
    local ownIndex=party:GetMemberTargetIndex(0)
    if not index or index<1 or index>2303 then return nil,'no selected target' end
    local battle=entities:GetTargetedIndex(ownIndex)
    if battle~=0 and battle~=index then return nil,'combat/selected target differ ('..tostring(battle)..'/'..tostring(index)..')' end
    if bit.band(entities:GetSpawnFlags(index),16)==0 then return nil,'selected target is not a monster' end
    if entities:GetHPPercent(index)<=0 then return nil,'selected monster is dead' end
    local distance=entities:GetDistance(index)
    if type(distance)~='number' or distance<0 or distance>18*18 then return nil,'target beyond 18 yalms' end
    local claim=entities:GetClaimStatus(index)
    if claim~=0 then
        local allowed=false
        for slot=0,17 do
            if party:GetMemberIsActive(slot)~=0 and party:GetMemberServerId(slot)==claim then allowed=true;break end
        end
        if not allowed then return nil,'target claimed outside alliance' end
    end
    -- The live player target field can be zero while engaged (captured PC case).
    -- Use the selected party-claimed monster; do not turn a zero into an unclaimed pull.
    if battle==0 and claim==0 then return nil,'combat target unavailable; monster not claimed' end
    local id=entities:GetServerId(index)
    if not id or id<=0 then return nil,'target ID unavailable' end
    return{id=id,index=index},'target valid'
end
function O.choose(report,s,time)
    if not report then return nil,'waiting for ready report' end
    if not report.darkPotionReady then return nil,'server reports unavailable' end
    if time<report.time or time-report.time>4 then return nil,'ready report expired' end
    if not s or s.job~=18 or s.level<40 or s.status~=1 or s.typing or not s.enemy then return nil,'target or player check' end
    return{ability=138,name='Dark Potion',id=s.enemy.id,index=s.enemy.index,offense=true}
end
function O.sameTarget(pending,s)
    return s and s.status==1 and not s.typing and s.enemy and s.enemy.id==pending.id and s.enemy.index==pending.index
end
return O
