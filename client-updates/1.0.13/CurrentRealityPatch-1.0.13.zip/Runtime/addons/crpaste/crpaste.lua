addon.name='crpaste';addon.author='Current Reality';addon.version='1.1';
addon.desc='Clipboard typing for chat and macro lines, with a ROG touch button.';
require('common');require('win32types')
local ffi=require('ffi');local bit=require('bit');local imgui=require('imgui');local settings=require('settings')
local planner=require('cr_paste_plan')
ffi.cdef[[
unsigned long long __stdcall GetTickCount64(void);
HWND __stdcall GetForegroundWindow(void);
short __stdcall GetAsyncKeyState(int);
short __stdcall GetKeyState(int);
short __stdcall VkKeyScanW(unsigned short);
unsigned int __stdcall MapVirtualKeyW(unsigned int,unsigned int);
typedef struct { int32_t dx,dy; uint32_t mouseData,dwFlags,time; uintptr_t dwExtraInfo; } CRPASTE_MOUSEINPUT;
typedef struct { uint16_t wVk,wScan; uint32_t dwFlags,time; uintptr_t dwExtraInfo; } CRPASTE_KEYBDINPUT;
typedef struct { uint32_t uMsg; uint16_t wParamL,wParamH; } CRPASTE_HARDWAREINPUT;
typedef struct { uint32_t type; union { CRPASTE_MOUSEINPUT mi; CRPASTE_KEYBDINPUT ki; CRPASTE_HARDWAREINPUT hi; } data; } CRPASTE_INPUT;
unsigned int __stdcall SendInput(unsigned int,CRPASTE_INPUT*,int);
]]
local user32=ffi.load('user32')
local config=settings.load(T{visible=true})
local state={message='Copy one line. Ctrl+V pastes into an open text field.',plan=nil,index=1,shift=false,down=nil}
-- The bundled Lua constants predate this client's newer ImGui backend.
local noNavInputs,noNavFocus=ImGuiWindowFlags_NoNavInputs,ImGuiWindowFlags_NoNavFocus
local versionOk,guiVersion=pcall(function()return imgui.GetVersion()end)
local guiMajor,guiMinor=tostring(guiVersion):match('^(%d+)%.(%d+)')
if versionOk and guiMajor and(tonumber(guiMajor)>1 or(tonumber(guiMajor)==1 and tonumber(guiMinor)>=92))then
    noNavInputs,noNavFocus=bit.lshift(1,16),bit.lshift(1,17)
end
local function now()return tonumber(ffi.C.GetTickCount64())/1000 end
local function pressed(vk)return bit.band(tonumber(user32.GetAsyncKeyState(vk)),0x8000)~=0 end
local function focus()
    local game=tonumber(AshitaCore:GetProperties():GetFinalFantasyHwnd())
    return game and game~=0 and tonumber(ffi.cast('uintptr_t',user32.GetForegroundWindow()))==game
end
local function input()
    local value=AshitaCore:GetChatManager():IsInputOpen()
    return value==true or(type(value)=='number'and bit.band(value,1)==1)
end
local function key(vk,up)
    local scan=tonumber(user32.MapVirtualKeyW(vk,0))
    if scan<=0 or scan>255 then return false end
    local event=ffi.new('CRPASTE_INPUT[1]')
    event[0].type=1;event[0].data.ki.wScan=scan;event[0].data.ki.dwFlags=up and 0x0A or 0x08
    return tonumber(user32.SendInput(1,event,ffi.sizeof('CRPASTE_INPUT')))==1
end
local function release()
    if state.down then key(state.down,true);state.down=nil end
    if state.shift then key(0x10,true);state.shift=false end
end
local function cancel(reason)
    release();state.plan=nil;state.armMacro=nil;state.message=reason or'Paste cancelled.'
end
local function releasePanelFocus()
    -- Clicking a touch button can leave ImGui navigation owning the keyboard.
    -- Relinquish only during a requested button paste; Ctrl+V is unchanged.
    local focusOk=pcall(function()imgui.SetWindowFocus(nil)end)
    local captureOk=pcall(function()imgui.SetNextFrameWantCaptureKeyboard(false)end)
    if not captureOk then
        captureOk=pcall(function()imgui.CaptureKeyboardFromApp(false)end)
    end
    return focusOk or captureOk
end
local function request(macro,delay)
    if state.plan then return end
    local text=ashita.misc.get_clipboard()
    local plan,reason=planner.build(text,function(ch)return tonumber(user32.VkKeyScanW(ch))end,
        bit.band(tonumber(user32.GetKeyState(0x14)),1)==1)
    if not plan then state.message=reason;print('[crpaste] '..reason);return end
    state.plan=plan;state.index=1;state.macro=macro;state.touch=delay and delay>0
    state.startAt=now()+(delay or 0)
    state.deadline=now()+45;state.message=delay and'Open the destination field now. Paste starts in 3 seconds.'or'Release Ctrl+V to paste.'
    if state.touch and not releasePanelFocus()then cancel('Panel focus unavailable. Use Ctrl+V in the editor instead.')end
end
local hotkey=false
local function tick()
    local time=now();local combo=focus()and pressed(0x11)and pressed(0x56)
    if combo and not hotkey and not state.plan then
        if input()or(state.armMacro and time<state.armMacro)then request(state.armMacro and time<state.armMacro,0);state.armMacro=nil
        else state.message='Open chat first, or use the Paste macro line button.'end
    end
    hotkey=combo
    if not state.plan then return end
    if not focus()then cancel('Paste cancelled: game lost focus.');return end
    if time>state.deadline then cancel('Paste timed out.');return end
    if time<state.startAt then return end
    if state.down then
        if time>=state.releaseAt then
            release();state.index=state.index+1;state.nextAt=time+0.02
            if state.index>#state.plan then state.plan=nil;state.message='Pasted. Review the text; nothing was submitted.'end
        end
        return
    end
    if pressed(0x11)or pressed(0x12)or pressed(0x10)or pressed(0x56)then return end
    if not state.macro and not input()then cancel('Paste cancelled: text input closed.');return end
    if time<(state.nextAt or 0)then return end
    local stroke=state.plan[state.index]
    if stroke.shift then if not key(0x10,false)then cancel('Shift key unavailable.');return end;state.shift=true end
    if not key(stroke.key,false)then cancel('A key is unavailable.');return end
    state.down=stroke.key;state.releaseAt=time+0.025
end
settings.register('settings','crpaste_settings',function(s)if s then config=s end end)
ashita.events.register('load','crpaste_load',function()
    -- Replace only the existing stock paste binding; other keybinds remain.
    AshitaCore:GetChatManager():QueueCommand(1,'/unbind $^v')
end)
ashita.events.register('key','crpaste_key',function(e)
    if e.wparam==0x56 and pressed(0x11)and focus()then e.blocked=true end
    if e.wparam==0x1B and state.plan then cancel('Paste cancelled.')end
end)
ashita.events.register('command','crpaste_commands',function(e)
    local args=e.command:lower():match('^/crpaste%s*(.-)%s*$');if args==nil then return end
    e.blocked=true
    if args==''then config.visible=not config.visible
    elseif args=='show'then config.visible=true
    elseif args=='hide'then config.visible=false
    elseif args=='macro'then state.armMacro=now()+20;state.message='Next Ctrl+V within 20 seconds pastes one macro line. Open its editor first.'
    elseif args=='cancel'then cancel()
    elseif args=='status'then print('[crpaste] '..state.message)
    else print('[crpaste] show | hide | macro | cancel | status. Ctrl+V: paste one line; never presses Enter.')end
    settings.save()
end)
ashita.events.register('d3d_present','crpaste_draw',function()
    if state.plan and state.touch and not releasePanelFocus()then cancel('Panel focus unavailable. Use Ctrl+V in the editor instead.')end
    local ok,err=pcall(tick);if not ok then cancel('Paste stopped: '..tostring(err))end
    if not config.visible then return end
    imgui.SetNextWindowSize({0,0},ImGuiCond_Always)
    local flags=bit.bor(ImGuiWindowFlags_AlwaysAutoResize,ImGuiWindowFlags_NoFocusOnAppearing,
        ImGuiWindowFlags_NoTitleBar,ImGuiWindowFlags_NoBackground,ImGuiWindowFlags_NoResize,ImGuiWindowFlags_NoCollapse)
    if state.plan and state.touch then flags=bit.bor(flags,noNavInputs,noNavFocus)end
    if imgui.Begin('CR Paste',nil,flags)then
        if imgui.Button('Macro',{44,44})then request(true,3)end
        imgui.SameLine()
        if imgui.Button('Chat',{44,44})then request(false,3)end
        if imgui.Button('Stop',{44,44})then cancel()end
        imgui.SameLine()
        if imgui.Button('X',{44,44})then cancel();config.visible=false;settings.save()end
    end
    imgui.End()
end)
ashita.events.register('unload','crpaste_unload',function()
    cancel();settings.save();AshitaCore:GetChatManager():QueueCommand(1,'/bind $^v /paste')
end)
