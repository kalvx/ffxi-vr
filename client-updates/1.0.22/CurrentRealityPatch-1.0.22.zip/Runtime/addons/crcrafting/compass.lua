-- Advisory display only. The native server owns every crafting roll.
local data=require('compass_data')
local M={}
local dayNames={'Firesday','Earthsday','Watersday','Windsday','Iceday','Lightningday','Lightsday','Darksday'}
local weatherNames={'None','Sunshine','Clouds','Fog','Hot spell','Heat wave','Rain','Squall','Dust storm','Sandstorm','Wind','Gales','Snow','Blizzards','Thunder','Thunderstorms','Auroras','Stellar glare','Gloom','Darkness'}
function M.element(crystal)
    if type(crystal)~='number' or crystal~=math.floor(crystal) then return end
    if crystal>=4096 and crystal<=4103 then return crystal-4096 end
    if crystal>=4238 and crystal<=4245 then return crystal-4238 end
end
function M.new() return {serial=0,nextQuery=0} end
function M.request(state,s,crystal,time)
    if not s.online or not M.element(crystal) or time<state.nextQuery then return end
    state.serial=state.serial%99999998+1
    state.pending={nonce=state.serial,character=s.character,zone=s.zone,crystal=crystal,time=time}
    state.nextQuery=time+2
    local text=string.format('!crcompass %d %d',state.serial,crystal)
    local raw=string.rep('\0',6)..text..'\0'
    raw=raw..string.rep('\0',(4-#raw%4)%4)
    return {raw:byte(1,#raw)}
end
function M.receive(state,text,s,crystal,time)
    if type(text)~='string' or not text:find('^%[CRCRAFT1%]') then return false end
    local a,b,c,d,e,f,g,h=text:match('^%[CRCRAFT1%] (%d+) (%d+) (%d+) (%d+) ([01]) (%d+) (%d+) (%d+)$')
    local p=state.pending
    if not a or not p or not s.online then return true end
    a,b,c,d,e,f,g,h=tonumber(a),tonumber(b),tonumber(c),tonumber(d),tonumber(e),tonumber(f),tonumber(g),tonumber(h)
    if a~=p.nonce or b~=p.character or c~=p.zone or d~=p.crystal or b~=s.character or c~=s.zone or d~=crystal
        or time<p.time or time-p.time>8 or f>255 or g>7 or h>19 then return true end
    state.report={character=b,zone=c,crystal=d,active=e==1,rotation=f,day=g,weather=h,time=time}
    state.pending=nil
    return true
end
function M.lines(state,s,crystal,time)
    local element=M.element(crystal)
    if not element then return {'Compass: capture a crystal recipe first.'} end
    local info=data.elements[element+1]
    local result={string.format('%s compass | Safe/NQ: %s | Risk/HQ + skillups: %s',info.name,data.directions[info.safe+1],data.directions[info.risky+1])}
    local r=state.report
    if not r or r.character~=s.character or r.zone~=s.zone or r.crystal~=crystal or time<r.time or time-r.time>8 then
        result[#result+1]='Compass preview: waiting for server confirmation.'
        return result
    end
    if not r.active then
        result[#result+1]='Compass preview: server bonuses are not enabled.'
        return result
    end
    local sector=math.floor((r.rotation+16)/32)%8
    local mode=sector==info.safe and 'Safe: better success' or (sector==info.risky and 'Risk: more breaks, better HQ/skillup chance' or 'Neutral direction')
    result[#result+1]='Facing '..data.directions[sector+1]..' | '..mode
    result[#result+1]=string.format('%s%s | %s%s',dayNames[r.day+1],data.days[r.day+1]==element and ' (matching)' or '',
        weatherNames[r.weather+1],data.weather[r.weather+1]==element and ' (matching)' or '')
    result[#result+1]='Alignment is locked when each synthesis starts. Skillup eligibility still applies.'
    return result
end
return M
