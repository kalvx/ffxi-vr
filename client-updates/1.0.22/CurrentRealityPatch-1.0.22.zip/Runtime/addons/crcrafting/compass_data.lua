return {version=1,directions={'E','SE','S','SW','W','NW','N','NE'},
 elements={
 {name='Fire',safe=5,risky=4},
 {name='Ice',safe=0,risky=5},
 {name='Wind',safe=1,risky=0},
 {name='Earth',safe=2,risky=1},
 {name='Lightning',safe=3,risky=2},
 {name='Water',safe=4,risky=3},
 {name='Light',safe=7,risky=6},
 {name='Dark',safe=6,risky=7},
},days={0,3,5,2,1,4,6,7},weather={-1,-1,-1,-1,0,0,5,5,3,3,2,2,1,1,4,4,6,6,7,7}}
