-- Dark Potion I is a fallback after the unchanged party-care policy.
local bit=require('bit')
local O={}
function O.capture(mem,s)
    if s.status~=1 or s.level<40 then return nil end
    local entities,party=mem:GetEntity(),mem:GetParty()
    local index=mem:GetTarget():GetTargetIndex(0)
    local ownIndex=party:GetMemberTargetIndex(0)
    if not index or index<1 or index>2303 or entities:GetTargetedIndex(ownIndex)~=index
        or bit.band(entities:GetSpawnFlags(index),16)==0 or entities:GetHPPercent(index)<=0 then return nil end
    local distance=entities:GetDistance(index)
    if type(distance)~='number' or distance<0 or distance>18*18 then return nil end
    local claim=entities:GetClaimStatus(index)
    if claim~=0 then
        local allowed=false
        for slot=0,17 do
            if party:GetMemberIsActive(slot)~=0 and party:GetMemberServerId(slot)==claim then allowed=true;break end
        end
        if not allowed then return nil end
    end
    local id=entities:GetServerId(index)
    if not id or id<=0 then return nil end
    return{id=id,index=index}
end
function O.choose(report,s,time)
    if not report or not report.darkPotionReady or time<report.time or time-report.time>4
        or not s or s.job~=18 or s.level<40 or s.status~=1 or s.typing or not s.enemy then return nil end
    return{ability=138,name='Dark Potion',id=s.enemy.id,index=s.enemy.index,offense=true}
end
function O.sameTarget(pending,s)
    return s and s.status==1 and not s.typing and s.enemy and s.enemy.id==pending.id and s.enemy.index==pending.index
end
return O
