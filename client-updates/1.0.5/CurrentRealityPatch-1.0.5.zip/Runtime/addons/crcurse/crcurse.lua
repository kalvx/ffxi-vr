addon.name = 'crcurse'
addon.author = 'Current Reality'
addon.version = '1.3'
addon.desc = 'Select an enemy, prepare carried medicines, then cast Curse or Virus.'
require('common')
local ffi = require('ffi')
ffi.cdef('unsigned long __stdcall GetTickCount(void);')
local definitions = {
    [257] = { name = 'Curse', level = 25, command = '!alccursemix' },
    [256] = { name = 'Virus', level = 10, command = '!alcvirusmix' },
}
local pending
local serial = tonumber(ffi.C.GetTickCount()) % 90000000
local function now() return tonumber(ffi.C.GetTickCount()) end
local function elapsed(start) return (now() - start) % 4294967296 end
local function uint32(raw, offset)
    return raw:byte(offset) + raw:byte(offset + 1) * 256 + raw:byte(offset + 2) * 65536 + raw:byte(offset + 3) * 16777216
end
local function identity(level)
    local memory = AshitaCore:GetMemoryManager()
    local player, party = memory:GetPlayer(), memory:GetParty()
    if player:GetLoginStatus() ~= 2 or party:GetMemberHP(0) <= 0 then return end
    local main, sub = player:GetMainJob(), player:GetSubJob()
    local ml, sl = player:GetMainJobLevel(), player:GetSubJobLevel()
    if not ((main == 18 and ml >= level) or (sub == 18 and sl >= level)) then return end
    return table.concat({ party:GetMemberServerId(0), party:GetMemberZone(0), main, sub, ml, sl }, ':')
end
local function cancel()
    if pending then
        AshitaCore:GetChatManager():QueueCommand(1, '!alcspellcancel ' .. pending.token)
        pending = nil
    end
end

ashita.events.register('packet_out', 'crcurse_prepare', function(e)
    if e.id ~= 0x01A or e.injected or e.blocked then return end
    local raw = e.data_modified
    if type(raw) ~= 'string' or #raw < 28 then return end
    local action = raw:byte(11)
    local id = raw:byte(13) + raw:byte(14) * 256
    local definition = definitions[id]
    local key = definition and identity(definition.level)
    if action == 3 and definition and key then
        e.blocked = true
        local target = uint32(raw, 5)
        local own = AshitaCore:GetMemoryManager():GetParty():GetMemberServerId(0)
        if target == 0 or target == own then
            cancel(); print('[Alchemist] Select an enemy for ' .. definition.name .. '.'); return
        end
        if pending and pending.id == id and pending.target == target and pending.key == key then return end
        cancel()
        serial = serial % 99999998 + 1
        pending = { id = id, definition = definition, target = target, token = serial, key = key, requested = now() }
        AshitaCore:GetChatManager():QueueCommand(1, definition.command .. ' ' .. target .. ' ' .. serial)
    elseif action == 3 or action == 4 or action == 7 or action == 9 or action == 16 then
        cancel()
    end
end)

ashita.events.register('text_in', 'crcurse_ack', function(e)
    local plain = (e.message or ''):gsub('[' .. string.char(0x1E, 0x1F, 0x7F) .. '].', ''):gsub('[%z\r\n\7]+$', '')
    local token, name, amount = plain:match('^%[Alchemist Mix%] (%d+) (%a+) (%d+)%.$')
    if token and (name == 'Curse' or name == 'Virus') then
        e.blocked = true
        local delay = tonumber(amount)
        if pending and pending.token == tonumber(token) and pending.definition.name == name and delay >= 1975 and delay <= 2500 then
            pending.started = now(); pending.delay = delay
        end
        return
    end
    local state
    token, state = plain:match('^%[Alchemist Mix%] (%d+) (%a+)%.$')
    if token and (state == 'Cast' or state == 'Failed') then
        e.blocked = true
        if pending and pending.token == tonumber(token) then pending = nil end
    end
end)

ashita.events.register('d3d_present', 'crcurse_cast', function()
    if not pending then return end
    if pending.key ~= identity(pending.definition.level) then cancel(); return end
    local limit = pending.started and pending.delay + 5000 or 5000
    if elapsed(pending.started or pending.requested) >= limit then
        local name = pending.definition.name
        cancel()
        print('[Alchemist] ' .. name .. ' preparation was not completed. Check the server response and try again.')
    end
end)
ashita.events.register('packet_in', 'crcurse_zone', function(e) if e.id == 0x00A then cancel() end end)
ashita.events.register('command', 'crcurse_cancel', function(e)
    local command = (e.command or ''):lower()
    if command == '/crcurse cancel' or command == '/crvirus cancel' then cancel(); e.blocked = true end
end)
ashita.events.register('unload', 'crcurse_unload', cancel)
