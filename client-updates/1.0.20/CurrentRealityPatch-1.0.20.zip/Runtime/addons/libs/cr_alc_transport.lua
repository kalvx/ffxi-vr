-- Send only the bounded Alchemist control protocol. Spell execution remains
-- owned by the server's ordinary cast engine; this never emits spell packets.
local M={}
local function validToken(n)return n and n>=1 and n<=99999999 end
function M.encode(text)
    if type(text)~='string'or #text>100 then return end
    local target,token=text:match('^!alccursemix (%d+) (%d+)$')
    if not token then target,token=text:match('^!alcvirusmix (%d+) (%d+)$')end
    local id
    if not token then id,target,token=text:match('^!alcspellmix (%d+) (%d+) (%d+)$')end
    if id then
        id=tonumber(id)
        if id~=1000 and id~=1001 and id~=1020 and id~=1021 and id~=1022 then return end
    end
    if not token then token=text:match('^!alcspellcancel (%d+)$')end
    if not validToken(tonumber(token))then return end
    if target and(tonumber(target)<1 or tonumber(target)>4294967295)then return end
    -- Outgoing 0x0B5: four-byte header, say mode, reserved byte, NUL message.
    -- Matches SmallPacket0x0B5's command-prefix offset 0x06 exactly.
    local raw=string.rep('\0',6)..text..'\0'
    raw=raw..string.rep('\0',(4-#raw%4)%4)
    return {raw:byte(1,#raw)}
end
function M.send(text)
    local bytes=M.encode(text)
    if not bytes then return false end
    local ok=pcall(function()AshitaCore:GetPacketManager():AddOutgoingPacket(0x0B5,bytes)end)
    return ok
end
return M
