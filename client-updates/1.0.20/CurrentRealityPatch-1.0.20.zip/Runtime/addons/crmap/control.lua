local bit=require('bit')
local M={}
local MASK=0x5000 -- Xbox A + X.
function M.new() return {mode='idle',next=0,direction=0} end
-- The event is a packed 16-byte XINPUT_STATE, little endian on Windows.
function M.decode(raw)
    if type(raw)~='string' or #raw~=16 then return end
    local buttons=raw:byte(5)+raw:byte(6)*256
    local y=raw:byte(11)+raw:byte(12)*256
    if y>=32768 then y=y-65536 end
    return buttons,y
end
function M.step(s,raw,t,allowed)
    local buttons,y=M.decode(raw)
    if not buttons then return raw,0 end
    if not allowed then s.mode='idle';s.direction=0;s.packet=nil;s.lastPad=nil;return raw,0 end
    local held=bit.band(buttons,MASK)
    local both=held==MASK
    if both then s.mode='chord'
    elseif s.mode=='chord' then
        if held==0 then s.mode='idle' else s.mode='release' end
    elseif s.mode=='release' and held==0 then s.mode='idle' end
    if s.mode=='idle' and held~=0 then s.mode='pending';s.since=t end
    local consume=false
    if s.mode=='pending' then
        if held==0 then
            -- Replay a short ordinary tap for one sample, then release it.
            buttons=bit.bor(buttons,s.pending or 0);s.mode='idle';s.pending=0
        elseif t-s.since>=0.09 then s.mode='ordinary'
        else consume=true;s.pending=held end
    elseif s.mode=='ordinary' and held==0 then s.mode='idle' end
    local direction=0
    if both then
        consume=true
        direction=y>16000 and 1 or y< -16000 and -1 or 0
    elseif s.mode=='release' then consume=true end
    local fire=0
    if direction~=0 and(direction~=s.direction or t>=s.next)then
        fire=direction;s.next=t+(direction~=s.direction and 0.35 or 0.18)
    end
    s.direction=direction
    if consume then buttons=bit.band(buttons,bit.bnot(MASK)) end
    local result=raw:sub(1,4)..string.char(buttons%256,math.floor(buttons/256))..raw:sub(7)
    if both or s.mode=='release' then result=result:sub(1,8)..string.rep('\0',4)..result:sub(13) end
    -- Buffered ordinary taps/holds can change the returned state while the
    -- hardware packet number is unchanged. Publish a new number for each
    -- delivered transition, including the release, so clients can observe it.
    local pad=result:sub(5)
    if not s.packet then
        s.packet=raw:byte(1)+raw:byte(2)*256+raw:byte(3)*65536+raw:byte(4)*16777216
    elseif s.lastPad~=pad then s.packet=(s.packet+1)%4294967296 end
    s.lastPad=pad
    local n=s.packet;local bytes={}
    for i=1,4 do bytes[i]=n%256;n=math.floor(n/256)end
    result=string.char(unpack(bytes))..pad
    return result,fire
end
function M.preset(text,x,y)
    local values={main={x=x,y=y,scale_x=1,scale_y=1,zoom=0.35,opacity_frame=0.04},theme={name='square'}}
    local section;local found={};local lines={}
    for line in (text..'\n'):gmatch('(.-)\r?\n')do
        local new=line:match('^%s*%[([^%]]+)%]')
        if new then section=new:lower();found[section]=found[section]or{} end
        local key=line:match('^%s*([%w_]+)%s*=')
        key=key and key:lower()
        if key and values[section]and values[section][key]~=nil then
            line=key..' = '..tostring(values[section][key]);found[section][key]=true
        end
        lines[#lines+1]=line
    end
    -- Existing shipped configs contain all these keys; fail rather than append
    -- misplaced values to a malformed or incompatible file.
    for sec,keys in pairs(values)do for key in pairs(keys)do
        if not(found[sec]and found[sec][key])then return nil,'Missing '..sec..'.'..key end
    end end
    return table.concat(lines,'\n')
end
function M.position(w,h,size)
    return math.max(0,w-size-48),math.max(0,h-size-120)
end
return M
