local P={}
local data=require('cr_alc_care_data')
local actions={}
for _,a in ipairs(data.actions)do actions[a.id]=a end
local function has(value,flag)return math.floor((value or 0)/flag)%2==1 end
local function ready(report,id)
    if report.ready then return report.ready[id]end
    return id==136 and report.heal or id==137 and report.mixed or id==147 and report.guard
end
local function action(report,id,v)
    if ready(report,id)then return{ability=id,name=actions[id].name,slot=v.member.slot,id=v.row.id}end
end
local buffs={{147,3},{148,4},{140,8},{179,32},{180,64}}
local function rotated(eligible,rotation,id)
    local list={unpack(eligible)}
    local last=rotation and rotation.members and rotation.members[id]or 5
    table.sort(list,function(a,b)return(a.member.slot-last-1)%6<(b.member.slot-last-1)%6 end)
    return list
end
function P.record(rotation,choice)
    rotation.members=rotation.members or{}
    rotation.members[choice.ability]=choice.slot
    for i,buff in ipairs(buffs)do if buff[1]==choice.ability then rotation.buff=i;break end end
end
function P.choose(report,party,time,rotation)
    if not report or time-report.time>4 or time<report.time then return nil end
    local eligible={}
    for _,row in ipairs(report.members)do
        local member=party[row.id]
        if member and member.alive and member.inRange and member.sameZone and row.hpp>0 then eligible[#eligible+1]={row=row,member=member}end
    end
    table.sort(eligible,function(a,b)if a.row.hpp~=b.row.hpp then return a.row.hpp<b.row.hpp end return a.member.slot<b.member.slot end)
    local function heal(limit,waking)
        for _,v in ipairs(eligible)do
            if(waking and has(v.row.ailments,1))or(not waking and v.row.hpp<=limit and v.member.hpp<=limit)then
                local chosen=action(report,136,v)or action(report,137,v)
                if chosen then return chosen end
            end
        end
    end
    local chosen=heal(35,false)or heal(100,true)
    if chosen then return chosen end
    for _,cure in ipairs({{16,144},{32,146},{4,142},{2,141},{8,143},{64,145}})do
        for _,v in ipairs(eligible)do
            if has(v.row.ailments,cure[1])then chosen=action(report,cure[2],v);if chosen then return chosen end end
        end
    end
    chosen=heal(75,false);if chosen then return chosen end
    local mana={}
    for _,v in ipairs(eligible)do if v.row.mpp and v.row.mpp<=50 and v.row.missing>=80 then mana[#mana+1]=v end end
    table.sort(mana,function(a,b)if a.row.mpp~=b.row.mpp then return a.row.mpp<b.row.mpp end return a.member.slot<b.member.slot end)
    if mana[1]then chosen=action(report,139,mana[1]);if chosen then return chosen end end
    if report.sleepRisk then
        local protect=rotated(eligible,rotation,266)
        for _,v in ipairs(protect)do if not has(v.row.buffs,16)then chosen=action(report,266,v);if chosen then return chosen end end end
    end
    for offset=1,#buffs do
        local buff=buffs[((rotation and rotation.buff or 0)+offset-1)%#buffs+1]
        for _,v in ipairs(rotated(eligible,rotation,buff[1]))do
            local current=v.row.buffs or((v.row.protect and 1 or 0)+(v.row.shell and 2 or 0))
            local missing=buff[1]==147 and(not has(current,1)or not has(current,2))or(buff[1]~=147 and not has(current,buff[2]))
            if missing and(buff[1]~=179 or(v.row.mpp and v.row.mpp~=255))then chosen=action(report,buff[1],v);if chosen then return chosen end end
        end
    end
end
function P.parse(text,request,time)
    if type(text)~='string' or #text>260 then return nil end
    text=text:gsub('%z.*$','')
    if #text>220 then return nil end
    if not request or time-request.time>4 or time<request.time then return nil end
    local nonce,zone,mask,risk,body=text:match('^%[CRALC2%] (%d+) (%d+) (%x+) ([01]) ([%x,;]+)$')
    if nonce then
        if tonumber(nonce)~=request.nonce or tonumber(zone)~=request.zone then return nil end
        mask=tonumber(mask,16);if mask>32767 or body:find(';;',1,true)or body:match(';$')then return nil end
        local report={time=time,ready={},sleepRisk=risk=='1',members={}};local seen={}
        for _,a in ipairs(data.actions)do report.ready[a.id]=has(mask,a.bit)end
        for line in body:gmatch('[^;]+')do
            local id,hpp,mpp,missing,buffs,ailments=line:match('^(%x+),(%d+),(%d+),(%x+),(%x+),(%x+)$')
            id=tonumber(id or'',16);hpp=tonumber(hpp);mpp=tonumber(mpp)
            missing=tonumber(missing or'',16);buffs=tonumber(buffs or'',16);ailments=tonumber(ailments or'',16)
            if not id or id<1 or id>4294967295 or seen[id]or not hpp or hpp<1 or hpp>100 or not mpp or(mpp>100 and mpp~=255)
                or not missing or missing>65535 or(mpp==255 and missing~=0)or not buffs or buffs>127 or not ailments or ailments>127 then return nil end
            seen[id]=true;report.members[#report.members+1]={id=id,hpp=hpp,mpp=mpp,missing=missing,buffs=buffs,ailments=ailments}
        end
        if #report.members<1 or #report.members>6 then return nil end
        return report
    end
    local heal,guard
    nonce,zone,heal,guard,body=text:match('^%[CRALC1%] (%d+) (%d+) ([0-3]) ([01]) ([%d,;]+)$')
    if not nonce or tonumber(nonce)~=request.nonce or tonumber(zone)~=request.zone then return nil end
    local readiness=tonumber(heal)
    local report={time=time,heal=readiness%2==1,mixed=readiness>=2,guard=guard=='1',members={}};local seen={}
    for line in body:gmatch('[^;]+')do
        local id,hpp,protect,shell=line:match('^(%d+),(%d+),([01]),([01])$')
        id=tonumber(id);hpp=tonumber(hpp)
        if not id or id<1 or id>4294967295 or not hpp or hpp>100 or seen[id]then return nil end
        seen[id]=true;report.members[#report.members+1]={id=id,hpp=hpp,protect=protect=='1',shell=shell=='1'}
    end
    if #report.members<1 or #report.members>6 then return nil end
    return report
end
return P
