-- Temporary per-entity body motion. No emote packet, effects or wing resources.
local visual = {}
local active = {}
local function fourcc(text)
    return text:byte(1) + text:byte(2)*256 + text:byte(3)*65536 + text:byte(4)*16777216
end
local float0, float1 = fourcc('flt0'), fourcc('flt1')
local locomotion = {}
for _, prefix in ipairs({ 'idl', 'id1', 'wlk', 'run' }) do
    for suffix = 0, 1 do locomotion[fourcc(prefix .. suffix)] = true end
end
local function restore(entry)
    if not entry.index then return end
    local entities = AshitaCore:GetMemoryManager():GetEntity()
    if entities:GetServerId(entry.index) ~= entry.id then return end
    for slot = 0, 1 do
        local value = entities:GetAnimation(entry.index, slot)
        if (value == float0 or value == float1) and entry.saved and entry.saved[slot] then
            entities:SetAnimation(entry.index, slot, entry.saved[slot])
        end
    end
end
function visual.message(plain, now)
    local id, state = plain:match('^%[Alchemist Float%] (%d+) (%a+)%.$')
    if not id or (state ~= 'Start' and state ~= 'End') then return false end
    id = tonumber(id)
    if state == 'End' then
        if active[id] then restore(active[id]); active[id] = nil end
    else
        active[id] = active[id] or { id = id }
        active[id].refreshed = now
    end
    return true
end
function visual.tick(now)
    if next(active) == nil then return end
    local entities = AshitaCore:GetMemoryManager():GetEntity()
    for id, entry in pairs(active) do
        if (now - entry.refreshed) % 4294967296 > 4500 then
            restore(entry); active[id] = nil
        else
            if entry.index and entities:GetServerId(entry.index) ~= id then entry.index = nil; entry.saved = nil end
            if not entry.index and (not entry.searched or (now-entry.searched)%4294967296 >= 500) then
                entry.searched = now
                for index = 0, 2303 do
                    if entities:GetServerId(index) == id then entry.index = index; break end
                end
            end
            if entry.index and entities:GetHPPercent(entry.index) > 0 then
                local lower = entities:GetAnimation(entry.index, 0)
                local upper = entities:GetAnimation(entry.index, 1)
                -- Combat, casting, emotes, mounted forms and other actions keep
                -- their own animation. Hover resumes with ordinary locomotion.
                if locomotion[lower] and locomotion[upper] then
                    entry.saved = { [0] = lower, [1] = upper }
                    entities:SetAnimation(entry.index, 0, float0)
                    entities:SetAnimation(entry.index, 1, float1)
                end
            end
        end
    end
end
function visual.clear()
    for _, entry in pairs(active) do restore(entry) end
    active = {}
end
return visual
