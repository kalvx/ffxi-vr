addon.name = 'crcurse'
addon.author = 'Current Reality'
addon.version = '1.5'
addon.desc = 'Prepare carried medicines before Alchemist magic; temporary wingless Float motion.'
require('common')
local floatVisual = require('float_visual')
local ffi = require('ffi')
ffi.cdef('unsigned long __stdcall GetTickCount(void);')
local definitions = {
    [1020] = { name = 'Impact', level = 50, command = '!alcspellmix 1020' },
    [1021] = { name = 'Meteor', level = 60, command = '!alcspellmix 1021' },
    [1022] = { name = 'MeteorII', level = 60, command = '!alcspellmix 1022' },
    [1000] = { name = 'Float', level = 37, command = '!alcspellmix 1000', friendly = true },
    [1001] = { name = 'ManaShield', level = 40, command = '!alcspellmix 1001', friendly = true },
    [257] = { name = 'Curse', level = 25, command = '!alccursemix' },
    [256] = { name = 'Virus', level = 10, command = '!alcvirusmix' },
}
local pending
local serial = tonumber(ffi.C.GetTickCount()) % 90000000
local function now() return tonumber(ffi.C.GetTickCount()) end
local function elapsed(start) return (now() - start) % 4294967296 end
local function uint32(raw, offset)
    return raw:byte(offset) + raw:byte(offset + 1) * 256 + raw:byte(offset + 2) * 65536 + raw:byte(offset + 3) * 16777216
end
local function identity(level)
    local memory = AshitaCore:GetMemoryManager()
    local player, party = memory:GetPlayer(), memory:GetParty()
    if player:GetLoginStatus() ~= 2 or party:GetMemberHP(0) <= 0 then return end
    local main, sub = player:GetMainJob(), player:GetSubJob()
    local ml, sl = player:GetMainJobLevel(), player:GetSubJobLevel()
    if not ((main == 18 and ml >= level) or (sub == 18 and sl >= level)) then return end
    return table.concat({ party:GetMemberServerId(0), party:GetMemberZone(0), main, sub, ml, sl }, ':')
end
local function cancel()
    if pending then
        AshitaCore:GetChatManager():QueueCommand(1, '!alcspellcancel ' .. pending.token)
        pending = nil
    end
end

local function prepare(id, target, key)
    local definition = definitions[id]
    local own = AshitaCore:GetMemoryManager():GetParty():GetMemberServerId(0)
    if target == 0 or (target == own and not definition.friendly) then
        cancel(); print('[Alchemist] Select an enemy for ' .. definition.name .. '.'); return
    end
    if pending and pending.id == id and pending.target == target and pending.key == key then return end
    cancel()
    serial = serial % 99999998 + 1
    pending = { id = id, definition = definition, target = target, token = serial, key = key, requested = now() }
    AshitaCore:GetChatManager():QueueCommand(1, definition.command .. ' ' .. target .. ' ' .. serial)
end

ashita.events.register('packet_out', 'crcurse_prepare', function(e)
    if e.id ~= 0x01A or e.injected or e.blocked then return end
    local raw = e.data_modified
    if type(raw) ~= 'string' or #raw < 28 then return end
    local action = raw:byte(11)
    local id = raw:byte(13) + raw:byte(14) * 256
    local aliases = { [503] = 1020, [218] = 1021, [244] = 1022 }
    if aliases[id] and identity(definitions[aliases[id]].level) then id = aliases[id] end
    local definition = definitions[id]
    local key = definition and identity(definition.level)
    if action == 3 and definition and key then
        e.blocked = true
        local target = uint32(raw, 5)
        prepare(id, target, key)
    elseif action == 3 or action == 4 or action == 7 or action == 9 or action == 16 then
        cancel()
    end
end)

ashita.events.register('text_in', 'crcurse_ack', function(e)
    local plain = (e.message or ''):gsub('[' .. string.char(0x1E, 0x1F, 0x7F) .. '].', ''):gsub('[%z\r\n\7]+$', '')
    -- Hide only the local rendered echo of our preparation/cancellation commands.
    -- Never block command, text_out or packet_out delivery to the server.
    local speaker, payload = plain:match('^([%a]+)%s*:%s*(.*)$')
    local own = AshitaCore:GetMemoryManager():GetParty():GetMemberName(0)
    local echo = not speaker and plain or (speaker == own and payload or '')
    echo = echo:match('^%s*(.-)%s*$')
    if echo:match('^!alccursemix %d+ %d+$') or echo:match('^!alcvirusmix %d+ %d+$') or
        echo:match('^!alcspellcancel %d+$') or echo:match('^!alcspellmix %d+ %d+ %d+$') then
        e.blocked = true
        return
    end
    if floatVisual.message(plain, now()) then e.blocked = true; return end
    local token, name, amount = plain:match('^%[Alchemist Mix%] (%d+) (%a+) (%d+)%.$')
    if token and (name == 'Curse' or name == 'Virus' or name == 'Float' or name == 'ManaShield' or name == 'Impact' or name == 'Meteor' or name == 'MeteorII') then
        e.blocked = true
        local delay = tonumber(amount)
        if pending and pending.token == tonumber(token) and pending.definition.name == name and delay >= 1975 and delay <= 2500 then
            pending.started = now(); pending.delay = delay
        end
        return
    end
    local state
    token, state = plain:match('^%[Alchemist Mix%] (%d+) (%a+)%.$')
    if token and (state == 'Cast' or state == 'Failed') then
        e.blocked = true
        if pending and pending.token == tonumber(token) then pending = nil end
    end
end)

ashita.events.register('d3d_present', 'crcurse_cast', function()
    floatVisual.tick(now())
    if not pending then return end
    if pending.key ~= identity(pending.definition.level) then cancel(); return end
    local limit = pending.started and pending.delay + 5000 or 5000
    if elapsed(pending.started or pending.requested) >= limit then
        local name = pending.definition.name
        cancel()
        print('[Alchemist] ' .. name .. ' preparation was not completed. Check the server response and try again.')
    end
end)
ashita.events.register('packet_in', 'crcurse_zone', function(e) if e.id == 0x00A then floatVisual.clear(); cancel() end end)
ashita.events.register('command', 'crcurse_cancel', function(e)
    local original = e.command or ''
    local verb, quoted, targetToken = original:match('^/(%a+)%s+"([^"]+)"%s+(%S+)%s*$')
    if not verb then verb, quoted, targetToken = original:match('^/(%a+)%s+(%S+)%s+(%S+)%s*$') end
    local macroNames = { ['float'] = 1000, ['mana shield'] = 1001, ['impact'] = 1020, ['meteor'] = 1021, ['meteor ii'] = 1022 }
    local id = quoted and macroNames[quoted:lower()]
    local key = id and identity(definitions[id].level)
    if verb and (verb:lower() == 'ma' or verb:lower() == 'magic') and key then
        local memory = AshitaCore:GetMemoryManager()
        local target
        if targetToken:lower() == '<me>' then target = memory:GetParty():GetMemberServerId(0)
        elseif targetToken:lower() == '<t>' then
            local index = memory:GetTarget():GetTargetIndex(0)
            if index and index > 0 then target = memory:GetEntity():GetServerId(index) end
        else
            local partyIndex = targetToken:lower():match('^<p([0-5])>$')
            if partyIndex then target = memory:GetParty():GetMemberServerId(tonumber(partyIndex)) end
        end
        if target and target > 0 then e.blocked = true; prepare(id, target, key); return end
    end
    local command = original:lower()
    if command == '/crcurse cancel' or command == '/crvirus cancel' then cancel(); e.blocked = true end
end)
ashita.events.register('unload', 'crcurse_unload', function() floatVisual.clear(); cancel() end)
