addon.name = 'crcurse'
addon.author = 'Current Reality'
addon.version = '1.2'
addon.desc = 'Prepare Alchemist mixtures before ordinary Curse and Virus spells.'
require('common')
local ffi = require('ffi')
ffi.cdef('unsigned long __stdcall GetTickCount(void);')
local spells = {
    [257] = { name = 'Curse', level = 25, command = '!alccursemix' },
    [256] = { name = 'Virus', level = 10, command = '!alcvirusmix' },
}
local pending
local function now() return tonumber(ffi.C.GetTickCount()) end
local function elapsed(start) return (now() - start) % 4294967296 end

local function identity(level)
    local memory = AshitaCore:GetMemoryManager()
    local player, party = memory:GetPlayer(), memory:GetParty()
    if player:GetLoginStatus() ~= 2 or party:GetMemberHP(0) <= 0 then return end
    local main, sub = player:GetMainJob(), player:GetSubJob()
    local ml, sl = player:GetMainJobLevel(), player:GetSubJobLevel()
    if not ((main == 18 and ml >= level) or (sub == 18 and sl >= level)) then return end
    return table.concat({party:GetMemberServerId(0), party:GetMemberZone(0), main, sub, ml, sl}, ':')
end

ashita.events.register('packet_out', 'crcurse_prepare', function(e)
    if e.id ~= 0x01A or e.injected or e.blocked then return end
    local raw = e.data_modified
    if type(raw) ~= 'string' or #raw < 28 then return end
    local action = raw:byte(11)
    local spell = raw:byte(13) + raw:byte(14) * 256
    local definition = spells[spell]
    local key = definition and identity(definition.level)
    if action == 3 and definition and key then
        e.blocked = true
        if pending and pending.spell == spell and pending.key == key then return end
        local bytes = {raw:byte(1, #raw)}
        pending = { key = key, spell = spell, definition = definition, bytes = bytes, requested = now() }
        AshitaCore:GetChatManager():QueueCommand(1, definition.command)
    elseif action == 3 or action == 0 or action == 2 or action == 4 or action == 7 or action == 9 or action == 16 then
        pending = nil
    end
end)

ashita.events.register('text_in', 'crcurse_ack', function(e)
    local plain = (e.message or ''):gsub('[' .. string.char(0x1E, 0x1F, 0x7F) .. '].', ''):gsub('[%z\r\n\7]+$', '')
    local name, amount = plain:match('^%[Alchemist (%a+)%] Mixing: (%d+)%.$')
    if name ~= 'Curse' and name ~= 'Virus' then return end
    local delay = tonumber(amount)
    if not delay or delay < 1975 or delay > 2500 then return end
    e.blocked = true
    if pending and not pending.started and pending.definition.name == name and
        pending.key == identity(pending.definition.level) then
        pending.started = now()
        pending.delay = delay
    end
end)

ashita.events.register('d3d_present', 'crcurse_cast', function()
    if not pending then return end
    if pending.key ~= identity(pending.definition.level) then pending = nil; return end
    if not pending.started then
        if elapsed(pending.requested) >= 5000 then
            local name = pending.definition.name
            pending = nil
            print('[Alchemist] ' .. name .. ' preparation was not acknowledged. Try again.')
        end
        return
    end
    if elapsed(pending.started) < pending.delay then return end
    local bytes = pending.bytes
    pending = nil
    AshitaCore:GetPacketManager():AddOutgoingPacket(0x01A, bytes)
end)

ashita.events.register('packet_in', 'crcurse_zone', function(e)
    if e.id == 0x00A then pending = nil end
end)
ashita.events.register('command', 'crcurse_cancel', function(e)
    local command = (e.command or ''):lower()
    if command == '/crcurse cancel' or command == '/crvirus cancel' then
        pending = nil
        e.blocked = true
    end
end)
ashita.events.register('unload', 'crcurse_unload', function() pending = nil end)
