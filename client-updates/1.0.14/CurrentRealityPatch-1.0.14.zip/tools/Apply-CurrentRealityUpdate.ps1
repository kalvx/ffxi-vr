param(
  [Parameter(Mandatory=$true)][string]$Root,
  [Parameter(Mandatory=$true)][string]$Manifest,
  [Parameter(Mandatory=$true)][string]$Package,
  [int]$LauncherPid = 0,
  [string]$ReadyFile = '',
  [switch]$ValidateOnly,
  [switch]$NoRelaunch
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem

function Get-PatchHash([string]$Path) {
  $stream = [IO.File]::OpenRead($Path)
  $sha = [Security.Cryptography.SHA256]::Create()
  try { return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
  finally { $stream.Dispose(); $sha.Dispose() }
}

function Assert-ManagedPath([string]$Relative) {
  if (!$Relative -or $Relative -match '[\\:<>"|?*\x00-\x1f]') { throw 'Unsafe update path' }
  $parts = $Relative.Split('/')
  foreach ($part in $parts) {
    if (!$part -or $part -eq '.' -or $part -eq '..' -or $part -match '[. ]$' -or $part -match '^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\.|$)') { throw 'Unsafe update path component' }
  }
  $p = $Relative.ToLowerInvariant()
  $allowed = ($parts.Count -eq 1 -and ($p.EndsWith('.dll') -or $p -eq 'current_reality_launcher.exe')) -or
    $p.StartsWith('data/') -or
    ($p.StartsWith('game/squareenix/playonlineviewer/viewer/') -and $p.EndsWith('.dll')) -or
    ($parts.Count -eq 4 -and $p.StartsWith('game/squareenix/final fantasy xi/') -and ($p.EndsWith('.dll') -or $parts[-1].ToLowerInvariant() -in @('ftable.dat','vtable.dat','patch.ver'))) -or
    ($parts.Count -eq 2 -and $p.StartsWith('runtime/') -and ($p.EndsWith('.dll') -or $p.EndsWith('.exe'))) -or
    ($p -match '^game/squareenix/final fantasy xi/rom(?:[2-9]|[1-9][0-9]+)?/[0-9]+/[0-9]+\.dat$') -or
    ($p -match '^game/squareenix/final fantasy xi/sound[0-9]*/win/music/data/music[0-9]+\.bgw$') -or
    ($p.StartsWith('runtime/addons/') -and $p.EndsWith('.lua') -and !(@($parts | Where-Object { $_.ToLowerInvariant() -in @('settings','config','data','logs','backups','profiles') }).Count)) -or
    ($p -in @('runtime/scripts/default.txt','runtime/bootloader/xiloader.exe','tools/apply-currentrealityupdate.ps1','tools/verifyplayonline.exe','tools/playonline-files.sha256','tools/playonline-official-baseline.sha256','tools/currentreality-diagnostics.ps1','run diagnostics.bat'))
  if (!$allowed) { throw "Not a managed file: $Relative" }
}

function Resolve-SafeTarget([string]$Base, [string]$Relative) {
  $target = [IO.Path]::GetFullPath((Join-Path $Base $Relative.Replace('/', '\')))
  if (!$target.StartsWith($Base.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Target escaped installation' }
  $cursor = $target
  while ($cursor -and $cursor.Length -ge $Base.Length) {
    if (Test-Path -LiteralPath $cursor) {
      $item = Get-Item -LiteralPath $cursor -Force
      if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Linked update destination: $cursor" }
    }
    $cursor = Split-Path -Parent $cursor
  }
  return $target
}

function Assert-File([string]$Path, $Entry) {
  $f = Get-Item -LiteralPath $Path
  if ($f.Length -ne $Entry.size -or (Get-PatchHash $Path) -ne $Entry.sha256) { throw "File verification failed: $($Entry.path)" }
}

$installRoot = [IO.Path]::GetFullPath($Root).TrimEnd('\')
$work = Join-Path ([IO.Path]::GetTempPath()) ('CurrentReality-apply-' + [Guid]::NewGuid().ToString('N'))
$backups = $null
$changes = [Collections.Generic.List[object]]::new()
$success = $false
$validated = $false
try {
  if (!(Test-Path -LiteralPath $installRoot -PathType Container)) { throw 'Installation does not exist' }
  Resolve-SafeTarget $installRoot 'data/update-path-check' | Out-Null
  $release = Get-Content -LiteralPath $Manifest -Raw | ConvertFrom-Json
  if ($release.schemaVersion -ne 1 -or $release.product -ne 'CurrentReality' -or $release.version -notmatch '^\d+\.\d+\.\d+$' -or @($release.files).Count -eq 0) { throw 'Invalid patch manifest' }
  if ($release.packageSha256 -notmatch '^[a-fA-F0-9]{64}$' -or (Get-PatchHash $Package) -ne $release.packageSha256) { throw 'Patch archive checksum mismatch' }
  New-Item -ItemType Directory -Path $work | Out-Null
  $expected = @{}
  foreach ($entry in $release.files) {
    Assert-ManagedPath $entry.path
    if ($expected.ContainsKey($entry.path) -or $entry.sha256 -notmatch '^[a-fA-F0-9]{64}$' -or $entry.size -lt 0) { throw 'Invalid/duplicate patch entry' }
    Resolve-SafeTarget $installRoot $entry.path | Out-Null
    $expected[$entry.path] = $entry
  }
  $zip = [IO.Compression.ZipFile]::OpenRead($Package)
  try {
    $seen = @{}
    foreach ($entry in $zip.Entries) {
      $name = $entry.FullName
      Assert-ManagedPath $name
      if (!$expected.ContainsKey($name) -or $seen.ContainsKey($name)) { throw "Unexpected/duplicate archive member: $name" }
      if ($entry.Length -ne $expected[$name].size) { throw 'Archive length mismatch' }
      $destination = Resolve-SafeTarget $work $name
      New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
      [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $destination)
      Assert-File $destination $expected[$name]
      $seen[$name] = $true
    }
    if ($seen.Count -ne $expected.Count) { throw 'Archive is missing manifest files' }
  } finally { $zip.Dispose() }
  $validated = $true
  if ($ValidateOnly) { Write-Output 'PASS: archive and every managed file verified'; return }
  if ($ReadyFile) {
    $readyPath = [IO.Path]::GetFullPath($ReadyFile)
    $manifestFolder = [IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($Manifest))
    if ([IO.Path]::GetDirectoryName($readyPath) -ne $manifestFolder -or [IO.Path]::GetFileName($readyPath) -ne 'helper-ready.json') { throw 'Unexpected helper startup marker' }
    [IO.File]::WriteAllText($readyPath, '{"validated":true}', [Text.UTF8Encoding]::new($false))
  }
  $deadline = (Get-Date).AddSeconds(60)
  while ($LauncherPid -gt 0 -and (Get-Process -Id $LauncherPid -ErrorAction SilentlyContinue)) {
    if ((Get-Date) -gt $deadline) { throw 'Launcher did not close; patch was not applied' }
    Start-Sleep -Milliseconds 250
  }
  $busy = Get-Process -Name pol,xiloader,current-reality-xiloader,xiloader-diagnostic,Ashita-cli -ErrorAction SilentlyContinue
  if ($busy) { throw 'Close game and loader sessions before updating' }
  $backups = Resolve-SafeTarget $installRoot ('update-backups/' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $backups -Force | Out-Null
  Copy-Item -LiteralPath $Manifest -Destination (Join-Path $backups 'manifest.json')
  foreach ($entry in $release.files) {
    $target = Resolve-SafeTarget $installRoot $entry.path
    $backup = Resolve-SafeTarget $backups $entry.path
    $existed = Test-Path -LiteralPath $target -PathType Leaf
    if ($existed) {
      New-Item -ItemType Directory -Path (Split-Path -Parent $backup) -Force | Out-Null
      Copy-Item -LiteralPath $target -Destination $backup
      if ((Get-PatchHash $target) -ne (Get-PatchHash $backup)) { throw 'Backup verification failed' }
    }
    $changes.Add([pscustomobject]@{ Target=$target; Backup=$backup; Existed=$existed })
    New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
    Copy-Item -LiteralPath (Resolve-SafeTarget $work $entry.path) -Destination $target -Force
    Assert-File $target $entry
  }
  # Include both release state files in rollback, then commit the verified manifest.
  foreach ($relative in @('tools/installed-release.json','tools/installed-manifest.json')) {
    $target = Resolve-SafeTarget $installRoot $relative
    $backup = Resolve-SafeTarget $backups $relative
    $existed = Test-Path -LiteralPath $target -PathType Leaf
    if ($existed) { New-Item -ItemType Directory -Path (Split-Path -Parent $backup) -Force | Out-Null; Copy-Item -LiteralPath $target -Destination $backup }
    $changes.Add([pscustomobject]@{ Target=$target; Backup=$backup; Existed=$existed })
  }
  $installedManifest = Resolve-SafeTarget $installRoot 'tools/installed-manifest.json'
  Copy-Item -LiteralPath $Manifest -Destination $installedManifest -Force
  $state = Resolve-SafeTarget $installRoot 'tools/installed-release.json'
  $stateJson = @{version=$release.version; updatedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json
  [IO.File]::WriteAllText($state, $stateJson, [Text.UTF8Encoding]::new($false))
  Write-Output ('PASS: installed and verified Current Reality ' + $release.version)
  $success = $true
  [IO.File]::WriteAllText((Join-Path $installRoot 'tools/update-last-result.txt'), ('Installed and verified ' + $release.version), [Text.UTF8Encoding]::new($false))
} catch {
  $reason = $_.Exception.Message
  $rollbackErrors = [Collections.Generic.List[string]]::new()
  for ($i=$changes.Count-1; $i -ge 0; $i--) {
    $change = $changes[$i]
    try {
      if ($change.Existed) { Copy-Item -LiteralPath $change.Backup -Destination $change.Target -Force }
      elseif (Test-Path -LiteralPath $change.Target) { Remove-Item -LiteralPath $change.Target -Force }
    } catch { $rollbackErrors.Add($_.Exception.Message) }
  }
  if ($rollbackErrors.Count) { $reason += '; rollback needs attention: ' + ($rollbackErrors -join '; ') }
  if (!$ValidateOnly -and (Test-Path -LiteralPath (Join-Path $installRoot 'tools') -PathType Container)) {
    [IO.File]::WriteAllText((Join-Path $installRoot 'tools/update-last-error.txt'), $reason, [Text.UTF8Encoding]::new($false))
  }
  if (!$ValidateOnly -and !$NoRelaunch) {
    Add-Type -AssemblyName System.Windows.Forms
    [Windows.Forms.MessageBox]::Show("Update failed: $reason`nBackup: $backups", 'Current Reality Update') | Out-Null
  }
  Write-Error $reason -ErrorAction Continue
} finally {
  $resolvedWork = [IO.Path]::GetFullPath($work)
  $expectedTemp = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\') + '\'
  if (!$resolvedWork.StartsWith($expectedTemp, [StringComparison]::OrdinalIgnoreCase) -or (Split-Path -Leaf $resolvedWork) -notmatch '^CurrentReality-apply-[a-f0-9]{32}$') { throw 'Refusing unsafe update cleanup path' }
  if (Test-Path -LiteralPath $resolvedWork) { Remove-Item -LiteralPath $resolvedWork -Recurse -Force }
  if (!$ValidateOnly -and !$NoRelaunch -and ($success -or $changes.Count -gt 0)) {
    Start-Process -FilePath (Join-Path $installRoot 'current_reality_launcher.exe') -WorkingDirectory $installRoot
  }
}
if (!$success -and !$ValidateOnly) { exit 1 }
if ($ValidateOnly -and !$validated) { exit 1 }
