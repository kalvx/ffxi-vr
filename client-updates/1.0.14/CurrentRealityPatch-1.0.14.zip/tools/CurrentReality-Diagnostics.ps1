param([string]$Root = (Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference = 'Continue'
$report = Join-Path $Root 'CurrentReality-diagnostics.txt'
$lines = [Collections.Generic.List[string]]::new()
function Record([string]$Text) { $lines.Add($Text); Write-Output $Text }
Record ('Current Reality diagnostics / ' + [DateTime]::UtcNow.ToString('o'))
Record ('Installation: ' + $Root)
Record ('Windows: ' + [Environment]::OSVersion.VersionString)
foreach ($relative in @('current_reality_launcher.exe','Runtime/Ashita-cli.exe','Runtime/bootloader/xiloader.exe','Runtime/plugins/addons.dll','Game/SquareEnix/FINAL FANTASY XI/FFXiMain.dll','tools/installed-release.json','tools/update-config.json')) {
  $path = Join-Path $Root $relative
  if (Test-Path -LiteralPath $path -PathType Leaf) { Record ('PASS file: ' + $relative) } else { Record ('MISSING file: ' + $relative) }
}
$profile = Join-Path $Root 'Runtime/config/boot/current-reality.ini'
if (Test-Path -LiteralPath $profile) {
  $text = Get-Content -LiteralPath $profile -Raw
  Record ('Hairpin enabled: ' + [bool]($text -match '(?m)^command\s*=.*--hairpin'))
  # Report connectivity without copying account arguments or personal settings.
  if ($text -match '(?m)^command\s*=.*--server\s+(\S+)') {
    $server = $Matches[1]
    foreach ($port in @(54230,54231,54001,54002)) {
      $tcp = [Net.Sockets.TcpClient]::new()
      try { $task = $tcp.ConnectAsync($server,$port); $ok = $task.Wait(1500) -and $tcp.Connected; Record ("Server $server port ${port}: $ok") }
      catch { Record ("Server $server port ${port}: unavailable") }
      finally { $tcp.Dispose() }
    }
  }
}
try {
  Add-Type -TypeDefinition @'
using System.Runtime.InteropServices;
public static class CRControllerDiagnostics {
 [DllImport("xinput1_4.dll")] public static extern uint XInputGetState(uint index, System.IntPtr state);
}
'@
  $buffer = [Runtime.InteropServices.Marshal]::AllocHGlobal(32)
  try { foreach ($index in 0..3) { Record ("XInput controller ${index}: " + ([CRControllerDiagnostics]::XInputGetState($index,$buffer) -eq 0)) } }
  finally { [Runtime.InteropServices.Marshal]::FreeHGlobal($buffer) }
} catch { Record ('XInput diagnostic failed: ' + $_.Exception.Message) }
$verifier = Join-Path $Root 'tools/VerifyPlayOnline.exe'
if (Test-Path -LiteralPath $verifier) {
  $pol = Join-Path $Root 'Game/SquareEnix/PlayOnlineViewer'
  $comReport = Join-Path $Root 'PlayOnline-registration-check.txt'
  & $verifier $pol $comReport
  Record ('PlayOnline files and COM activation verifier exit: ' + $LASTEXITCODE)
  if (Test-Path -LiteralPath $comReport) { foreach ($line in (Get-Content -LiteralPath $comReport)) { Record $line } }
}
$lines | Set-Content -LiteralPath $report -Encoding UTF8
Write-Output ('Report saved: ' + $report)
