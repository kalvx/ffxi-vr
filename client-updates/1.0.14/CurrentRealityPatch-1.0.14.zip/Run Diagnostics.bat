@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\CurrentReality-Diagnostics.ps1" -Root "%~dp0"
pause
