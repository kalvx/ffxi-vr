addon.name='cralcbot';addon.author='Current Reality';addon.version='1.2';
addon.desc='Opt-in Max Potion, mixed Max Potion and Guard Drink support for your party and trusts.';
require('common')
local imgui=require('imgui');local settings=require('settings');local ffi=require('ffi')
local packets=require('cr_packets');local policy=require('cr_alc_policy')
ffi.cdef('unsigned long long __stdcall GetTickCount64(void);')
local function now()return tonumber(ffi.C.GetTickCount64())/1000 end
local config=settings.load(T{visible=true})
config.visible=true -- Loading explicitly reopens the panel even after Hide/X.
local state={enabled=false,message='Stopped. Start to assist your party.',nonce=0,nextQuery=0,busyUntil=0}
local function queue(text)AshitaCore:GetChatManager():QueueCommand(1,text)end
local function stop(reason)
    state.enabled=false;state.request=nil;state.report=nil;state.message=reason or'Stopped.'
end
local function snapshot()
    local mem=AshitaCore:GetMemoryManager();local p,party,entities=mem:GetPlayer(),mem:GetParty(),mem:GetEntity()
    if p:GetLoginStatus()~=2 or party:GetMemberIsActive(0)==0 then return nil end
    local own=party:GetMemberServerId(0);local index=party:GetMemberTargetIndex(0)
    if not own or own<=0 or index<=0 or index>2303 then return nil end
    local job,zone=p:GetMainJob(),party:GetMemberZone(0)
    local status=entities:GetStatusServer(index)
    local input=AshitaCore:GetChatManager():IsInputOpen()
    local s={id=own,zone=zone,job=job,level=p:GetMainJobLevel(),hp=party:GetMemberHP(0),status=status,
        typing=input==true or(type(input)=='number'and input%2==1),party={}}
    s.key=table.concat({own,zone,job,p:GetSubJob()},':')
    for slot=0,5 do
        if party:GetMemberIsActive(slot)~=0 then
            local mid,target=party:GetMemberServerId(slot),party:GetMemberTargetIndex(slot)
            if mid and mid>0 and target and target>0 and target<=2303 and entities:GetServerId(target)==mid then
                local d=entities:GetDistance(target)
                s.party[mid]={slot=slot,hpp=party:GetMemberHPPercent(slot),alive=party:GetMemberHP(slot)>0,
                    sameZone=party:GetMemberZone(slot)==zone,inRange=slot==0 or(type(d)=='number'and d>=0 and d<=18*18)}
            end
        end
    end
    return s
end
local function valid(s)
    if not s or s.job~=18 or s.level<1 or s.hp<=0 or(s.status~=0 and s.status~=1)then return false end
    if state.key and state.key~=s.key then return false end
    return true
end
local function start()
    local s=snapshot()
    if not s or s.job~=18 or s.hp<=0 then state.message='Use main-job Alchemist while alive to start.';return end
    state.enabled=true;state.key=s.key;state.nextQuery=0;state.request=nil;state.report=nil
    state.message='Running: Max Potion, mixed fallback, then missing Protect/Shell.'
end
local function telemetry(text)
    if type(text)~='string'or not text:find('^%[CRALC1%]')then return false end
    if not state.enabled then return true end
    local s=snapshot()
    if not valid(s)or not state.request or state.request.key~=s.key then return true end
    local report=policy.parse(text,state.request,now())
    if report then state.report=report;state.request=nil end
    return true
end
local function tick()
    if not state.enabled then return end
    local s=snapshot();local time=now()
    if not valid(s)then stop('Stopped: job, zone, party session or player status changed.');return end
    if s.typing or time<state.busyUntil then return end
    if state.pending and time<state.pending.expires then return end
    state.pending=nil
    local action=policy.choose(state.report,s.party,time)
    if action then
        -- Revalidate the exact party member immediately before the ordinary job-ability command.
        if not s.party[action.id]then return end
        local command=string.format('/ja "%s" <p%d>',action.name,action.slot)
        state.pending={command=command,id=action.id,slot=action.slot,ability=action.ability,key=s.key,expires=time+3}
        state.report=nil;state.busyUntil=time+2;state.nextQuery=time+2.5
        state.message=action.name..' → '..(action.slot==0 and'you'or'party '..action.slot)
        queue(command);return
    end
    if time>=state.nextQuery then
        state.nonce=state.nonce%99999998+1
        state.request={nonce=state.nonce,zone=s.zone,key=s.key,time=time}
        state.nextQuery=time+2.5;queue('/say !cralcbot '..state.nonce)
    end
end
settings.register('settings','cralcbot_settings',function(s)if s then config=s end;config.visible=true;stop('Stopped: character settings changed.')end)
ashita.events.register('command','cralcbot_commands',function(e)
    local args=e.command:lower():match('^/cralcbot%s*(.-)%s*$')
    if args~=nil then
        e.blocked=true
        if args=='start'then start()
        elseif args=='stop'then stop()
        elseif args=='show'then config.visible=true
        elseif args=='hide'then config.visible=false
        elseif args=='status'then print('[cralcbot] '..state.message)
        elseif args==''then config.visible=not config.visible
        else print('[cralcbot] start | stop | show | hide. Max Potion first, Mix: Max Potion fallback; Guard Drink when Protect or Shell is missing.')end
        settings.save();return
    end
    if state.pending and e.command==state.pending.command then
        local s=snapshot();local member=s and s.party[state.pending.id]
        if not state.enabled or not valid(s)or not member or member.slot~=state.pending.slot or not member.alive
            or not member.sameZone or not member.inRange or now()>state.pending.expires then e.blocked=true end
    elseif e.command:lower():match('^/ma[gic]*%s')or e.command:lower():match('^/item%s')then
        state.busyUntil=now()+40
    end
end)
ashita.events.register('packet_in','cralcbot_packets',function(e)
    local raw=e.data_modified or e.data
    if e.id==0x017 and type(raw)=='string'and #raw>=24 and raw:byte(5)==6 then
        if telemetry(raw:sub(24))then e.blocked=true end
    elseif e.id==0x00A or e.id==0x00B then stop('Stopped after zoning. Start again when ready.')
    elseif e.id==0x028 then
        local a=packets.action(raw);local s=snapshot()
        if not a or not s or a.actor~=s.id then return end
        if a.category==8 then state.busyUntil=a.id==28787 and now()+1 or now()+40
        elseif a.category==4 or a.category==5 or a.category==6 or a.category==11 then
            state.busyUntil=now()+2;state.report=nil
            if state.pending then state.pending=nil end
        end
    end
end)
ashita.events.register('text_in','cralcbot_quiet',function(e)
    local plain=(e.message or e.message_modified or''):gsub('[\30\31\127].',''):gsub('%z.*$','')
    if telemetry(plain)then e.blocked=true;return end
    local name,command=plain:match('^([%a]+)%s*:%s*(!cralcbot%s+%d+)%s*$')
    local own=AshitaCore:GetMemoryManager():GetParty():GetMemberName(0)
    if name==own and command then e.blocked=true end
end)
ashita.events.register('d3d_present','cralcbot_draw',function()
    local ok,err=pcall(tick);if not ok then stop('Stopped: '..tostring(err))end
    if not config.visible then return end
    imgui.SetNextWindowSize({0,0},ImGuiCond_Always)
    local flags=ImGuiWindowFlags_AlwaysAutoResize+ImGuiWindowFlags_NoTitleBar+ImGuiWindowFlags_NoBackground+
        ImGuiWindowFlags_NoResize+ImGuiWindowFlags_NoCollapse+ImGuiWindowFlags_NoFocusOnAppearing
    if imgui.Begin('CR Alchemist Helper',nil,flags)then
        imgui.Button('Move',{264,44})
        if imgui.IsItemActive()and imgui.IsMouseDragging(0)then
            local dx,dy=imgui.GetMouseDragDelta(0);local x,y=imgui.GetWindowPos()
            if type(dx)=='table'then dx,dy=dx[1],dx[2]end
            if type(x)=='table'then x,y=x[1],x[2]end
            imgui.SetWindowPos({x+dx,y+dy});imgui.ResetMouseDragDelta(0)
        end
        imgui.Dummy({0,8})
        imgui.Text(state.enabled and'Running'or'Stopped')
        if imgui.Button(state.enabled and'Stop'or'Start',{80,64})then if state.enabled then stop()else start()end end
        imgui.SameLine(0,12);if imgui.Button('Hide',{80,64})then config.visible=false;settings.save()end
        imgui.SameLine(0,12);if imgui.Button('X',{80,64})then config.visible=false;settings.save()end
    end
    imgui.End()
end)
ashita.events.register('unload','cralcbot_unload',function()stop();settings.save()end)
