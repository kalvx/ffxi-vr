addon.name = 'crmixing'
addon.author = 'Current Reality'
addon.version = '1.3'
addon.desc = 'Native Combat Skills Mixing entry and normal skill-up chat.'
require('common')
local bit = require('bit')
local state = { name = '', value = nil, cap = nil }
local slot = 0
local owned = false
local disabled = 0x8000
local function resetForCharacter(current)
    if state.name ~= '' and state.name ~= current then
        state.name=''; state.value=nil; state.cap=nil
    end
end
local function updateNative()
    if slot == 0 then return end
    local manager=AshitaCore:GetMemoryManager()
    local current=manager:GetParty():GetMemberName(0)
    resetForCharacter(current)
    local previous=ashita.memory.read_uint16(slot)
    -- Claim only the verified unused slot after the game has received skills.
    if not owned then
        if previous ~= disabled then return end
        owned=true
    end
    local desired=disabled
    if current and current ~= '' and manager:GetPlayer():GetMainJob()==18 then
        desired=math.min(32767, math.max(0,math.floor((state.value or 0)+0.000001)))
        if desired>0 and state.cap and state.value>=state.cap then desired=desired+disabled end
    end
    if previous~=desired then ashita.memory.write_uint16(slot,desired) end
end
ashita.events.register('load', 'crmixing_load', function()
    -- Verified once in this H client. The absolute operand is relocated by Windows.
    -- It addresses the same native skill array used by the Combat Skills renderer.
    local found=ashita.memory.find('FFXiMain.dll',0,'8D0C4D????????668B0184E479??A9FF7F000074014783C1024A75??',0,0) or 0
    if found~=0 then
        local base=ashita.memory.read_uint32(found+3)
        if base~=0 then slot=base+13*2 end
    end
    if slot==0 then print('[Mixing] Native skill display unavailable: client signature differs.') end
end)
ashita.events.register('unload', 'crmixing_unload', function()
    if owned and slot~=0 then ashita.memory.write_uint16(slot,disabled) end
    slot=0;owned=false
end)
ashita.events.register('text_in', 'crmixing_text', function(e)
    -- Server packet channels and Ashita rendered-chat modes use different IDs.
    -- Recognize only this exact system-report payload, after removing client colors.
    local message=e.message or ''
    local plain=message:gsub('['..string.char(0x1E,0x1F,0x7F)..'].',''):gsub('[%z\r\n\7]+$','')
    local name,value,cap,suffix=plain:match('^%[Mixing%] (%a+): ([%d.]+) / ([%d.]+)(.*)$')
    if not name or (suffix~='' and not suffix:match('^ %(%+[%d.]+%)$')) then return end
    local current=AshitaCore:GetMemoryManager():GetParty():GetMemberName(0)
    if name~=current then e.blocked=true;return end
    local number,maximum=tonumber(value),tonumber(cap)
    if not number or not maximum then return end
    state.name=name;state.value=number;state.cap=maximum
    updateNative()
    local gained=tonumber(suffix:match('%(%+([%d.]+)%)')) or 0
    if gained<=0 then e.blocked=true;return end
    local replacement=string.format("%s's mixing skill rises %.1f points.",name,gained)
    if math.floor(number+0.000001)>math.floor(number-gained+0.000001) then
        replacement=replacement..string.format("\n%s's mixing skill reaches level %d.",name,math.floor(number+0.000001))
    end
    local edited=e.message_modified or message
    local start=edited:find('[Mixing]',1,true)
    e.message_modified=(start and edited:sub(1,start-1) or '')..replacement
end)
ashita.events.register('command', 'crmixing_command', function(e)
    if e.command:lower():match('^/mixing%s*$') then
        e.blocked=true
        print(string.format('Mixing skill: %d.',math.floor((state.value or 0)+0.000001)))
    elseif e.command:lower():match('^/mixing%s+debug%s*$') then
        e.blocked=true
        print(string.format('[Mixing] native slot=%s; synced=%s',slot~=0 and 'ready' or 'unavailable',state.value and tostring(state.value) or 'waiting'))
    end
end)
ashita.events.register('d3d_present', 'crmixing_present', updateNative)
