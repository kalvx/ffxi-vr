-- Read-only current-target elemental telemetry for the personal crmm addon.
-- No SQL, character variables, stats, quests, equipment or progression are changed.
local command = { cmdprops = { permission = 0, parameters = 'ii' } }
local last = {}
command.onTrigger = function(player, requestedId, nonce)
    if not requestedId or not nonce or nonce < 1 or nonce > 99999999 then return end
    local now = os.time()
    local id = player:getID()
    if last[id] and now-last[id] < 2 then return end
    last[id] = now
    local target = player:getCursorTarget()
    if not target or not target:isMob() or target:getID()~=requestedId
        or target:getHP()<=0 or player:checkDistance(target)>30 then return end
    -- Eight elements in server order: fire, ice, wind, earth, thunder, water, light, dark.
    -- Rank, SDT, elemental MEVA, absorb chance, null chance. General chances are included.
    for part=1,2 do
        local values={}
        for e=(part-1)*4+1,part*4 do
            values[#values+1]=table.concat({target:getMod(191+e),target:getMod(53+e),target:getMod(14+e),
                math.max(target:getMod(458+e),target:getMod(475),target:getMod(480)),
                math.max(target:getMod(466+e),target:getMod(476),target:getMod(142))},',')
        end
        player:printToPlayer(string.format('[CRMM1] %d %d %d %d %s',nonce,requestedId,player:getZoneID(),part,table.concat(values,';')),6)
    end
end
return command
