local core=require('crmm_core')
local data=require('crmm_data')
local count=0
local function check(ok,label) assert(ok,label); count=count+1 end
check(core.chain(data,{props={3}},{props={8}})==11,'Liquefaction -> Impaction gives Fusion')
check(core.chain(data,{props={8}},{props={3}})==3,'Reverse order is different')
check(core.chain(data,{props={1,3}},{props={8,4}})==10,'Server opening-property priority respected')
check(data.pets[598].props[1]==12,'Server level-70 pact properties included')
check(data.pets[544].mp==9 and data.pets[544].bit==32,'Pact cost and client menu bit exported')
check(data.pets[518]==nil,'Astral Flow excluded')
local avatars={}; for _,p in pairs(data.pets) do avatars[p.avatar]=true end
check(avatars.Carbuncle and avatars.Fenrir and avatars.Ifrit and avatars.Titan and avatars.Leviathan and avatars.Garuda and avatars.Shiva and avatars.Ramuh and avatars['Cait Sith'] and avatars.Diabolos,'All ten server chain-capable avatars represented')
check(not avatars.Siren,'Siren has no chain properties in this server dataset; do not invent them')
local weak={}; for i=1,8 do weak[i]={0,0,0,0,0} end
check(core.elementScore({-2,0,0,0,0})>core.elementScore({2,0,0,0,0}),'Lower resistance rank preferred')
check(core.elementScore({0,-5000,0,0,0})>core.elementScore({0,5000,0,0,0}),'SDT uses correct damage-taken sign')
check(core.elementScore({-5,0,0,1,0})==nil,'Absorbing element excluded')
check(core.elementScore({-5,0,0,0,100})==nil,'Null element excluded')
local w={id=1,kind='ws',actor=1,props={3},mp=0,name='WS'}
local pet={id=544,kind='pet',actor=2,props={8},mp=9,avatar='Ifrit',name='Pact'}
local fire={id=145,kind='spell',actor=1,element=1,mp=20,tier=2,name='Fire II',jobs={[4]=18}}
local fire1={id=144,kind='spell',actor=1,element=1,mp=5,tier=1,name='Fire',jobs={[4]=13}}
check(core.castable(fire,{main=15,sub=4,level=75,sublevel=37}),'Subjob level permits learned spell')
check(not core.castable(fire,{main=15,sub=3,level=75,sublevel=37}),'Known but unusable job spell rejected')
check(not core.castable(fire,{main=15,sub=4,level=20,sublevel=10}),'Subjob level requirement respected')
local plan=core.plan(data,{w},{pet},{fire,fire1},weak,100)[1]
check(plan and plan.spell==fire and plan.first==w,'Picks full chain + Tier II burst')
local reverseWS={id=2,kind='ws',actor=1,props={8},mp=0,name='WS'}
local reversePet={id=545,kind='pet',actor=2,props={3},mp=9,avatar='Ifrit',name='Pact'}
check(core.plan(data,{reverseWS},{reversePet},{fire},weak,100)[1].first==reversePet,'Pet-first order chosen when it makes the stronger chain')
check(core.plan(data,{w},{pet},{fire,fire1},weak,15)[1].spell==fire1,'Reserves pact MP and falls back to Tier I')
check(core.plan(data,{w},{pet},{},weak,100)[1].spell==nil,'Chain-only plan explicitly represented')
check(#core.plan(data,{w},{pet},{fire},weak,8)==0,'Insufficient pact MP gives no plan')
check(#core.plan(data,{},{pet},{fire},weak,100)==0,'No known weapon skill means no plan')
local time,commands,reason,allow=0,{},nil,true
local runner=core.runner({now=function() return time end,send=function(a) commands[#commands+1]=a end,
    message=function(s) reason=s end,valid=function() return allow,'identity changed' end,ready=function() return allow,'not ready' end})
local identity={target=3}
local function event(a,effect,success)
    return {actor=a.actor,target=3,id=a.id,kind=a.kind,success=success~=false,effect=effect,chainAction=a.kind~='spell'}
end
runner:start(plan,identity)
check(#commands==1,'Run sends only opener')
runner:start(plan,identity); check(#commands==1,'Double-click does not duplicate opener')
runner:action({actor=999,target=99,id=1,kind='ws',chainAction=true})
check(runner.active~=nil,'Unrelated target ignored')
runner:action(event(plan.first)); time=3; runner:tick()
check(#commands==1,'Closer waits beyond three seconds')
time=3.4; runner:tick(); check(#commands==2,'Confirmed opener schedules closer')
runner:action(event(plan.second,core.effects[plan.chain])); time=4.5; runner:tick()
check(#commands==3 and commands[3]==fire,'Only confirmed expected chain triggers burst')
local burst=event(fire); burst.burst=true; runner:action(burst)
check(not runner.active and reason:find('Magic burst confirmed',1,true),'Server burst completion reported')
runner:start(plan,identity); runner:action(event(plan.first)); time=time+3.4; runner:tick(); runner:action(event(plan.second,nil))
check(not runner.active and reason:find('not confirmed',1,true),'No chain confirmation cancels burst')
runner:start(plan,identity); runner:action(event(plan.first,nil,false)); check(not runner.active,'Miss cancels sequence')
runner:start(plan,identity); local before=#commands; runner:stop(); time=time+20; runner:tick(); check(#commands==before,'Stop prevents remaining commands')
runner:start(plan,identity); time=time+13; runner:tick(); check(not runner.active,'No action acknowledgement times out')
runner:start(plan,identity); allow=false; runner:tick(); check(not runner.active,'Identity changes cancel')
allow=true; runner:start(plan,identity); runner:action({actor=99,target=3,id=3,kind='ws',chainAction=true}); check(not runner.active,'Competing chain action cancels')

-- Server helper: mocked player has no mutation API; any state-changing call would fail.
local clock=os.time; local serverTime=100; os.time=function() return serverTime end
local lines={}; local targetId,alive,mob,range=3,true,true,3
local target={isMob=function() return mob end,getID=function() return targetId end,getHP=function() return alive and 10 or 0 end,
    getMod=function(_,id) return id==192 and -2 or 0 end}
local player={getID=function() return 1 end,getCursorTarget=function() return target end,checkDistance=function() return range end,
    getZoneID=function() return 230 end,printToPlayer=function(_,s,mode) check(mode==6,'Telemetry is private system text'); lines[#lines+1]=s end}
local server=assert(loadfile(TEST_DIR..'/../server/crmm.lua'))()
server.onTrigger(player,3,7); check(#lines==2 and lines[1]:find('[CRMM1] 7 3 230 1',1,true),'Server returns two correlated telemetry parts')
server.onTrigger(player,3,8); check(#lines==2,'Server query rate limited')
serverTime=103; server.onTrigger(player,4,9); check(#lines==2,'Target-ID race rejected')
serverTime=106; mob=false; server.onTrigger(player,3,10); check(#lines==2,'Non-monster rejected')
serverTime=109; mob=true; range=50; server.onTrigger(player,3,11); check(#lines==2,'Remote target rejected')
serverTime=112; range=3; alive=false; server.onTrigger(player,3,12); check(#lines==2,'Dead target rejected')
os.time=clock

-- Actual addon under a simulated Ashita client.
local callbacks,chat,logs={},{},{}
local current={target=3,pet=2,mp=100,tp=1000,status=1,job=15,sub=4,level=75,sublevel=37,spell=true,ws=true,pact=true,recast=0,buffs={},online=true}
time=100
local party={GetMemberTargetIndex=function() return 1 end,GetMemberServerId=function(_,i) return i==0 and 1 or 0 end,
    GetMemberIsActive=function(_,i) return i==0 and 1 or 0 end,GetMemberZone=function() return 230 end,
    GetMemberMP=function() return current.mp end,GetMemberTP=function() return current.tp end,GetMemberHP=function() return 100 end}
local p={GetLoginStatus=function() return current.online and 2 or 0 end,HasAbilityData=function() return true end,HasSpellData=function() return true end,
    GetMainJob=function() return current.job end,GetSubJob=function() return current.sub end,GetMainJobLevel=function() return current.level end,
    GetSubJobLevel=function() return current.sublevel end,HasWeaponSkill=function() return current.ws end,
    HasSpell=function(_,id) return id==288 or current.spell end,
    HasAbility=function(_,id) assert(id==1056,'Pet availability must use resource ID, not menu bit'); return current.pact end,
    GetBuffs=function() return current.buffs end}
local entity={GetTargetedIndex=function(_,i) if i==2 then return current.petTarget or current.target end; return current.battleTarget or current.target end,GetSpawnFlags=function() return 16 end,GetHPPercent=function(_,i) return i==current.target and (current.mobHP or 100) or 100 end,GetPetTargetIndex=function() return current.pet end,
    GetServerId=function(_,i) return i end,GetName=function(_,i) return i==2 and 'Ifrit' or 'Monster' end,GetStatusServer=function() return current.status end,
    GetDistance=function() return 4 end,GetLocalPositionX=function(_,i) return i end,GetLocalPositionY=function() return 0 end,
    GetLocalPositionZ=function() return 0 end,GetClaimStatus=function() return current.claim or 0 end}
local recast={GetAbilityTimerId=function() return 173 end,GetAbilityTimer=function() return current.recast end,GetSpellTimer=function() return current.spellRecast or 0 end}
local inv={GetEquippedItem=function() return {Index=1} end,GetContainerItem=function() return {Id=100,Extra='a'} end}
local mem={GetPlayer=function() return p end,GetParty=function() return party end,GetEntity=function() return entity end,
    GetTarget=function() return {GetTargetIndex=function() return current.target end} end,GetInventory=function() return inv end,GetRecast=function() return recast end}
local resource={GetAbilityById=function(_,id) return {Name={[1]=id==1 and 'Test WS' or 'Shock Strike'}} end,
    GetSpellById=function() return {Name={[1]='Fire II'}} end,
    GetSpellByName=function(_,name) if name=='Ifrit' then return {Index=288} end end}
AshitaCore={GetMemoryManager=function() return mem end,GetResourceManager=function() return resource end,
    GetChatManager=function() return {QueueCommand=function(_,mode,text) chat[#chat+1]=text end} end}
ashita={events={register=function(event,name,fn) callbacks[event]=fn end},bits={}}
addon={}; ImGuiCond_FirstUseEver=1
package.loaded.common={}
package.loaded.ffi={cdef=function() end,C={GetTickCount=function() return time*1000 end}}
package.loaded.imgui=setmetatable({Begin=function() return true end,Button=function() return false end},{__index=function() return function() end end})
package.loaded.crmm_data={ws={[1]={props={3},range=5}},pets={[544]={props={8},range=10,mp=9,avatar='Ifrit',bit=32,level=1,recast=173,add=0}},spells={[145]=fire},chains=data.chains}
local oldprint=print; print=function(s) logs[#logs+1]=s end
assert(loadfile(TEST_DIR..'/../crmm.lua'))()
local function command(s) local e={command=s}; callbacks.command(e); return e.blocked end
local function frame(dt) time=time+(dt or .2); callbacks.d3d_present() end
local function response()
    local targetId,nonce
    for i=#chat,1,-1 do targetId,nonce=chat[i]:match('!crmm (%d+) (%d+)'); if targetId then break end end
    for part=1,2 do
        local body=string.format('[CRMM1] %s %s 230 %d 0,0,0,0,0;0,0,0,0,0;0,0,0,0,0;0,0,0,0,0',nonce,targetId,part)
        local e={id=0x17,data=string.rep('\0',4)..string.char(6)..string.rep('\0',18)..body..'\0\0\0'}
        callbacks.packet_in(e)
        check(e.blocked,'Raw private scan reply consumed before chat rendering')
    end
end
local function actionCommands()
    local n=0; for _,s in ipairs(chat) do if not s:find('/say ',1,true) then n=n+1 end end; return n
end
check(not command('/crmmother'),'Unrelated commands not intercepted')
command('/crmm scan'); response(); frame()
check(actionCommands()==0,'Scan and live preview send no combat commands')
frame(6); response(); check(actionCommands()==0,'Automatic scan never starts combat')
current.tp=999; command('/crmm run'); frame(6); response()
check(actionCommands()==0 and logs[#logs]:find('1000',1,true),'Run below TP threshold refused')
current.tp=1000; command('/crmm run'); frame(6); response()
check(actionCommands()==1 and chat[#chat]:find('/ws',1,true),'Run starts one planned opener after fresh scan')
command('/crmm run'); check(actionCommands()==1,'Repeated Run does not duplicate')
command('/crmm stop')
local raw=string.rep('\0',8)..string.char(3,0,7,0,1,0)
local out={id=0x1A,data=raw}; callbacks.packet_out(out)
check(out.blocked,'Stop blocks a queued action that has not left client')
current.claim=999; command('/crmm run'); frame(6); response()
check(actionCommands()==1 and logs[#logs]:find('claimed',1,true),'Foreign claimed target refused')
current.claim=0; current.pact=false; command('/crmm run'); frame(6); response()
check(actionCommands()==1,'Unavailable pet menu bit prevents execution')
current.pact=true; current.spell=false; command('/crmm scan'); frame(6); response()
check(actionCommands()==1,'No learned burst never invents a cast')
current.spell=true; command('/crmm run'); current.target=4; frame(); response()
check(actionCommands()==1,'Target change during query cancels Run intent')
current.target=3; current.recast=50; command('/crmm run'); frame(6); response()
check(actionCommands()==1,'Rage recast prevents starting an impossible combo')
current.recast=0; command('/crmm run'); frame(6); response(); check(actionCommands()==2,'Run recovers after cooldown')
callbacks.packet_in({id=0x00B}); frame(20); check(actionCommands()==2,'Zoning cancels remaining sequence')
-- Feed actual bit-packed action packets through the addon parser and scheduler.
ashita.bits.unpack_be=function(raw,base,offset,n)
    local value=0
    for i=0,n-1 do value=value+(raw[offset+i] or 0)*2^i end
    return value
end
local function actionPacket(actor,category,id,message,effect,effectMessage)
    local raw,offset={},40
    local function write(value,n)
        for i=0,n-1 do raw[offset+i]=math.floor(value/2^i)%2 end
        offset=offset+n
    end
    write(actor,32); write(1,6); write(0,4); write(category,4); write(id,32); write(0,32)
    write(current.target,32); write(1,4); write(8,5); write(0,12); write(0,7); write(0,3)
    write(100,17); write(message,10); write(0,31); write(effect and 1 or 0,1)
    if effect then write(effect,10); write(100,17); write(effectMessage or 287+effect,10) end
    write(0,1)
    return {id=0x28,size=math.ceil(offset/8),data_raw=raw}
end
local function runFresh()
    local previous=actionCommands()
    command('/crmm run')
    response()
    if actionCommands()==previous then frame(5.1); response() end
end
runFresh()
local n=actionCommands()
callbacks.packet_in(actionPacket(1,3,1,185)); frame(3.4)
check(actionCommands()==n+1 and chat[#chat]:find('/pet',1,true),'Real packet parser advances WS to pet: '..tostring(logs[#logs])..' / '..tostring(chat[#chat]))
callbacks.packet_in(actionPacket(2,13,544,317,6)); frame(1.1)
check(actionCommands()==n+2 and chat[#chat]:find('/ma "Fire II"',1,true),'Real packet parser verifies Fusion and casts learned Fire II')
callbacks.packet_in(actionPacket(1,4,145,252)); frame()
check(logs[#logs]:find('Magic burst confirmed',1,true),'Burst message 252 confirmed through full addon')
runFresh()
n=actionCommands(); callbacks.packet_in(actionPacket(1,3,1,185)); frame(3.4)
callbacks.packet_in(actionPacket(2,13,544,317,6,390)); frame(2)
check(actionCommands()==n+1 and logs[#logs]:find('not confirmed',1,true),'Absorbed skillchain does not trigger burst')
runFresh()
n=actionCommands(); callbacks.packet_in(actionPacket(1,3,1,185)); frame(3.4)
callbacks.packet_in(actionPacket(2,13,544,317,6)); frame(1.1)
callbacks.packet_in(actionPacket(1,4,145,264))
check(logs[#logs]:find('did not confirm',1,true),'Secondary damage message is not misreported as burst')
runFresh()
callbacks.packet_in({id=0x28,size=5,data_raw={}})
check(logs[#logs]:find('Malformed',1,true),'Truncated action packet stops execution')
runFresh()
current.target=4
out={id=0x1A,data=string.rep('\0',8)..string.char(4,0,7,0,1,0)}; callbacks.packet_out(out)
check(out.blocked,'Outgoing target race is blocked before action transmission')
-- Auto mode waits without Run and repeats only when resources recover.
command('/crmm stop'); current.target=3; current.tp=0
local function autoFrames(n)
    for i=1,n do frame(1.1); response(); frame(.2) end
end
n=actionCommands(); command('/crmm auto on'); autoFrames(6)
check(actionCommands()==n,'Auto waits for TP')
current.tp=1000; current.recast=30; autoFrames(5)
check(actionCommands()==n,'Auto waits for pact cooldown')
current.recast=0; current.spellRecast=20; autoFrames(5)
check(actionCommands()==n,'Auto waits for burst cooldown instead of dropping burst')
current.spellRecast=0; current.mp=10; autoFrames(5)
check(actionCommands()==n,'Auto waits for whole sequence MP')
current.mp=100; current.battleTarget=4; autoFrames(5)
check(actionCommands()==n,'Auto requires selected target to match engaged target')
current.battleTarget=3; current.status=0; autoFrames(5)
check(actionCommands()==n,'Auto does not engage enemies')
current.status=1; autoFrames(3)
check(actionCommands()==n+1,'Auto starts opener without Run when ready')
frame(.2); check(actionCommands()==n+1,'Auto does not duplicate active opener')
callbacks.packet_in(actionPacket(1,3,1,185)); current.tp=0; frame(3.4)
check(actionCommands()==n+2,'Auto confirms opener before pact')
callbacks.packet_in(actionPacket(2,13,544,317,6)); current.recast=30; frame(1.1)
check(actionCommands()==n+3,'Auto confirms chain before burst')
callbacks.packet_in(actionPacket(1,4,145,252)); autoFrames(6)
check(actionCommands()==n+3,'Auto waits for next cycle resources')
current.tp=1000; current.recast=0; autoFrames(3)
check(actionCommands()==n+4,'Auto repeats without another click')
command('/crmm stop'); n=actionCommands(); autoFrames(6)
check(actionCommands()==n,'Stop disarms automatic repetition')
command('/crmm auto on'); current.sub=5; autoFrames(6)
check(actionCommands()==n,'Job change disarms Auto')
current.sub=4; autoFrames(5)
check(actionCommands()==n,'Auto stays off after returning to original job')
-- Farm controller: target ownership, summon/pull/Assault ordering, XP and cancellation.
local farmTime=0; local sent={}; local selected=3; local mob={index=3,id=30,name='Camp mob',hp=100,allowed=true}
local stopped
local f=require('crmm_farm').new({now=function() return farmTime end,stop=function(reason) stopped=reason end,
    mob=function() return mob end,choose=function() return mob end,select=function(index) selected=index end,
    command=function(c) sent[#sent+1]=c end,summon=function() return 'Ifrit' end,pull=function() return 'Fire' end})
local fs={context='one',hp=100,mp=100,exp=10,level=75,selected=3,battleTarget=3,status=1,pet=0,petTarget=0,weak={}}
local function ft(dt) farmTime=farmTime+(dt or 1); return f:tick(fs) end
f:start('one'); fs.weak=nil; fs.status=0; ft()
check(sent[#sent]=='/attack <t>','Farm engages before scan, summon and magic')
fs.status=1; sent={}; ft(3)
check(#sent==0 and f.target.id==30,'Farm locks target and waits for resistance scan')
fs.weak={}; ft(); check(sent[#sent]=='/ma "Ifrit" <me>','Farm summons before attacking')
ft(1); check(#sent==1,'Summon retry throttled')
fs.pet=2; ft(10); check(sent[#sent]=='/ma "Fire" <t>','Farm opening spell targets locked monster')
ft(6); check(sent[#sent]=='/pet "Assault" <t>','Farm directs Assault before combo')
fs.petTarget=3; fs.status=0; ft(3); check(sent[#sent]=='/attack <t>','Farm restores player engagement if lost')
fs.status=1; check(ft(3),'Farm permits combo only after player and pet share target')
fs.selected=4; ft(); check(selected==3,'Farm restores locked target instead of following cursor changes')
fs.selected=3; mob.hp=0; local before=#sent; ft(2); check(#sent==before,'No commands on defeated target')
fs.exp=30; ft(12); check(f.enabled and not f.target,'XP gain allows another target')
mob={index=4,id=40,name='Next mob',hp=100,allowed=true}; fs.selected=4; fs.petTarget=4; fs.battleTarget=4
ft(2); check(f.target.id==40,'Farm acquires next target after XP update')
mob.hp=0; ft(); ft(12); check(not f.enabled and stopped:find('no experience',1,true),'No XP after confirmed kill stops Farm')
mob.hp=100; f:start('one'); fs.context='two'; ft(); check(not f.enabled,'Farm stops on character context change')
fs.context='one'; f:start('one'); fs.hp=0; ft(); check(not f.enabled,'Farm stops on player defeat')
fs.hp=100; fs.distance=2; fs.petTarget=4; f:start('one'); local casts=#sent; ft(); check(#sent==casts,'Farm skips opening magic in melee range');
fs.hp=100; f:start('one'); ft(); mob.allowed=false; ft(); check(not f.enabled,'Farm stops on foreign claim')
mob.allowed=true; f:start('one'); ft(); mob={index=4,id=41,name='Replacement',hp=100,allowed=true}; ft(); check(not f.enabled,'Farm rejects reused entity slot')
f:start('one'); ft(301); check(not f.enabled,'Farm stops after five minutes without progress')
-- Actual adapter: correct 1-based resource job table and weakest learned summon.
current.target=3; current.pet=0; current.tp=0; current.status=0; current.exp=100
p.GetExpCurrent=function() return current.exp end
resource.GetSpellByName=function(_,name)
    if name=='Ifrit' then return {Index=288,LevelRequired={[16]=1},ManaCost=7} end
    if name=='Shiva' then return {Index=289,LevelRequired={[16]=1},ManaCost=7} end
    if name=='Fire II' then return {Index=145} end
end
local originalTarget=mem.GetTarget
mem.GetTarget=function() return {GetTargetIndex=function() return current.target end,SetTarget=function(_,index) current.target=index end} end
command('/crmm farm on'); n=actionCommands(); frame(); response(); frame()
check(chat[#chat]=='/attack <t>','Actual adapter sends player attack first')
current.status=1; autoFrames(6)
local summoned=false
for i=1,#chat do if chat[i]=='/ma "Ifrit" <me>' then summoned=true end end
check(summoned,'Actual Farm adapter chooses learned eligible elemental summon')
current.pet=2; current.petTarget=0; autoFrames(10)
local assault=false
for _,c in ipairs(chat) do if c=='/pet "Assault" <t>' then assault=true end end
check(assault,'Actual Farm sends Assault to selected target')
current.petTarget=3; autoFrames(3)
local attacked=false
for _,c in ipairs(chat) do if c=='/attack <t>' then attacked=true end end
check(attacked,'Actual Farm has engaged the player')
current.status=1; current.tp=1000; n=actionCommands(); autoFrames(2)
check(actionCommands()==n+1 and chat[#chat]:find('/ws',1,true),'Farm hands ready TP to automatic combo')
callbacks.packet_in(actionPacket(1,3,1,185)); current.tp=0; frame(3.4)
check(chat[#chat]:find('/pet "Shock Strike"',1,true),'Farm combo pact uses current locked target')
callbacks.packet_in(actionPacket(2,13,544,317,6)); frame(1.1)
check(chat[#chat]:find('/ma "Fire II"',1,true),'Farm combo casts burst after confirmed skillchain')
callbacks.packet_in(actionPacket(1,4,145,252)); current.mobHP=0; frame(1)
current.exp=120; frame(12.1)
check(not logs[#logs]:find('no experience',1,true),'Actual XP gain permits continuation')
command('/crmm stop'); current.mobHP=100; n=actionCommands(); autoFrames(6)
check(actionCommands()==n,'Stop disables actual Farm adapter commands')
-- A queued support spell is cancelled even if Stop happens before transmission.
current.pet=0; current.tp=0; command('/crmm farm on'); autoFrames(6); command('/crmm stop')
local utilityOut={id=0x1A,data=string.rep('\0',8)..string.char(1,0,3,0,32,1)}
callbacks.packet_out(utilityOut)
check(utilityOut.blocked,'Stop blocks queued summon support action')
mem.GetTarget=originalTarget
check(not table.concat(logs,'\n'):find('[crmm] Error:',1,true),'Actual panel and callbacks run without Lua errors')
print=oldprint
print('PASS: '..count..' crmm planner, runner, server and addon integration checks')

