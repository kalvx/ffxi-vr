local M={}
function M.new()return {timers={},labels={},chargeIntervals={},received=false}end
function M.set(s,kind,id,duration,time,name)
    if type(id)~='number'or type(duration)~='number'or duration<0 or duration>86400 then return end
    local key=kind..':'..id
    if duration==0 then s.timers[key]=nil;return end
    local previous=s.timers[key]
    local expires=time+duration
    -- Repeated snapshots must not refill a steadily falling bar.
    local total=duration
    if previous and math.abs(previous.expires-expires)<=1.1 then total=previous.total end
    s.timers[key]={kind=kind,id=id,expires=expires,total=math.max(1,total),name=name}
end
function M.snapshot(s,rows,time)
    if not rows then return end
    for key,timer in pairs(s.timers)do
        if timer.kind=='ability'and rows[timer.id]==nil then s.timers[key]=nil end
    end
    for id,duration in pairs(rows)do M.set(s,'ability',id,duration,time)end
    s.received=true
end
function M.rows(s,time,label,charge)
    local rows={}
    for key,t in pairs(s.timers)do
        local remaining=t.expires-time
        if remaining<=0 then s.timers[key]=nil
        else
            local name=t.name or label(t.kind,t.id)or(t.kind..' '..t.id)
            local c=t.kind=='ability'and charge(t.id)or nil
            local row={key=key,kind=t.kind,id=t.id,name=name,remaining=remaining,
                fraction=math.min(1,math.max(0,remaining/t.total))}
            if c then
                local interval=s.chargeIntervals[t.id]or c.interval
                row.charges=math.max(0,c.maximum-math.ceil(remaining/interval))
                row.maximum=c.maximum;row.name=name..string.format(' [%d/%d] · recharge',row.charges,c.maximum)
            end
            rows[#rows+1]=row
        end
    end
    table.sort(rows,function(a,b)if a.kind~=b.kind then return a.kind<b.kind end
        if a.remaining~=b.remaining then return a.remaining<b.remaining end return a.key<b.key end)
    return rows
end
function M.format(seconds)
    local n=math.ceil(math.max(0,seconds))
    if n>=3600 then return string.format('%dh %02dm %02ds',math.floor(n/3600),math.floor(n/60)%60,n%60)end
    if n>=60 then return string.format('%dm %02ds',math.floor(n/60),n%60)end
    return n..'s'
end
return M
