-- Bounded packet decoding. No game-memory addresses or resource-table scans.
local P = {}
function P.uint(data, offset, count)
    if type(data)~='string' or offset<0 or offset+count>#data then return nil end
    local value=0
    for i=count-1,0,-1 do value=value*256+data:byte(offset+i+1) end
    return value
end
function P.bits(data, offset, count)
    if type(data)~='string' or count<1 or count>32 or offset<0 or offset+count>#data*8 then return nil end
    local value=0
    for i=0,count-1 do
        local pos=offset+i
        value=value+math.floor(data:byte(math.floor(pos/8)+1)/2^(pos%8))%2*2^i
    end
    return value
end
function P.action(data)
    if type(data)~='string' or #data<19 then return nil end
    local category=P.bits(data,82,4)
    return {actor=P.uint(data,5,4),category=category,
        id=P.bits(data,86,category==11 and 13 or(category==8 or category==7)and 16 or 10),recast=P.bits(data,118,10),
        target=P.bits(data,150,32),result=P.bits(data,213,17),message=P.bits(data,230,10)}
end
function P.ability_recasts(data)
    if type(data)~='string' or #data<0x104 then return nil end
    local rows={[0]=P.uint(data,4,4)}
    for slot=0,30 do
        local offset=0x0C+slot*8
        if not(offset==0xFC and P.uint(data,0xFE,2)==256)then
            local id=P.uint(data,offset+3,1)
            if id and id>0 then rows[id]=P.uint(data,offset,3) end
        end
    end
    return rows
end
return P
