local P={}
function P.choose(report,party,time)
    if not report or time-report.time>4 then return nil end
    local eligible={}
    for _,row in ipairs(report.members)do
        local member=party[row.id]
        if member and member.alive and member.inRange and member.sameZone and row.hpp>0 then
            eligible[#eligible+1]={row=row,member=member}
        end
    end
    table.sort(eligible,function(a,b)if a.row.hpp~=b.row.hpp then return a.row.hpp<b.row.hpp end
        return a.member.slot<b.member.slot end)
    if report.heal or report.mixed then
        for _,v in ipairs(eligible)do
            if v.row.hpp<=75 and v.member.hpp<=75 then
                return {ability=report.heal and 136 or 137,name=report.heal and'Max Potion'or'Mix: Max Potion',slot=v.member.slot,id=v.row.id}
            end
        end
    end
    if report.guard then
        for _,v in ipairs(eligible)do
            if not v.row.protect or not v.row.shell then
                return {ability=147,name='Mix: Guard Drink',slot=v.member.slot,id=v.row.id}
            end
        end
    end
end
function P.parse(text,request,time)
    if type(text)~='string'then return nil end
    text=text:gsub('%z.*$','')
    local nonce,zone,heal,guard,body=text:match('^%[CRALC1%] (%d+) (%d+) ([0-3]) ([01]) ([%d,;]+)$')
    if not nonce or not request or tonumber(nonce)~=request.nonce or tonumber(zone)~=request.zone or time-request.time>4 then return nil end
    local readiness=tonumber(heal)
    local report={time=time,heal=readiness%2==1,mixed=readiness>=2,guard=guard=='1',members={}};local seen={}
    for line in body:gmatch('[^;]+')do
        local id,hpp,protect,shell=line:match('^(%d+),(%d+),([01]),([01])$')
        id=tonumber(id);hpp=tonumber(hpp)
        if not id or id<1 or id>4294967295 or not hpp or hpp>100 or seen[id]then return nil end
        seen[id]=true;report.members[#report.members+1]={id=id,hpp=hpp,protect=protect=='1',shell=shell=='1'}
    end
    if #report.members<1 or #report.members>6 then return nil end
    return report
end
return P
