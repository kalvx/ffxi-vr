local P={}
function P.build(text,map,caps)
    if type(text)~='string'then return nil,'Clipboard is empty.'end
    text=text:gsub('[\r\n]+$','')
    if text==''then return nil,'Clipboard is empty.'end
    if #text>240 then return nil,'Copy one line of up to 240 characters.'end
    if text:find('[\r\n]')then return nil,'Copy one macro command line at a time.'end
    local plan={}
    for i=1,#text do
        local ch=text:byte(i)
        if ch<32 or ch>126 then return nil,'This paste helper currently supports plain English text.'end
        local value=map(ch)
        if not value or value<0 or math.floor(value/256)>1 then return nil,'A character is unavailable on this keyboard layout.'end
        local key=value%256;local shift=math.floor(value/256)==1
        if key>=65 and key<=90 and caps then shift=not shift end
        plan[#plan+1]={key=key,shift=shift}
    end
    return plan,text
end
return P
