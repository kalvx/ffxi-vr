-- Temporary per-entity body motion. No emote packet, effects or wing resources.
local visual = {}
local active = {}
local actorMotion = require('float_actor')
local function fourcc(text)
    return text:byte(1) + text:byte(2)*256 + text:byte(3)*65536 + text:byte(4)*16777216
end
-- Live capture: the ten slots contain three-character motion prefixes padded
-- with a space. The engine selects the matching 0/1 body tracks itself.
local floatPrefix = fourcc('flt ')
local locomotion = { [fourcc('idl ')] = true, [fourcc('wlk ')] = true, [fourcc('run ')] = true }
local function restore(entry)
    if not entry.index then return end
    local entities = AshitaCore:GetMemoryManager():GetEntity()
    if entities:GetServerId(entry.index) ~= entry.id then return end
    actorMotion.restore(entry,entities,floatPrefix)
    for slot = 0, 9 do
        local value = entities:GetAnimation(entry.index, slot)
        if value == floatPrefix and entry.saved and entry.saved[slot] then
            entities:SetAnimation(entry.index, slot, entry.saved[slot])
        end
    end
end
function visual.message(plain, now)
    local id, state = plain:match('^%[Alchemist Float%] (%d+) (%a+)%.$')
    if not id or (state ~= 'Start' and state ~= 'End') then return false end
    id = tonumber(id)
    if state == 'End' then
        if active[id] then restore(active[id]); active[id] = nil end
    else
        active[id] = active[id] or { id = id }
        active[id].refreshed = now
    end
    return true
end
function visual.tick(now)
    if next(active) == nil then return end
    local entities = AshitaCore:GetMemoryManager():GetEntity()
    for id, entry in pairs(active) do
        if (now - entry.refreshed) % 4294967296 > 4500 then
            restore(entry); active[id] = nil
        else
            if entry.index and entities:GetServerId(entry.index) ~= id then entry.index = nil; entry.saved = nil; entry.actor=nil; entry.actorSaved=nil end
            if not entry.index and (not entry.searched or (now-entry.searched)%4294967296 >= 500) then
                entry.searched = now
                for index = 0, 2303 do
                    if entities:GetServerId(index) == id then entry.index = index; break end
                end
            end
            if entry.index then
                local status = entities:GetStatus(entry.index)
                if entities:GetHPPercent(entry.index) > 0 and (status == 0 or status == 1) then
                    entry.saved = entry.saved or {}
                    -- Change only captured idle/walk/run prefixes. Sit/fishing
                    -- slots and the action/emote scheduler remain native.
                    for slot = 0, 9 do
                        local value = entities:GetAnimation(entry.index, slot)
                        if locomotion[value] then
                            entry.saved[slot] = value
                            entities:SetAnimation(entry.index, slot, floatPrefix)
                        end
                    end
                    actorMotion.apply(entry,entities,floatPrefix,locomotion)
                else
                    restore(entry)
                end
            end
        end
    end
end
function visual.clear()
    for _, entry in pairs(active) do restore(entry) end
    active = {}
end
return visual
