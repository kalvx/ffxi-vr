-- The exact entity-to-skeleton cache copy is verified from the loaded H DLL.
-- No executable hook, global motion-table patch or coordinate change.
local cache={}
local pattern='8B86A00000008B8EA40100008988C80700008B96A00000008B86B00100008982CC0700008B8EA00000008B96B40100008991D0070000'
local fields={0x7c8,0x7cc,0x7d0} -- native idle, walk, run copies
local supported=false
if ashita and ashita.memory then
    local ok,address=pcall(ashita.memory.find,'FFXiMain.dll',0,pattern,0,0)
    supported=ok and type(address)=='number' and address~=0
end
function cache.restore(entry,entities,prefix)
    if not entry.actor or not entry.actorSaved or not entry.index then return end
    if entities:GetServerId(entry.index)~=entry.id or entities:GetActorPointer(entry.index)~=entry.actor then return end
    for _,offset in ipairs(fields)do
        if entry.actorSaved[offset] and ashita.memory.read_uint32(entry.actor+offset)==prefix then
            ashita.memory.write_uint32(entry.actor+offset,entry.actorSaved[offset])
        end
    end
end
function cache.apply(entry,entities,prefix,locomotion)
    if not supported then return end
    local actor=entities:GetActorPointer(entry.index)
    if not actor or actor<0x10000 then return end
    if entry.actor~=actor then entry.actor=actor;entry.actorSaved={} end
    -- Claim only ordinary locomotion cache values. Other model/action owners
    -- retain their cache entries; never touch the current action or pose state.
    for _,offset in ipairs(fields)do
        local value=ashita.memory.read_uint32(actor+offset)
        if locomotion[value] then
            entry.actorSaved[offset]=value
            ashita.memory.write_uint32(actor+offset,prefix)
        end
    end
end
return cache
