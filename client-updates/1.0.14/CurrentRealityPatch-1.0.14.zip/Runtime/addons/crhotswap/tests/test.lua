local core=require('crhs_core')
local config=require('crhs_config')
local exported=require('crhs_data')
assert(exported.items[10240] and exported.generated,'Generated server snapshot loads')
local s={main=6,sub=13,level=75,su=0,mp=0,race=1}
local count=0
local function check(ok,label) assert(ok,label); count=count+1 end
local function item(id,slot,mods,index)
    return {id=id,name='Item '..id,bag=0,index=index or id,slots=2^slot,mods=mods or {}}
end
local hp=item(1,8,{[2]=100})
local speed=item(2,8,{[76]=12})
local atk=item(3,8,{[23]=20,[25]=10})
local regen=item(4,5,{[370]=2})
local body=item(5,5,{[2]=50})
local found={hp,speed,atk,regen,body}
check(core.plan(found,'idle',s,config)[8]==speed,'Idle chooses movement speed')
check(core.plan(found,'idle',s,config)[5]==regen,'Recovery participates in idle scoring')
check(core.plan(found,'attack',s,config)[8]==atk,'Attack uses attack/accuracy')
check(core.plan(found,'idle',s,config,{[8]=hp})[8]==hp,'Manual choice overrides movement speed')
local ring=item(6,13,{[25]=20}); ring.slots=2^13+2^14
local second=item(7,13,{[25]=10}); second.slots=ring.slots
local rings=core.plan({ring,second},'attack',s,config)
check(rings[13]~=rings[14] and rings[13] and rings[14],'No duplicate physical ring')
local one=core.plan({ring},'attack',s,config)
check((one[13]~=nil)~=(one[14]~=nil),'One ring only fills one slot')
ring.equipped=14
check(core.plan({ring,second},'attack',s,config)[14]==ring,'Avoids needless paired-slot moves')
check(core.plan({ring,second},'attack',s,config,{[13]=ring})[14]==second,'Pinned ring reserves physical copy')
local d={level=75,su=0,jobs=32,blocked=0,mods={}}
check(core.eligible(d,s),'Main-job mask accepted')
s.main=1; check(not core.eligible(d,s),'Subjob does not grant gear permission'); s.main=6
s.level=74; check(not core.eligible(d,s),'Level requirement respected'); s.level=75
d.su=1; check(not core.eligible(d,s),'Superior requirement respected'); d.su=0
d.mods[276]=2; check(not core.eligible(d,s),'Race restriction respected'); d.mods={}
d.blocked=64; check(not core.eligible(d,s),'Multi-slot armor excluded')
local refresh=item(8,5,{[369]=10})
check(core.score(refresh,'idle',s,config)==0,'No Refresh value on MP-less job')
s.mp=100; check(core.score(refresh,'idle',s,config)==300,'Refresh value on MP job')
config.profiles['THF/NIN']={attack={attack=0,accuracy=10,str=0,dex=0}}
check(core.score(atk,'attack',s,config)==100,'Main/sub-specific priorities')
config.profiles={}
local defense=item(20,5,{[1]=50,[161]=-500})
local fragile=item(21,5,{[1]=50,[161]=500})
check(core.score(defense,'defense',s,config)>core.score(fragile,'defense',s,config),'Damage reduction sign and scale respected')
local evade=item(22,5,{[68]=20,[108]=5,[11]=10})
check(core.plan({defense,evade},'evasion',s,config)[5]==evade,'Evasion prioritizes evasion, skill and AGI')
local summoner=item(23,5,{[117]=10,[346]=2,[357]=3})
local nuker=item(24,5,{[28]=50,[30]=10,[115]=10})
local healer=item(25,5,{[374]=10,[112]=10})
check(core.plan({summoner,nuker},'magic_summoning',s,config)[5]==summoner,'Summoning values skill, perpetuation and pact delay rather than caster MAB')
check(core.plan({summoner,nuker},'magic_elemental',s,config)[5]==nuker,'Elemental values offensive magic stats')
check(core.plan({healer,nuker},'magic_healing',s,config)[5]==healer,'Healing values cure potency and healing skill')
check(core.autoMagic(s)=='ninjutsu','THF/NIN chooses ninjutsu')
check(core.autoMagic({main=15,sub=3})=='summoning','SMN/WHM prioritizes main-job magic')
check(core.autoMagic({main=6,sub=3})=='healing','THF/WHM recognizes subjob magic')
check(core.autoMagic({main=6,sub=19})=='casting','Nonmagic jobs use neutral casting focus')
-- Load the actual entry point against a mocked Ashita API and exercise callbacks.
local recovery=item(26,8,{[72]=5})
check(core.plan({speed,hp,recovery},'rest',s,config)[8]==recovery,'Rest chooses recovery over movement and HP')
local mpRecovery=item(27,8,{[71]=5})
s.mp=0; check(core.score(mpRecovery,'rest',s,config)==0,'Rest ignores healing MP without MP pool')
s.mp=100; check(core.score(mpRecovery,'rest',s,config)==250,'Rest scores healing MP with MP pool')
local callbacks,packets,messages={},{},{}
local chat,status={},0
local t,job,sub,online=100,6,13,true
local equippedItems={}
local gear={[1]={Id=1,Count=1,Flags=0,Extra='a'},[2]={Id=2,Count=1,Flags=0,Extra='b'}}
local inv={GetContainerCountMax=function(_,bag) return bag==0 and 2 or 0 end,
    GetContainerItem=function(_,bag,index) return bag==0 and gear[index] or nil end,
    GetEquippedItem=function(_,slot) return {Index=equippedItems[slot] or 0} end}
local player={GetLoginStatus=function() return online and 2 or 0 end,GetMainJob=function() return job end,
    GetSubJob=function() return sub end,GetMainJobLevel=function() return 75 end,GetSubJobLevel=function() return 37 end,
    GetSuLevel=function() return 0 end,GetMPMax=function() return 0 end}
local party={GetMemberTargetIndex=function() return 1 end,GetMemberIsActive=function() return 1 end,
    GetMemberServerId=function() return 6 end,GetMemberZone=function() return 230 end,GetMemberHP=function() return 100 end}
local entity={GetStatusServer=function() return status end,GetRace=function() return 1 end}
local mem={GetInventory=function() return inv end,GetPlayer=function() return player end,
    GetParty=function() return party end,GetEntity=function() return entity end}
local resource={GetItemById=function(_,id) return {Flags=0x800,Slots=256,Name={[1]='Test '..id}} end}
local acknowledge=true
local packet={AddOutgoingPacket=function(_,id,bytes)
    packets[#packets+1]={id=id,bytes=bytes}
    if acknowledge then equippedItems[bytes[6]]=bytes[5]==0 and 0 or bytes[7]*256+bytes[5] end
end}
AshitaCore={GetMemoryManager=function() return mem end,GetResourceManager=function() return resource end,GetPacketManager=function() return packet end}
AshitaCore.GetChatManager=function() return {QueueCommand=function(_,kind,text) chat[#chat+1]=text end} end
addon={}; T=function(x) return x end
ashita={events={register=function(event,name,fn) callbacks[event]=fn end}}
package.loaded.common={}
package.loaded.ffi={cdef=function() end,C={GetTickCount=function() return t*1000 end}}
local choices={choices={},magicTypes={}}
package.loaded.settings={load=function() return choices end,register=function() end,save=function() end}
local click
local ui=setmetatable({Begin=function() return true end,Button=function(label) if click==label then click=nil; return true end; return false end,
    Selectable=function(label) if click and label:find(click,1,true) then click=nil; return true end; return false end,
    IsItemHovered=function() return true end}, {__index=function() return function() end end})
package.loaded.imgui=ui
package.loaded.crhs_data={items={
    [1]={level=1,su=0,jobs=32,slots=256,blocked=0,mods={[76]=12}},
    [2]={level=1,su=0,jobs=32,slots=256,blocked=0,mods={[23]=50}}
}}
local originalPrint=print
print=function(message) messages[#messages+1]=message end
local path=package.searchpath('crhotswap',package.path)
assert(loadfile(path))()
local function command(text)
    local e={command=text}; callbacks.command(e); return e.blocked
end
local function frame() t=t+0.3; callbacks.d3d_present() end
check(not command('/crhotswapother'),'Does not intercept unrelated commands')
check(command('/crhotswap scan') and #packets==0,'Scan is read-only')
command('/crhotswap preview idle'); frame()
check(#packets==0,'Preview is read-only and panel renders')
command('/crhotswap idle'); frame(); t=t+3; frame()
check(#packets==1 and packets[1].id==0x50 and packets[1].bytes[5]==1 and packets[1].bytes[6]==8,'Idle emits correct slot/index packet')
check(messages[#messages]:find('confirmed',1,true)~=nil,'Swap verifies actual equipped item')
command('/crhotswap attack'); job=1; frame()
check(#packets==1,'Job change cancels pending swap')
job=6; command('/crhotswap attack'); gear[2].Id=3; frame()
check(#packets==1 and messages[#messages]:find('Inventory changed',1,true),'Stale inventory cancels swap')
gear[2].Id=2; command('/crhotswap attack'); command('/crhotswap stop'); frame()
check(#packets==1,'Stop cancels queued requests')
command('/crhotswap attack'); callbacks.packet_in({id=0x00B}); frame()
check(#packets==1,'Zoning cancels queued requests')
t=t+4; command('/crhotswap attack'); frame()
check(#packets==1,'Waits for inventory finish after zoning')
callbacks.packet_in({id=0x01D,data=string.char(0,0,0,0,1)})
command('/crhotswap attack'); acknowledge=false; frame(); t=t+3; frame()
check(messages[#messages]:find('Not confirmed',1,true)~=nil,'Rejected gear is not reported as success')
command('/crhotswap scan'); click='##slot8'; frame(); click='Test 1 |'; frame()
check(next(choices.choices)~=nil,'Clicking alternative persists personal choice')
command('/crhotswap attack'); acknowledge=true; frame(); t=t+3; frame()
check(equippedItems[8]==1,'Saved alternative overrides scoring')
sub=19; command('/crhotswap attack'); frame(); t=t+3; frame()
check(equippedItems[8]==2,'THF/DNC does not inherit THF/NIN override')
local before=#packets; online=false; command('/crhotswap idle'); frame()
check(#packets==before,'Offline action emits no packet')
online=true; sub=13; gear[1].Id=99
command('/crhotswap attack'); frame()
check(#packets==before and messages[#messages]:find('Saved choice unavailable',1,true),'Missing saved choice prevents silent substitution')
choices.choices={}; gear[1].Id=11; gear[2].Id=12
package.loaded.crhs_data.items[11]={level=1,su=0,jobs=32,slots=2^13+2^14,blocked=0,mods={[25]=20}}
package.loaded.crhs_data.items[12]={level=1,su=0,jobs=32,slots=2^13+2^14,blocked=0,mods={[25]=10}}
equippedItems={[13]=2,[14]=1}
choices.choices['6:THF/NIN:attack:13']='11:0:61'
command('/crhotswap attack')
for i=1,5 do frame() end
t=t+3; frame()
check(equippedItems[13]==1 and equippedItems[14]==2,'Pinned paired-slot swap releases old slots and equips both pieces')
check(packets[before+1].bytes[5]==0 and packets[before+2].bytes[5]==0,'Paired swaps release before equipping')
before=#packets
for i=1,10 do frame() end
check(#packets==before,'Idle frames never trigger automatic gear changes')
command('/crhotswap preview magic summoning'); frame()
check(messages[#messages]:find('ring2',1,true)~=nil,'School-specific magic preview renders')
command('/crhotswap magic'); frame(); t=t+3; frame()
check(messages[#messages]:find('magic_ninjutsu',1,true)~=nil,'Magic command resolves current main/sub focus')
command('/crhotswap def'); frame(); t=t+3; frame()
check(messages[#messages]:find('defense',1,true)~=nil,'Defense alias works')
command('/crhotswap evasion'); frame(); t=t+3; frame()
check(messages[#messages]:find('evasion',1,true)~=nil,'Evasion command works')
choices.choices={}; equippedItems={}
command('/crhotswap preview rest'); frame()
check(#chat==0,'Rest preview does not rest')
command('/crhotswap rest'); frame()
check(#chat==0,'Rest waits for equipment confirmation')
for i=1,4 do frame() end
t=t+3; frame()
check(#chat==1 and chat[1]=='/heal on','Confirmed recovery set starts resting without toggle')
status=33; command('/crhotswap rest'); frame()
check(#chat==1,'Already resting does not toggle off')
status=1; before=#packets; command('/crhotswap rest'); frame()
check(#chat==1 and #packets==before,'Combat blocks Rest')
status=0; equippedItems={}; acknowledge=false
command('/crhotswap rest'); for i=1,4 do frame() end; t=t+3; frame()
check(#chat==1 and messages[#messages]:find('Not confirmed',1,true),'Failed swap cannot start rest')
acknowledge=true; command('/crhotswap rest'); command('/crhotswap stop')
for i=1,10 do frame() end
check(#chat==1,'Stop cancels pending rest')
command('/crhotswap rest'); status=1; frame(); status=0
for i=1,10 do frame() end
check(#chat==1,'Entering combat cancels pending rest')
click='Rest'; frame(); for i=1,4 do frame() end; t=t+3; frame()
check(#chat==2,'Rest button equips and requests rest')
print=originalPrint
print('PASS: '..count..' optimizer and addon integration checks')
