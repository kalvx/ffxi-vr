addon.name='cralltimers';addon.author='Current Reality';addon.version='1.2';
addon.desc='Packet-driven all-job spell and ability recast bars.';
require('common')
local imgui=require('imgui');local settings=require('settings');local ffi=require('ffi')
local packets=require('cr_packets');local model=require('cr_recast_model');local catalog=require('cr_recast_catalog')
ffi.cdef('unsigned long long __stdcall GetTickCount64(void);')
local function now()return tonumber(ffi.C.GetTickCount64())/1000 end
local config=settings.load(T{visible=true,locked=false,width=300,x=28,y=250})
local state=model.new();local owner,profile;local job={main=0,sub=0,level=0,sublevel=0}
local diagnostic={packets=0,actions=0,draws=0,lastId=0,lastSize=0,login=0,active=0,error='none'}
local function context()
    local mem=AshitaCore:GetMemoryManager();local player,party=mem:GetPlayer(),mem:GetParty()
    diagnostic.login=player:GetLoginStatus();diagnostic.active=party:GetMemberIsActive(0)
    if diagnostic.login~=2 or diagnostic.active==0 then return nil end
    local id=party:GetMemberServerId(0)
    if not id or id==0 then return nil end
    local key=table.concat({id,player:GetMainJob(),player:GetSubJob()},':')
    if owner and(owner~=id or profile~=key)then state=model.new()end
    owner=id;profile=key
    job={main=player:GetMainJob(),sub=player:GetSubJob(),level=player:GetMainJobLevel(),sublevel=player:GetSubJobLevel()}
    return id
end
local function available(a)
    return(a.job==job.main and a.level<=job.level)or(a.job==job.sub and a.level<=job.sublevel and a.group~=0)
end
local function label(kind,id)
    if kind=='spell'then return catalog.spells[id]or('Spell '..id)end
    if state.labels[id]then return state.labels[id]end
    if id==231 then return 'Stratagems'end
    if id==195 then return 'Quick Draw'end
    if id==102 then return 'Ready'end
    local names,seen={},{}
    for _,a in pairs(catalog.abilities)do
        if a.group==id and available(a)and not seen[a.name]then names[#names+1]=a.name;seen[a.name]=true end
    end
    table.sort(names)
    if #names>3 then return table.concat({names[1],names[2]},' / ')..' + '..(#names-2)..' shared'end
    return #names>0 and table.concat(names,' / ')or('Ability recast '..id)
end
local function charge(id)
    local best
    for _,c in ipairs(catalog.charges)do
        local level=c.job==job.main and job.level or c.job==job.sub and job.sublevel or 0
        if c.group==id and c.level<=level and(not best or c.level>best.level)then best=c end
    end
    return best
end
settings.register('settings','cralltimers_settings',function(s)if s then config=s end end)
ashita.events.register('packet_in','cralltimers_packets',function(e)
    if e.blocked then return end
    local id=context();if not id then return end
    local raw=e.data_modified or e.data
    if e.id==0x119 then
        diagnostic.packets=diagnostic.packets+1;diagnostic.lastId=e.id;diagnostic.lastSize=type(raw)=='string'and#raw or-1
        model.snapshot(state,packets.ability_recasts(raw),now())
    elseif e.id==0x028 then
        diagnostic.actions=diagnostic.actions+1;diagnostic.lastId=e.id;diagnostic.lastSize=type(raw)=='string'and#raw or-1
        local a=packets.action(raw)
        if not a or a.actor~=id then return end
        diagnostic.category=a.category;diagnostic.actionId=a.id;diagnostic.recast=a.recast
        if a.category==4 and a.id<=1023 then model.set(state,'spell',a.id,a.recast,now())
        elseif a.category==6 or a.category==11 then
            local abilityId=a.category==11 and catalog.alcActions[a.id]or a.id
            local ability=abilityId and catalog.abilities[abilityId]
            if ability and available(ability)then
                state.labels[ability.group]=ability.name
                local c=charge(ability.group)
                if c and a.recast>0 then state.chargeIntervals[ability.group]=a.recast/math.max(1,ability.recast)end
            end
        end
    end
end)
ashita.events.register('command','cralltimers_commands',function(e)
    local args=e.command:lower():match('^/cralltimers%s*(.-)%s*$');if args==nil then return end
    e.blocked=true
    if args==''then config.visible=not config.visible
    elseif args=='show'then config.visible=true
    elseif args=='hide'then config.visible=false
    elseif args=='lock'then config.locked=true
    elseif args=='unlock'then config.locked=false
    elseif args=='debug'then print('[cralltimers] Ability snapshot: '..tostring(state.received)..'; active bars: '..#model.rows(state,now(),label,charge)..'; login: '..diagnostic.login..'; packets: '..diagnostic.packets)
    else print('[cralltimers] show | hide | lock | unlock | debug')end
    settings.save()
end)
local function draw()
    diagnostic.draws=diagnostic.draws+1
    if not config.visible or not context()then return end
    local rows=model.rows(state,now(),label,charge);diagnostic.bars=#rows;if #rows==0 then return end
    imgui.SetNextWindowPos({config.x,config.y},ImGuiCond_FirstUseEver)
    imgui.SetNextWindowSize({config.width+24,0},ImGuiCond_Always)
    local flags=ImGuiWindowFlags_AlwaysAutoResize+ImGuiWindowFlags_NoCollapse
    if config.locked then flags=flags+ImGuiWindowFlags_NoMove end
    if imgui.Begin('CR All Timers',nil,flags)then
        local x,y=imgui.GetWindowPos();if type(x)=='table'then config.x=x[1];config.y=x[2]else config.x=x;config.y=y end
        for _,r in ipairs(rows)do
            imgui.TextWrapped(r.name)
            local color=r.kind=='spell'and{0.25,0.56,0.88,1}or{0.76,0.57,0.22,1}
            imgui.PushStyleColor(ImGuiCol_PlotHistogram,color)
            imgui.ProgressBar(r.fraction,{config.width,14},model.format(r.remaining))
            imgui.PopStyleColor()
        end
    end
    imgui.End()
end
ashita.events.register('d3d_present','cralltimers_draw',function()
    local ok,err=pcall(draw)
    if not ok then
        if diagnostic.error~=tostring(err)then diagnostic.error=tostring(err);print('[cralltimers] '..tostring(err))end
    end
end)
ashita.events.register('load','cralltimers_load',function()print('[cralltimers] 1.2 loaded. Bars appear after a cooldown starts; /cralltimers debug checks their status.')end)
ashita.events.register('unload','cralltimers_unload',function()settings.save()end)
