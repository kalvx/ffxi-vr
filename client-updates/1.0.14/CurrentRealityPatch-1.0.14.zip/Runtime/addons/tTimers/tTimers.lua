-- Current Reality compatibility entry: the old timer implementation is bypassed.
addon.name='tTimers';addon.author='Current Reality';addon.version='1.0';
addon.desc='Compatibility entry for CR All Timers; legacy timer code is not executed.';
require('common')
ashita.events.register('load','ttimers_cr_bridge',function()
    AshitaCore:GetChatManager():QueueCommand(1,'/addon load cralltimers')
end)
