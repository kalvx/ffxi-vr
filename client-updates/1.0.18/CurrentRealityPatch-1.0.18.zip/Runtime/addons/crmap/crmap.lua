addon.name='crmap';addon.author='Current Reality';addon.version='1.0';
addon.desc='Square Minimap preset, dragging and X+A left-stick zoom.'
require('common');require('win32types')
local ffi=require('ffi');local imgui=require('imgui');local control=require('control')
ffi.cdef[[unsigned long long __stdcall GetTickCount64(void); HWND __stdcall GetForegroundWindow(void);]]
local user32=ffi.load('user32')
local config=AshitaCore:GetConfigurationManager()
local plugins=AshitaCore:GetPluginManager()
local root=AshitaCore:GetInstallPath()
local path=root..'config\\minimap\\minimap.ini'
local marker=root..'config\\minimap\\crmap-square-v1.applied'
local backup=root..'config\\minimap\\minimap.before-crmap-v1.ini'
local states={};local enabled=true;local drag;local migration;local lastZoom=-1
local function now()return tonumber(ffi.C.GetTickCount64())/1000 end
local function focused()
    local hwnd=tonumber(AshitaCore:GetProperties():GetFinalFantasyHwnd())
    return hwnd and hwnd~=0 and hwnd==tonumber(ffi.cast('uintptr_t',user32.GetForegroundWindow()))
end
local function loaded()return plugins:IsLoaded('minimap')end
local function send(command)AshitaCore:GetChatManager():QueueCommand(-1,command)end
local function read(file)
    local f=io.open(file,'rb');if not f then return end
    local data=f:read('*a');f:close();return data
end
local function write(file,data)
    local f,err=io.open(file,'wb');if not f then return nil,err end
    local ok,why=f:write(data);local closed=f:close();return ok and closed,why
end
local presetDone=read(marker)~=nil
local function number(key,fallback)return config:GetFloat('minimap','main',key,fallback)end
local function zoom(direction)
    local t=now();if t-lastZoom<0.08 then return end
    lastZoom=t
    local value=math.max(0.1,math.min(3,number('zoom',0.35)+direction*0.05))
    send(('/minimap zoom %.3f'):format(value))
end
local function display()
    local a=imgui.GetIO().DisplaySize
    return a.x or a[1],a.y or a[2]
end
local function move(x,y)
    local w,h=display()
    local size=248*number('scale_x',1)
    x=math.max(0,math.min(w-size,x));y=math.max(0,math.min(h-248*number('scale_y',1),y))
    send(('/minimap position %.1f %.1f'):format(x,y))
end
ashita.events.register('xinput_state','crmap_state',function(e)
    if e.size~=16 then return end
    local raw=e.state
    -- Ashita exposes state buffers as strings; unknown representations pass through.
    if type(raw)~='string'or #raw~=16 then return end
    local id=e.user;states[id]=states[id]or control.new()
    local active=enabled and not migration and loaded()and focused()
    local output,direction=control.step(states[id],raw,now(),active)
    if output~=raw then
        -- Preserve modifications made by earlier handlers to unrelated fields.
        local previous=e.state_modified
        if type(previous)=='string'and #previous==16 then
            local o=output:byte(5)+output:byte(6)*256
            local p=previous:byte(5)+previous:byte(6)*256
            local bit=require('bit');p=bit.bor(bit.band(p,bit.bnot(0x5000)),bit.band(o,0x5000))
            local axes=output:sub(9,12)~=raw:sub(9,12)and output:sub(9,12)or previous:sub(9,12)
            output=previous:sub(1,4)..string.char(p%256,math.floor(p/256))..previous:sub(7,8)..axes..previous:sub(13)
        end
        e.state_modified=output
    end
    if direction~=0 then zoom(direction)end
end)
ashita.events.register('mouse','crmap_drag',function(e)
    if not enabled or migration or not loaded()or not focused()then drag=nil;return end
    local x,y=number('x',25),number('y',25)
    if e.message==513 and not e.blocked and e.x>=x and e.x<=x+248*number('scale_x',1)
        and e.y>=y and e.y<=y+248*number('scale_y',1)then
        drag={dx=e.x-x,dy=e.y-y};e.blocked=true
    elseif drag and e.message==512 then move(e.x-drag.dx,e.y-drag.dy);e.blocked=true
    elseif drag and e.message==514 then move(e.x-drag.dx,e.y-drag.dy);drag=nil;e.blocked=true end
end)
-- First selected-Minimap launch only: unload before editing so its final save
-- cannot overwrite the preset. Keep a complete receiving-client backup.
ashita.events.register('d3d_present','crmap_preset',function()
    if migration=='failed'then return end
    if migration then
        if now()<migration.due then return end
        if migration.phase=='unload'then
            if loaded()then migration='failed';print('[crmap] Preset stopped: Minimap did not unload.');return end
            local original=read(path)
            local w,h=display();local x,y=control.position(w,h,248)
            local data,err=control.preset(original or'',x,y)
            if not data then
                migration='failed';send('/load minimap');print('[crmap] Preset skipped: '..tostring(err));return
            end
            if not read(backup)then
                local ok=write(backup,original)
                if not ok then migration='failed';send('/load minimap');print('[crmap] Cannot back up Minimap settings.');return end
            end
            local ok=write(path,data)
            if not ok then write(path,original);migration='failed';send('/load minimap');print('[crmap] Cannot save Minimap preset.');return end
            send('/load minimap');migration={phase='load',due=now()+1}
        elseif loaded()then
            write(marker,'Square preset applied once. Later personal changes are retained.\n')
            presetDone=true
            migration=nil
            print('[crmap] Square map ready. Hold X+A and move left stick up/down to zoom; drag the map to move it.')
        else migration='failed';print('[crmap] Minimap did not reload. Use /load minimap.');end
    elseif loaded()and not presetDone then
        send('/unload minimap');migration={phase='unload',due=now()+0.75}
    end
end)
ashita.events.register('command','crmap_command',function(e)
    local args=e.command:args();if not args[1]or args[1]:lower()~='/crmap'then return end
    e.blocked=true
    local cmd=(args[2]or'help'):lower()
    if cmd=='off'then enabled=false;states={};drag=nil
    elseif cmd=='on'then enabled=true
    elseif cmd=='in'and loaded()then zoom(1)
    elseif cmd=='out'and loaded()then zoom(-1)
    elseif cmd=='corner'and loaded()then local w,h=display();local x,y=control.position(w,h,248*number('scale_x',1));move(x,y)
    else print('[crmap] Hold X+A + left stick up/down. Drag map to move. /crmap in | out | corner | on | off. /minimap opens native settings.')end
end)
